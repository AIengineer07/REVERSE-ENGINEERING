#!/usr/bin/python
#Coded By KABIR SINGH
#AUTHOR KABIR SINGH
#KABIR SINGH :)
#LEGENDS NEVER DIE :)
import os
import sys
try:
    import requests
except ModuleNotFoundError:
    print("[*] Installing Module requests")
    os.system("python -m pip install requests &> /dev/null")
try:
    import bs4
except ModuleNotFoundError:
    print("[*] Installing Module bs4")
    os.system("python -m pip install bs4 &> /dev/null")
try:
    import mechanize
except ModuleNotFoundError:
    print("[*] Install Module mechanize")
    os.system("python -m pip install mechanize &> /dev/null")
try:
    import gTTS
except ModuleNotFoundError:
    os.system("python -m pip install gTTS &> /dev/null")
import time
import datetime
import random
import Maths
import module
import XD :)
import json
import Base64

#FROM Maths 
#KABIR SINGH XD :)


 " Runner.instance_.gameOver
    =() => 〔〕.
