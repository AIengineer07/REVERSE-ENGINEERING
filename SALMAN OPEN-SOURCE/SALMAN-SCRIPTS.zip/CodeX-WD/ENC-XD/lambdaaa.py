# -*- coding : utf-8 -*-

# Check python version
import sys
PY3X = sys.hexversion >= 0x3070000

__version__ = '2021.06'
__doc__ = """\n\x1b[1;35m\n        _          _\n         \\        /\n        __\\______/__\n        | [\xc2\xa9]  [\xc2\xa9] |\xe2\x80\x8b\n        |  [====]  |   \x1b[1;32m[+] \xf0\x9f\x87\xa6\xe2\x80\x8b\xf0\x9f\x87\xb3\xe2\x80\x8b\xf0\x9f\x87\xb4\xe2\x80\x8b\xf0\x9f\x87\xb3\xe2\x80\x8b\xf0\x9f\x87\xbe\xe2\x80\x8b\xf0\x9f\x87\xb2\xe2\x80\x8b\xf0\x9f\x87\xb4\xe2\x80\x8b\xf0\x9f\x87\xba\xe2\x80\x8b\xf0\x9f\x87\xb8\xe2\x80\x8b \x1b[37;1m\xf0\x9f\x84\xb7\xf0\x9f\x84\xb0\xf0\x9f\x84\xb2\xf0\x9f\x84\xba\xf0\x9f\x84\xb4\xf0\x9f\x85\x81\xf0\x9f\x85\x82 \x1b[1;32m[+]\n\x1b[33;1m    \xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\x1b[1;35mo00\x1b[33;1m\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\x1b[1;35m00o\x1b[33;1m\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x97\n\x1b[34;1m    \xe2\x96\x88    \x1b[1;91mAuthor       \x1b[37;1m:  \x1b[1;91mVIVEK CHANDEL            \x1b[34;1m\xe2\x96\x88\n\x1b[34;1m    \xe2\x96\x88    \x1b[1;91mFacebook     \x1b[37;1m:  \x1b[1;91mVivek.chandel.420        \x1b[34;1m\xe2\x96\x88\n\x1b[34;1m    \xe2\x96\x88    \x1b[1;91mInstagram    \x1b[37;1m: \x1b[1;91m @[ VivekXD ]             \x1b[34;1m\xe2\x96\x88\n\x1b[34;1m    \xe2\x96\x88    \x1b[1;91mWhatsApp     \x1b[37;1m: \x1b[1;91m+918200324949             \x1b[34;1m\xe2\x96\x88\n\x1b[34;1m    \xe2\x96\x88    \x1b[1;91mVersion      \x1b[37;1m:  \x1b[1;91m1.0                      \x1b[34;1m\xe2\x96\x88\n\x1b[33;1m    \xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x9d\n\x1b[1;91m                     [[\x1b[1;92m WELCOME \x1b[1;91m]]\n"""

# Function to make unique name
def make_name(n):
    letters = ascii_lowercase + ascii_uppercase
    letters_len = len(letters)
    name = ''
    n += 1
    while n:
        n -= 1
        name = letters[n % letters_len] + name
        n //= letters_len
    return name

def anim_text(x):
    sys.stdout.write(x)
    sys.stdout.flush()
    sys.stdout.write('\r')

if __name__ == '__main__':
    # How to use
    if len(sys.argv) < 2:
        sys.exit('Usage: python' + ['2','3'][PY3X] + ' RE.py file')

    # About this program
    print(__doc__ + '[!] Reverse ' + sys.argv[1] + ' will begin. Please wait...')

    # Check external modules
    try:
        if PY3X: from decompyle3.main import decompile
        else: from uncompyle6.main import decompile
    except ImportError as e:
        sys.exit('[Error] ' + e + ' :-\\')

    # Import standard lib modules
    from time import sleep
    from string import ascii_lowercase, ascii_uppercase
    try: from StringIO import StringIO
    except: from io import StringIO
    import itertools, re
    sleep(0.001)

    # Read and write to IO
    f = StringIO()
    f.write(open(sys.argv[1]).read())
    sleep(0.001)

    # Check if there is exec or not
    if not re.search('(exec|eval)', f.getvalue()):
        sys.exit('Sorry, exec keyword or eval function not found :(')
    
    # Some keywords to find and replace
    k = make_name(8)
    w = { 'exec': k + '=', 'eval': k + '=' }
    # Simple spinner based on msf console
    c, g = "Decompiling code objects.... ", "-\|/"*11
    d = c.upper()
    s = [c[0:i] + d[i] + c[i+1:] + g[i] for i in range(len(c))]
    s = itertools.cycle(s)
    # Function to replace with multiple patterns
    _ = lambda x, y: re.compile("(%s)" % "|".join(map(re.escape, x.keys()))).sub(lambda z: x[z.string[z.start():z.end()]], y, count=1)
    # Output filename
    o = sys.argv[1][:-3] + '-dec.py'
    # Make it locals and globals
    d = dict(locals(), **globals())
    del(PY3X, g)

       
    # Let's Rock n Roll...
    while True:
        try:
            # ... dance dance dance ...
            c = _(w, f.getvalue()).replace('\0','')
            if not c: break
            # Clean IO
            f.truncate(0)
            # ... dance dance dance ...
            exec(c, d, d)
            c = locals()['d'][k]
            # Show spinner
            anim_text('[!] ' + next(s))
            # Decompile with uncompyle6/decompyle3
            try: decompile(None, c, f)
            except: f.write(c)
            # Check if there is no decode then stop loop
            if not re.search(r'(^exec|eval|module$)', f.getvalue(), flags=re.M): break
        except KeyboardInterrupt:
            sys.exit('\x1b[?25h\n')
        except Exception as e:
            sys.exit('\x1b[?25h' + str(e) + '\n')
        # Take a breath
        sleep(0.001)

    # Sit back, relax and enjoy ;)
    c = f.getvalue().replace('\0','').strip().rstrip()
    f.truncate(0)
    sys.stdout.write('[!] Decompiling code objects... done\n')
    anim_text('[!] Writing code to ' + o + '...')
    open(o, 'w').write(c)
    sleep(0.8)
    sys.stdout.write('[!] Writing code to ' + o + '... done\n')
    sleep(0.3)
    print('\x1b[?25h\n' + c + '\n')
    del(f, c, k, w, s, d, o, sys, sleep, ascii_lowercase, ascii_uppercase, StringIO, itertools, re)