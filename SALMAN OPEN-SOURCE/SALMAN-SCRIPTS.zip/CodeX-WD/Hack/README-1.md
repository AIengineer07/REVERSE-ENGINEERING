## ALL IN ONE FACEBOOK HACKING TOOLKIT FOR NOOBZ
![FIRST RUN OF MY TOOL](https://github.com/mkdirlove/FBTOOL/blob/master/Screenshot_2020-04-27_17-37-57.png)
#
## LOGIN METHODS
- [x] NORMAL LOGIN
- [x] ACCESS TOKEN LOGIN

## AVAILABLE FEATURES
- [x] Facebook friend info fetcher
- [x] Get ID from friend
- [x] Get ID friend from friend
- [x] Get group member ID
- [x] Get email friend
- [x] Get email friend from friend
- [x] Get a friend's phone number
- [x] Get a friend's phone number from friend
- [x] Mini Hack Facebook(Target)
- [x] Multi Bruteforce Facebook
- [x] Super Multi Bruteforce Facebook
- [x] BruteForce(Target)
- [x] Yahoo Checker(Deprecated)
- [x] Bot Reactions Target Post
- [x] Bot Reactions group Post
- [x] BOT COMMENT Target Post
- [x] BOT COMMENT group Post
- [x] Mass delete Post
- [x] Mass accept friends
- [x] Mass delete friend
- [x] ACreate Post
- [x] Create Wordlist
- [x] Account Checker 
- [x] See my group list
- [x] Profile Guard

## INSTALLATION & USAGE

    $ git clone https://github.com/mkdirlove/FBTOOL
    
    $ cd FBTOOL

    $ python2 fbtool.py
    
    or
    
    $ sudo python2 fbtool.py
#
