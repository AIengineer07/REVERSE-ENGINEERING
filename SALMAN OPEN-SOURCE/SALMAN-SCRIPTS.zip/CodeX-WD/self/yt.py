from pytube import YouTube
link= "https://youtu.be/Esxgz15PyxQ"
yt = YouTube( link )
yt.streams.first( ).download( )