# Decompile by Mardis (Tools By Kapten-Kaizo)
# Time Succes decompile : 2022-06-02 12:49:59.606018
import os
import sys
import time
import requests
import random
import platform
import base64
import subprocess
from concurrent.futures import ThreadPoolExecutor

def runtxt(z):
    for e in z + "\n":
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.03)
def notice():
	print("")
	runtxt('    Wating For Anousment And Voting In Group Stay Happy')
	print("")
	runtxt("\n        Admin :- CHAND")
	print("")
	runtxt("\033[1;32m        YouTube Channel :- CHANDTRICKER")
	print("")
	runtxt("\033[1;33m        Team :- CHAND + SONA + LOVER")
	print("")
	runtxt("\033[1;33m            🌹🌹🌹🌹🌹🌹🌹🌹🌹🌹")
	print("")
	runtxt("\033[1;36m          Pro Hackers Or Programers")
	input()
logo="""
\033[1;31m ▄████████              ▄████████ 
 ███    ███             ███    ███ 
 ███    █▀              ███    █▀  
\033[1;32m ███                    ███        
 ███                  ▀███████████ 
 ███    █▄                     ███ 
\033[1;36m ███    ███              ▄█    ███ 
 ████████▀             ▄████████▀  
"""
os.system('clear')
print(logo)
print("[🔥]•••••••••••••••••{C + S}•••••••••••••••••[🔥]")
print("")
print ("\033[1;32m     Welcome 🤪 To Lottery And Win 500 Rupees And  😊 Accounts")
print("")
print("        Recommend Things To Enter Lottery👇")
print("")
print("            Pakistan Zindabad 👍🔥")
print("")
print("\033[1;32m ! :- 5 Winner  ko 100Rs 100Rs mile ge Aur Koch   Account")
print("\033[1;33m ! :- Note All countries allowed")
print("\033[1;35m 1 :- Subscribe Like And Comment")
print("\033[1;36m 2 :- Join My Group ")
print("\033[1;37m 3 :- Send Name Or Screen Shot Subscribe Ka")
print("")
print("\033[1;33m   [1] Subscribe Our Channel")
Ahmad = input()
if Ahmad in ["", " "]:
    print (" [!] Please Select Correct Option")
    exit()
elif Ahmad in ["1", "01"]:
    os.system('xdg-open https://youtube.com/channel/UCPErGt_PlIcbobfyCwle9HA')
    time.sleep(1.0)
    os.system('clear')
    print(logo)
print("[🔥]••••••••••••{YT CHAND TRICKER}••••••••••••[🔥]")
print("")
print("        Recommend Things To Enter Lottery👇")
print("")
print("\033[1;35m 1 :- subscribe like and comment")
print("\033[1;36m 2 :- join my group ")
print("\033[1;37m 3 :- Send Name or Screen shot Subscribe ka")
print("")
print("\033[1;36m   [2] Join My Group")
Ahmad = input()
if Ahmad in [""]:
    print (" [!] Please Select Correct Option")
    exit()
elif Ahmad in ["2", "02"]:
	os.system('xdg-open https://chat.whatsapp.com/Ef2FpfXRD105l7s5fKkkpp')
	time.sleep(1.0)
	os.system('clear')
	print(logo)
print("[🔥]•••••••••••••••••{C + S}•••••••••••••••••[🔥]")
print("")
print("        Recommend Things To Enter Lotter👇")
print("")
print("\033[1;35m 1 :- subscribe like and comment")
print("\033[1;36m 2 :- join my group ")
print("\033[1;37m 3 :- Send Name or Screen shot Subscribe ka")
print("")
print("\033[1;32m   [?] Enter Your Name And Send Me")
ah = input('\n\033[1;31m    Type Your Name :-\033[1;33m ')
tks = 'Dear%20Sir,%20Please%20Add%20My%20Name%20In%20Lottery%20%20%20%20%20My%20%20Name%20%20:%20'+ah
os.system('am start https://wa.me/+994400511189?text=' + tks)
time.sleep(1.0)
print('\n\033[1;32m   Congratulations Your Name Enter To Lottery ')
print("")
input("            \033[1;33m     Press Enter")
os.system('clear')
print(logo)

notice()
