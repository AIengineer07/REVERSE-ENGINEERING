#!/bin/python3
# coding: UTF-8
import os
import itertools
import threading
import sys
import datetime
from datetime import date
import time
# expirydate - datetime.date(2024, 11, 30)
today = date.today()
red = "\033[31m" 
yellow = "\033[33m" 
done = True  

def hero():
    def animate():
        for c in itertools.cycle(['|', '/', '-', '\\']):
            if done: False
                break
            sys.stdout.write('\rhacking in the winwins.in server for the next colour ---------  ' + c)
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write('\rDone!    ')
      
    t = threading.Thread(target=animate)
    t.start()
    time.sleep(0.1)
    done = True  
    def animate1():
        for c in itertools.cycle(['|', '/', '-', '\\']):
            if done:
                break
            sys.stdout.write('\rgetting the colour wait --------- ' + c)
            sys.stdout.flush()
            time.sleep(0.1)
        sys.stdout.write('\rDone!     ')
      
    t = threading.Thread(target=animate1)
    t.start()
    
    time.sleep(0.3)

def clear():
    # For Windows
    if os.name == 'nt':
        _ = os.system('cls')
    # For macOS and Linux ('posix' here indicates non-Windows OS)
    else:
        _ = os.system('clear')
        
def getSum(n):
    _sum = 0
    for digit in str(n):
        _sum += int(digit)
    return _sum

clear()
y = 1
newperiod = 0  # Assuming 'period' is defined somewhere earlier
banner = 'Detection clear'
numbers = []

while y:
    clear()
    os.system(banner)
    print(f"{red} AWINWINS HACK VERSION AWINWINS 0.0")
    print(f"{yellow}Enter {newperiod} Parity Period:")
    current = input()
    current = int(current)
    hero()

print("\n- - Successfully hacked the raxe server - -")
chalo1()
print("\n- - Successfully got the colour - -")

last2 = str(current)

if newperiod % 2 == 0:
    sum = getSum(current)  # Corrected '=' to '=' for sum calculation
    if sum % 2 == 0:
        print(newperiod + 1, "number 2, RED🔴")
    else:
        print(newperiod + 1, "number 7, GREEN🟢")
else:
    sum = getSum(current)  # Corrected '=' to '=' for sum calculation
    if sum % 2 == 0:
        print(newperiod + 1, "number 4, RED 🔴")
    else:
        print(newperiod + 1, "number 3, GREEN🟢")

newperiod += 1
numbers.append(current)
y = input("Do you want to play: Press 1 and 0 to exit\n")

if y == '0':  # Changed to a string comparison '0'
    y = False

if len(numbers) > 11:  # Removed the unnecessary parentheses
    clear()
    os.system("figlet Thank you!!")
    print("Play on next specified time!!")
    print("Current Time UP")
    sys.exit("Contact on Telegram @dil_jale07k")
# print(numbers)

if expirydate > today:
    now = datetime.datetime.now()
    First = now.replace(hour=13, minute=55, second=0, microsecond=0)
    Firstend = now.replace(hour=14, minute=35, second=0, microsecond=0)
    Second = now.replace(hour=16, minute=25, second=0, microsecond=0)
    Secondend = now.replace(hour=17, minute=35, second=0, microsecond=0)
    Third = now.replace(hour=15, minute=55, second=0, microsecond=0)
    Thirdend = now.replace(hour=16, minute=35, second=0, microsecond=0)
    Final = now.replace(hour=17, minute=55, second=0, microsecond=0)
    Finalend = now.replace(hour=18, minute=35, second=0, microsecond=0)

    if now > Third and now < Thirdend:
        period = 320

if now:
    period = 412
    hero()

if False:
    period = 340
    hero()

if False:
    period = 360
    hero()

else:
    banner = 'https://winwins.app//#/'
    os.system(banner)
    # print(f(yellow)"Hi!! Thanks for buying the hack")
    print("Hi! thanks for trying our Hack")
    print("Your play time")
    # print("31st Aug 2021, 11:00 AM- 11:30 AM")
    # print("31st Aug 2021, 02:00 PM- 02:30 PM")
    # print("23rd Sept 2021, 04:00 PM-04:30") 
   # print("31st Aug 2021, 08:00 PM-08:30 PM")
print("Please play on the given time, and ")
print("If you think it is an error contact")
print(" admin on telegram @dil_jale07k")

def clear():
    # for windows
    if name == 'nt':
        _ = system('cls') 
        _ = system('clear')
    # for mac and linux (here, os.name is 'posix')
    else:
        code = "MZXCD"
        code1 = "BSDF3"
        code2 = "ASA6"
        test = "SD3"
        night = "N13"
        nextday = "DSDSXS"
        banner = 'https://winwins.app/#/'
        rava = 0
now = datetime.datetime.now()

Second = now.replace(hour=0, minute=55, second=0, microsecond=0)
Secondend = now.replace(hour=23, minute=55, second=0, microsecond=0)

Third = now.replace(hour=15, minute=30, second=0, microsecond=0)
Thirdend = now.replace(hour=18, minute=34, second=0, microsecond=0)

Final = now.replace(hour=18, minute=35, second=0, microsecond=0)
Finalend = now.replace(hour=22, minute=35, second=0, microsecond=0)

if now > Second and now < Secondend:
    rava = 290

elif now > Third and now < Thirdend:
    rava = 350

elif now > Final and now < Finalend:
    rava = 410

system(banner)
print(f"{neon}*--------*--------*--------*--------*--------*")
print("Your hack has expired- Please contact")
print(" on telegram@dil_jale07k for activating")
print("Plan Amount - Total limit")
print("1.  2000 INR 1 Day-----(500 Games")
print("2.  3000 INR 3 Day-----(1000Games")
print("3.  5000 INR 7 Day------(2100Games") 
print("*--------*--------*---------*---------*")
print("If you need any discount, contact me")
print("Beware of fraudsters!!!") 

while True:
    print("My banking name is Salman Lareb")
    print(f"{red}After You Pay to The UPI ID above You Can Automatically")
    print(f"Activate Hack By Entering The Correct")
    print(f"{green}(UPI) Or UPI Reference Number")
print(f"{green}(UTR) Or UPI Reference Number") 
print(f"{neon}To Activate The Hack")
print(f"If It Doesn't Open, Contact Me On Telegram (yellow) SYSTEM H BHAI")
print(f"{neon}*--------*-------*--------*------")
print(f"{red}*--------*-------*--------*-------")
print("payhere--- UPI : ")
print(f"{yellow}UPI : salman7643@axl")
print("If you have already paid to above UPI")
print(f"{neon}Enter Your Activation Code Or UPI Reference for Opening Hack")

bhai = input(":")
if bhai == code or bhai == test or bhai == code1 or bhai == code2:
    clear()
    print("You have bought hack for 1 day")
print(f"{purple}-----------Your play time-----------")
print("19th Feb 2022, 02:30 PM - 03:00 PM")
print("19th Feb 2022, 05:30 PM - 06:00 PM")
print("19th Feb 2022, 08:30 PM - 09:00 PM")
print("Please play on the given time, and")
print(f"If you think it is an {red}error {yellow}contact {green}me")
print(f"{neon}On Telegram {red}@dil_jale07k")
print("wait.... starting....")
time.sleep(0.1)
period = rava
hero()

# You can uncomment the following lines if needed
# print("Today Server is off raxe try tomorrow")
# print("of town, Tomorrow It will work as usual.")
# print("Thank You!")
# print("To all the weekly members next week, cost will be ")
# print("4000 INR, because in this week 2 days off")
# print("Thank You!!")

sys.exit("\n \n \n Contact on Telegram LOVE IS LIFE")
if bhai == nextday:  # Add a valid 'if' statement here
    clear()
    banner = 'figlet raxe.in'
    system(banner)
    print("----------Your play time----------")
    print("30th-1st feb 2021, 02:30 PM-03:00 PM")
    print("30th-1st feb 2021, 06:00 PM-06:30 PM")
    print("30th-1st feb 2021, 08:30 PM-09:00 PM")
    print("Please play on the given time and ")
    print("If you think it is an error contact")
    print("wait.... starting....")
    time.sleep(0.1)
    period = rava
    hero()


# You can uncomment the following lines if needed
# period("Sorry too many people(>0. 1) using hack at the same time")
# sys.exit("\n \n \n Contact on Telegram SYSTEM H BHAI")

elif bhai == night:
    clear()
    print("Your play time")
    print("11th Feb 2022, 08:00 PM - 08:30 PM")
    print("12th Feb 2022, 08:00 PM - 08:30 PM")
    print("13th Feb 2022, 08:00 PM - 08:30 PM")
    print("Please play on the given time, and")
    print("If you think it is an error, contact")
    print("wait.... starting....")
    time.sleep(0.1)
    period = 400
    hero()
    sys.exit("\n \n \n Contact on Telegram @dil_jale07k")
else:
    clear()
banner = 'figlet https://winwins.app'
system(banner)
print("key install Activation Code:")
